# Make hero section fill the full main width

## Goal
Extend the hero section so it spans the full width of the `<main>` container instead of being constrained by a centered max-width.

## Changes
1. In `src/components/site/HeroSection.tsx`:
   - Remove `mx-auto max-w-7xl` from the `<section>` className so the section fills the full main width.
   - Keep the internal content aligned by keeping `px-6` horizontal padding and the existing two-column grid.
   - Preserve `overflow-hidden rounded-3xl` and the bubble background so the visual style stays intact.

## Verification
- Run the build to confirm no className errors.
- Check the live preview to confirm the hero section now touches the full width of the page while the text and image remain properly aligned inside it.
