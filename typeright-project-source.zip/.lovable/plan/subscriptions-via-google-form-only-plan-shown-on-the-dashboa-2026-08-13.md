# Subscriptions via Google Form only, plan shown on the dashboard

Subscriptions stop being something a learner buys in the app. They sign up through the Google Form, an admin activates them, and the learner simply sees which plan they are on from their dashboard.

## What changes for learners

- No more Billing & subscription page, no in-app checkout, no payment-proof upload, no cancel/reactivate buttons.
- The Pricing page stays as a shop window: plans, what's included, prices. Every plan button becomes "Sign up via form" and opens the Google Form in a new tab (Teams keeps its enquiry form).
- The account menu loses "Billing" and keeps "Dashboard".
- The dashboard gets one small card at the top: current plan name, status (Active / Pending / None) and the renewal or end date when there is one. If there is no plan, the card shows "No active plan" with a "View plans" link.

## Technical scope

Delete:
- `src/routes/_authenticated/billing.tsx`
- `src/routes/_authenticated/subscribe.$planCode.tsx`
- `src/routes/_authenticated/subscription.pending.$paymentId.tsx`

Edit:
- `src/components/site/TopBar.tsx` — remove both `/billing` links.
- `src/routes/pricing.tsx` — replace the `/subscribe/$planCode` links with an external link to `ENROLMENT_FORM_URL`; drop the interval-driven checkout wiring that is no longer used, keep the price display.
- `src/lib/subscriptions.functions.ts` — remove `startSubscriptionCheckout`, `abandonPendingSubscription`, `submitPaymentProof`, `cancelAtPeriodEnd`, `reactivateSubscription` and `myPayments`. Keep `listPublicPlans`, `mySubscription`, `myEntitlements`, `submitTeamsEnquiry` and the admin functions.
- `src/lib/learning.functions.ts` — include the learner's current subscription (plan name, status, period end) in the dashboard payload so the card needs no extra round-trip.
- New `src/components/dashboard/PlanCard.tsx` — the simple plan summary, mounted at the top of `src/routes/_authenticated/dashboard.tsx`.

Database: no schema changes. The `subscriptions`, `subscription_payments` and plan tables stay as they are; admins keep activating a subscription server-side and the learner view is read-only.
