# Show all scheduled classes/exams on every learner dashboard

Currently the learner dashboard calendar only shows sessions the admin has assigned to that specific learner via `class_attendees`. Change it so every signed-in learner sees the full schedule of upcoming classes and exams, while keeping enrolment on the existing Google Form.

## What changes

1. **Dashboard data fetch**
   - In `src/lib/learning.functions.ts`, update `getDashboard` to query `course_sessions` directly for all upcoming sessions instead of joining through `class_attendees`.
   - Still fetch the current user's `class_attendees` rows so assigned sessions can show an optional "Assigned to you" indicator, but the calendar list itself is no longer gated by assignment.

2. **RLS policy**
   - Add a `TO authenticated` SELECT policy on `course_sessions` so every signed-in learner can read scheduled sessions. Admins and instructors keep their existing write policies.

3. **UI label**
   - Update `SessionCalendar.tsx` heading from "My classes & exams" to "Upcoming classes & exams" (or similar) so the copy matches the new behaviour.

4. **Enrolment path stays unchanged**
   - The calendar remains read-only. Learners do not book seats or see capacity. The Google Form link on `/courses` continues to be the only enrolment path.

## Out of scope

- Public/guest calendar view.
- Seat availability or capacity display.
- In-calendar enrolment or booking.
- Changes to admin calendar creation/editing.
