# Remove frame effects from hero image

## Goal
Make the hero instructor image appear completely frameless by removing all surrounding visual treatments while keeping it sized and positioned correctly in the two-column layout.

## Changes
1. In `src/components/site/HeroSection.tsx`:
   - Remove `shadow-xl` from the `<img>` className.
   - Remove the decorative glow container (`<div className="absolute -inset-6 -z-10 rounded-3xl bg-accent/10 blur-2xl" />`) behind the image.
   - Keep `aspect-[4/3] w-full object-cover` so the image still fills its column properly.

## Verification
- Run the build to confirm no className or JSX errors.
- Check the live preview to confirm the hero image has no shadow, glow, or rounded frame and still aligns with the text column.
