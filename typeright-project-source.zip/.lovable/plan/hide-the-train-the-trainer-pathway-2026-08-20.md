# Hide the Train-the-Trainer Pathway

## Goal
Remove the "Future Train-the-Trainer Pathway" from all public-facing parts of the site, without deleting the underlying content so it can be brought back later.

## Changes
1. **Home page** (`src/routes/index.tsx`): remove the Train-the-Trainer card from the "What we offer" carousel, leaving Keyboard Mastery and Shorthand Training. Update the section description so it no longer mentions the trainer pathway.
2. **Courses index** (`src/routes/courses.index.tsx`): drop `trainer` from the category order/labels so only Core programmes is listed.
3. **Top bar** (`src/components/site/TopBar.tsx`): remove the "Train-the-trainer" links from both the desktop and mobile Courses dropdowns.
4. **Course data** (`src/data/courses.ts`): mark the trainer course as hidden (comment it out or exclude it from the exported list) so it no longer shows in listings or category pages.

## Kept as-is
- The `/courses/trainer` route file, `TrainerTemplate.tsx`, and the cover image remain in the project, unlinked, so the pathway can be re-enabled quickly.
- No database or enrolment changes.

## Verification
Check the home page, `/courses`, and the Courses dropdown show no trainer entry, and that no build errors appear from the removed data reference.
