# Blend the typing illustration into the section — no card frame

## Goal
The generated typing illustration in "What we offer" (`#services`) currently sits inside a bordered, rounded card. The user wants it frameless and blended into the section background, like the uploaded reference (floating illustration, no container).

## Changes

1. **Regenerate the image with a transparent background**
   - Replace `src/assets/typing-illustration.jpg` with a transparent PNG at `src/assets/typing-illustration.png` (same typing/keyboard concept, navy/blue palette with peach/orange accents), so it floats directly over the section's bubble backdrop with no visible edges.

2. **`src/components/services/ServicesCarousel.tsx`**
   - Update the import to the new PNG.
   - Remove the frame classes from the `<img>` (`rounded-2xl border border-border bg-card shadow-sm`) — keep responsive width, alt text, and `loading="lazy"`.

## Notes
- Presentation-only change; no other sections touched.
- Verify: build log clean + Playwright screenshot of `#services` confirming the illustration blends with the bubble backdrop.
