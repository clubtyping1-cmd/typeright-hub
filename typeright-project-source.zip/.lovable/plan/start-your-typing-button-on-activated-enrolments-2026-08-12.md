# "Start your typing" button on activated enrolments

Once an admin activates a learner's enrolment, that course card on the learner dashboard gets a button that opens the external practice/class portal in a new tab.

## Behaviour

- Button label: **Start your typing**
- Opens in a new tab (`target="_blank"`, `rel="noopener noreferrer"`).
- Shown on every enrolment card whose status is active (hidden for suspended/completed enrolments).
- Same fixed destination link for all learners.

## Technical scope

- New constant in `src/lib/enrolment.ts` (e.g. `PRACTICE_PORTAL_URL`) holding the single external URL, alongside the existing Google Form constant.
- `src/components/dashboard/EnrolledCourseCard.tsx`: render the button using that constant, styled as the card's primary action next to the existing Continue / Start learning link.
- No database or server-function changes; activation already sets enrolment status.

## Needed from you

The actual portal URL. Until it's provided the constant will point at a clearly marked placeholder that is easy to swap.
