# Homepage Alternating Backgrounds

Update the landing page (`src/routes/index.tsx`) so each section alternates through a white, grey, dark rhythm for a more visual, modern feel.

## Proposed pattern

Top-to-bottom sequence:

1. HeroSection → `bg-background` (white)
2. ServicesHero → `bg-secondary/50` (light grey)
3. TestimonialsSection → `bg-foreground` (dark)
4. ServicesCarousel → `bg-background` (white)
5. PhotoGallery → `bg-secondary/50` (light grey)
6. CompactCTA → `bg-foreground` (dark)
7. SiteFooter → `bg-background` (white)

## Files to update

- `src/components/site/HeroSection.tsx` — keep current white background.
- `src/components/services/ServicesHero.tsx` — replace gradient with solid `bg-secondary/50`, remove bottom border.
- `src/components/services/TestimonialsSection.tsx` — set `bg-foreground`, invert all text to `text-background` / `text-background/80`, update chips and card borders for dark readability.
- `src/components/services/ServicesCarousel.tsx` — set `bg-background`.
- `src/components/services/PhotoGallery.tsx` — set `bg-secondary/50`.
- `src/components/services/CompactCTA.tsx` — set `bg-foreground`, invert text, update button styling for dark background.
- `src/components/site/SiteFooter.tsx` — keep current white background.

## Verification

- Run a typecheck/build check to confirm no class-name or layout errors.
- Capture a preview screenshot to verify the alternating sections read cleanly and the dark bands remain readable.