# Restyle "What we offer" section like the reference, with a bubble backdrop

## Goal
Make the `ServicesCarousel` section (`#services` on the homepage) visually similar to the uploaded reference: a bold stacked headline on the left with an eyebrow, supporting text, a pill CTA button, and a row of small circular icon badges — with a soft decorative bubble backdrop behind the section (per the user's request, replacing the reference's wave/illustration).

## Changes

**`src/components/services/ServicesCarousel.tsx`** (only file edited):
1. **Bubble backdrop** — make the `<section>` `relative overflow-hidden` and render the existing `BubbleBackground` component (already used in the hero, blue/orange blurred circles) as the first child. Wrap content in a `relative` container so it sits above the bubbles.
2. **Left intro column** — restyle to match the reference:
   - Eyebrow stays as-is (small uppercase accent text).
   - Headline larger and heavier (`text-4xl sm:text-5xl font-bold`), keeping the current text.
   - Add a pill CTA button below the description: **"See Courses"** (accent background, rounded-full, arrow icon) linking to `/courses`.
   - Add a row of 3 circular outline icon badges beneath the button, echoing the reference's "Taught by industry pros / friendly community / tactical feedback" row — using TypeRight-relevant items with lucide icons:
     - "Certified trainers" (badge/award icon)
     - "Small class sizes" (users icon)
     - "Practical feedback" (message/clipboard icon)
3. **Right side** — keep the existing Embla course card carousel, arrows, and dot navigation unchanged.

**`src/routes/index.tsx`** — no changes expected (props already passed); only touched if a new prop is needed.

## Notes
- No color/text content changes beyond what's listed; light grey/blue theme tokens are preserved.
- No new assets generated — the backdrop is pure CSS bubbles via the existing `BubbleBackground` component.
- Verify: build log clean + Playwright screenshot of the section.
