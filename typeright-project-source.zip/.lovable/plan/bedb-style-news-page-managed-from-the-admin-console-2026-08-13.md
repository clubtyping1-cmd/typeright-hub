# BEDB-style News page, managed from the Admin Console

## What the page will look like

Rebuild `/news` to mirror the BEDB news layout:

- Dark page header with a single "News" title, matching the About page hero style.
- One featured post at the top: large cover image, headline, short intro, "Read More" link.
- Below it, a vertical list of posts. Each row is a card: cover image on the left, headline, a 2-3 line excerpt, then a small meta footer (author, date, read time).
- Clicking any headline or card opens a full article page at `/news/{slug}` with the cover image, title, meta line, and full body text.
- Fully responsive: image stacks above text on mobile.
- Empty state when no posts are published yet.

## How news gets added

News is added by staff in the Admin Console — no code changes needed for each post.

- A new **News** tab appears in the Admin Console beside Calendar, Enrolments and Programmes.
- The tab lists all posts (published and draft) with edit and delete actions.
- "New post" opens a form with: title, category (Announcement / Examinations / Programme update / Partnership / Community), short excerpt, full body, cover image upload, author name, publish date, and a Published toggle.
- Only published posts appear on the public `/news` page; drafts stay internal.
- The newest published post automatically becomes the featured item at the top.
- The learner dashboard announcement banner stays as it is — it is separate from the public news feed.

## Technical notes

- New `public.news_posts` table: `id`, `slug` (unique, generated from title), `title`, `excerpt`, `body`, `category`, `cover_url`, `author`, `published_at`, `is_published`, `created_by`, timestamps. GRANTs for `anon` (SELECT), `authenticated`, `service_role`; RLS: public read where `is_published = true`, admin full manage via `has_role(auth.uid(), 'admin')`.
- Public storage bucket `news-covers` for cover images; admin-only write policy, public read.
- `src/lib/news.functions.ts` — server functions: `listPublishedNews`, `getNewsPost(slug)`; admin-guarded `listAllNews`, `upsertNewsPost`, `deleteNewsPost`.
- Routes: rewrite `src/routes/news.tsx` as a layout with `news.index.tsx` (list) and `news.$slug.tsx` (article), each with its own `head()` metadata; the article route sets `og:image` from the cover URL and includes NewsArticle JSON-LD.
- Components: `src/components/news/NewsFeatured.tsx`, `NewsListItem.tsx`, `NewsArticleBody.tsx`; admin UI in `src/components/admin/NewsManager.tsx` plus route `src/routes/_authenticated/admin.news.tsx`, with an explicit tab nav added to `admin.tsx`.
- The hardcoded `articles` array in `src/routes/news.tsx` is removed; a migration seeds those five entries as published posts so the page is not empty.