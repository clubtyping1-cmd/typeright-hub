# Replace the dashboard with a learner Profile page

The `/dashboard` route is retired and replaced by `/profile`, which keeps the learner's courses and class calendar and adds a profile header with an achievement **level** and **badges** that admins award.

## What the learner sees at /profile

- **Profile header** — avatar, name (editable), email, member-since, current plan, and a level badge (e.g. "Level 3 — Advanced") with a progress strip toward the next level.
- **Badges** — a grid of the 12 badges. Earned badges appear in full colour with the date awarded; unearned ones appear locked/greyed so learners can see what to aim for.
- **My courses** — unchanged cards, including the "Start your typing" button on active enrolments.
- **Calendar** — unchanged upcoming classes and exams.

Badge set: New Learner, Active Learner, Course Completed, Assessment Passed, Certified Learner, Perfect Attendance, Most Improved, Top Performer, Keyboard Master, Shorthand Master, AI Skills Champion, Future Trainer.

## What the admin does

A new **Learners** tab in the Admin Console:
- Pick a learner, set their level (1–5 with a name such as Beginner / Foundation / Intermediate / Advanced / Master).
- Toggle badges on or off for that learner; awarding records who awarded it and when.

## Routing

- New route `/profile`; `/dashboard` permanently redirects to `/profile` so old links and bookmarks keep working.
- Top bar and every in-app link ("Dashboard" menu item, post-login destination) point to Profile.

## Technical notes

- Database migration: `learner_levels` (user_id, level int, level_name, updated_by, updated_at) and `learner_badges` (user_id, badge_code, awarded_by, awarded_at, unique per user+badge), plus a `badges` reference table seeded with the 12 badge codes, labels and descriptions. Each table gets GRANTs, RLS enabled, learner read-own policies and admin full-access policies via `has_role(auth.uid(), 'admin')`.
- `src/lib/learning.functions.ts`: extend `getDashboard` (kept as the profile data fetcher) to also return level and earned badges; add admin server fns in `src/lib/admin.functions.ts` for setting a level and awarding/revoking badges.
- New components `src/components/profile/LevelCard.tsx` and `BadgeGrid.tsx`; reuse existing `ProfileCard`, `EnrolledCourseCard`, `SessionCalendar`, `PlanCard`.
- New `src/components/admin/LearnerProgressManager.tsx` wired into the admin tabs.
- `src/routes/_authenticated/dashboard.tsx` becomes a redirect; page body moves to `src/routes/_authenticated/profile.tsx` with its own head metadata.
