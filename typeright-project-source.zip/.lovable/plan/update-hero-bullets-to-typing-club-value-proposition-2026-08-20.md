# Update Hero Bullets to Typing Club Value Proposition

Replace the current three bullet points in the landing page hero section with three value-proposition statements that reflect the typing club's benefits.

Chosen bullets (from the list provided):
1. Individuals improve their speed, accuracy, productivity and employability.
2. Employees modernise their clerical and administrative skills using digital and AI tools.
3. Government agencies and organisations access structured, customised workforce training.

## File to change
- `src/components/site/HeroSection.tsx` — update the `hero.bullets` array. No other layout, styling, or component changes needed.

## Verification
- Load the landing page preview and confirm the hero section shows exactly three new bullets with checkmarks.
- Confirm no TypeScript or build errors.