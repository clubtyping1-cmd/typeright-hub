# Remove the "Your plan" card from the profile page

Remove the plan/subscription summary card from the learner profile page and clean up the now-unused code.

## Changes

1. `src/routes/_authenticated/profile.tsx`
   - Remove the `PlanCard` import.
   - Remove the `<PlanCard subscription={...} />` line from the profile layout.

2. `src/components/dashboard/PlanCard.tsx`
   - Delete this file; it is no longer used anywhere else.

3. `src/lib/learning.functions.ts`
   - Remove the `subscriptions` query from `getDashboard`.
   - Remove `subscription` from the returned payload.

## Out of scope

- No database schema changes.
- No changes to the public pricing page or subscription admin logic.
- The existing `subscription` tables and server functions remain intact for future use if needed.
