# Redesign hero section to centered layout with floating circular accents

## Goal
Rework the hero section to match the reference layout: a centered text block (headline, subtext, single CTA) with decorative circular icon bubbles floating on the left and right edges, instead of the current two-column text/image split.

## Current state
`src/components/site/HeroSection.tsx` renders a two-column grid: left text column (eyebrow, title, subtitle, bullets, two buttons, trust line) and right image column (trainer portrait), over a `BubbleBackground`.

## Changes

1. **Layout in `src/components/site/HeroSection.tsx`**
   - Replace the two-column grid with a single centered column: `mx-auto max-w-3xl text-center`.
   - Center the headline and supporting text, stacked like the reference.
   - Keep ONE primary CTA button ("Explore Our Programmes"), centered and pill-shaped; remove the secondary "View Pricing" button or demote it — recommend keeping just the primary to match the reference.
   - Remove the trainer portrait image from the hero (the reference has no hero image — floating circular badges replace it).
   - Drop the checkmark bullet list (or fold one key phrase into the subtitle) to keep the composition clean like the reference.

2. **Floating circular accents**
   - Create `src/components/site/HeroBadges.tsx`: absolutely positioned circular badges (varied sizes and brand colors — navy, peach, midnight) floating on the left and right sides of the hero, `aria-hidden`, hidden or reduced on mobile.
   - Badges contain simple relevant icons (Keyboard, FileText, GraduationCap, Sparkles, Users from lucide-react) inside colored circles, mirroring the reference's floating icon bubbles.

3. **Background**
   - Keep `BubbleBackground` as the section backdrop (full-width, edge-to-edge as previously set up).

## Files to modify
- `src/components/site/HeroSection.tsx`
- New: `src/components/site/HeroBadges.tsx`

## Verification
- Build passes.
- Playwright screenshot of the landing page confirming: centered headline and CTA, floating circular badges on both sides, no portrait image, bubble backdrop intact.
