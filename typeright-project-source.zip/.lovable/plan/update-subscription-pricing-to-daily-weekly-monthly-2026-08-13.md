# Update subscription pricing to daily / weekly / monthly

## Goal
Change the public subscription pricing so every individual plan (TRT, TRS, Complete) is offered at **BND 2 daily, BND 10 weekly, BND 35 monthly**. Remove the annual interval and remove the TypeRight Teams card from the pricing page.

## What will change

### Database
- Add `daily` as an allowed value for `plan_prices.interval`.
- Set the active prices for `trt`, `trs`, and `complete` to:
  - `daily` = BND 2
  - `weekly` = BND 10
  - `monthly` = BND 35
- Delete the existing `annual` prices for those three plans.
- Mark the `teams` plan as inactive and deactivate its `custom` price so it no longer appears publicly.

### Frontend
- Update `src/routes/pricing.tsx`:
  - Replace the interval selector with `Daily / Weekly / Monthly` and default to `monthly`.
  - Remove the `annual` tab and the "Save BND 100+" annual copy.
  - Remove the `teams` card from `PLAN_HIGHLIGHTS`.
  - Update the meta description to reference daily/weekly/monthly instead of weekly/monthly/annual.
- Update `src/lib/subscriptions.functions.ts`:
  - Add `daily` to `INTERVALS` and the `periodEndFor` helper so subscription dates compute correctly if a subscription is activated with a daily price.
  - Update the MRR helper in `adminMetrics` so it recognises the new intervals (daily = amount * 30, weekly = amount * 4.33, monthly = amount).
- Update `src/components/dashboard/PlanCard.tsx`:
  - Add a label for `daily` so the dashboard displays "BND 2 / daily" correctly.

## Notes
- The subscription checkout flow has already been removed; users still sign up via the Google Form. These changes only affect the displayed prices and the backing data.
- No plan entitlements or feature lists are changing; only the intervals and amounts.
