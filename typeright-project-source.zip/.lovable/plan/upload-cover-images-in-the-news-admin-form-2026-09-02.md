# Upload cover images in the News admin form

## What changes

In the Admin Console News form, the "Cover image URL" text field becomes an image uploader:

- A "Choose image" button opens the file picker (JPG, PNG, WebP, up to 5MB).
- The selected image uploads immediately and shows a thumbnail preview with a "Remove" link.
- Pasting a URL is still possible via a small "or paste a link" field, so existing posts keep working.
- Uploading is disabled until the image finishes; errors show as a toast.

Everything else in the form and the public News page stays the same — the stored value is still a public image URL.

## Technical notes

- New public storage bucket `news-covers` (created with the storage bucket tool, 5MB limit).
- Migration adds `storage.objects` policies: public SELECT on `bucket_id = 'news-covers'`; INSERT/UPDATE/DELETE limited to `public.has_role(auth.uid(),'admin')`.
- `NewsManager.tsx`: replace the cover URL `Input` with an upload control using `supabase.storage.from('news-covers').upload(...)` (path `${crypto.randomUUID()}.${ext}`, `upsert: false`), then `getPublicUrl` to set `form.coverUrl`. Local `uploading` state drives the disabled/pending UI.
- No changes to `news.functions.ts` or the news routes.
