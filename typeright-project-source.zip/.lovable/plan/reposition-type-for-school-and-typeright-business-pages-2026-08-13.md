# Reposition Type for School and TypeRight Business pages

## Goal
Redefine two public marketing pages so their content matches the user's clarified intent:

- **Type for School** (`/type-for-school`) should promote TypeRight's typing clubs / after-school programmes at schools in Brunei, not a school-wide institutional partnership.
- **TypeRight Business** (`/business`) should promote a separate freelancer / independent instructor pathway for people who want to teach TypeRight courses, not workforce upskilling for organisations.

The route URLs and top-bar labels will remain the same; only the content, messaging, and CTAs will change.

## What will change

### 1. `src/routes/type-for-school.tsx` — Typing Clubs at Schools

Rewrite the page to speak directly to schools, parents, and students about extracurricular typing clubs.

New sections:
- **Hero** — "Typing clubs for Brunei schools" with a student-focused message.
- **Why join** — benefits such as accurate typing, digital confidence, certificates, and competition-ready skills.
- **How it works** — weekly club sessions, progress tracking, and end-of-term showcase/assessment.
- **Club formats** — onsite at school, online after school, or hybrid.
- **What's included** — instructor-led sessions, practice materials, progress reports, certificates, and optional inter-school benchmarks.
- **CTA** — primary button opens the Google Form (`ENROLMENT_FORM_URL`) for schools to register a club; secondary button links to `/contact`.

Update the `<head>` meta title and description to match the new positioning.

### 2. `src/routes/business.tsx` — Teach TypeRight as a Freelancer / Instructor

Rewrite the page to attract freelancers and aspiring instructors who want to deliver TypeRight courses themselves.

New sections:
- **Hero** — "Teach TypeRight, build your own training practice" with a freelancer-focused message.
- **Why teach with us** — proven curriculum, ready-to-use materials, certification, marketing support, and ongoing coach access.
- **How the pathway works** — apply, get trained, get certified, start teaching.
- **What you can teach** — digital typing, digital shorthand, AI literacy, and workplace productivity programmes.
- **Support you receive** — lesson plans, slides, assessments, certificates, and a tutor community.
- **CTA** — primary button links to `/courses/trainer` to explore the train-the-trainer programme; secondary button links to `/contact` for a conversation.

Update the `<head>` meta title and description to match the new positioning.

### 3. No TopBar changes required

The top-bar labels "Type for School" and "TypeRight Business" are already correct in the user's view. The URLs will stay `/type-for-school` and `/business`. No routing or label changes are needed.

## Design and content notes
- Keep the existing visual system: light grey backgrounds, navy primary, blue accent, rounded cards, and the same section rhythm used on the current pages.
- Reuse the same icon set (`GraduationCap`, `Users`, `Sparkles`, `CheckCircle2`, etc.) so the pages still feel visually consistent.
- Both pages should remain responsive and include the same `TopBar` and footer-less single-page layout.
- All CTA buttons will be functional and route correctly.

## Out of scope
- No new routes or URL changes.
- No changes to the admin console, dashboard, or course catalogue.
- No new database tables or server functions.
