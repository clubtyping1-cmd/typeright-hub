# Align Keyboard Mastery content with the proposal document

I compared the PDF against the site. Fees, examination duration, certificate/transcript concept and the overall programme flow already match. Two areas differ but you chose to keep the site as-is, so they are out of scope:

- Practice pricing stays at BND 2 daily / 10 weekly / 35 monthly (PDF says 15 weekly / 50 monthly).
- Typing levels stay at four (Basic / Beginner / Intermediate / Advanced) rather than the PDF's three.

## Already matching (no change)

- Half-day course BND 40, Examination BND 40, Upgrade examination BND 40, Retake BND 25, Optional detailed progress report BND 10.
- Examination takes about 1 hour; certificate issued only to those who pass; transcript issued with the certificate.
- Programme flow: course -> online practice -> examination -> certificate -> level upgrade.

## Small gaps to fix on the Keyboard Mastery course page

1. State that the guided course is a **half-day morning session** (currently just "half-day").
2. Add the **Upgrade Typing Level Pathway** detail to the assessment section: retaking the course is optional, but a minimum weekly online practice subscription is required before an upgrade examination, and the upgrade is charged as a normal examination (BND 40), not a retake.
3. Add the **certificate title** wording: "Certificate of Achievement in Keyboard Mastery — <Level> Level".
4. List what the **Typing Level Transcript** contains: candidate name, assessment date, typing level, words per minute, accuracy, errors recorded, final result (Passed / Not Yet Achieved).
5. Note that the final speed result is recorded as **Net Words Per Minute**, supported by accuracy percentage and error count.
6. Clarify that the retake fee applies only to candidates who did not meet the passing mark for the level they attempted.

## Technical notes

All changes are content edits in `src/data/courses.ts` for the `keyboard-mastery-trt` entry — the description, `assessment.outcomes` / `assessment.steps`, and a short set of upgrade-pathway lines rendered by the existing `CourseAssessment` component. If a new field is needed for the upgrade pathway, it will be added to the `CourseAssessmentInfo` type and rendered by `src/components/courses/CourseAssessment.tsx`. No database, pricing or routing changes.
