# Hero Section: Full-Width Backdrop, Constrained Content

## Goal
Make the bubble backdrop in the hero section extend edge-to-edge across the page while keeping the text, buttons, and image aligned with the rest of the page content (max-width container).

## Current state
`src/components/site/HeroSection.tsx` renders a single `<section>` that is already full-width (no `max-w-7xl` or `mx-auto`). Because the content and the bubble background share the same wrapper, both currently extend edge-to-edge.

## Proposed change
1. Keep the `<section>` element full-width so the bubble backdrop fills the entire width.
2. Wrap the inner grid (text block + image) in a new container with `mx-auto max-w-7xl px-6` so it lines up with other page sections.
3. Move the existing `px-6` padding from the `<section>` to the inner container, or keep a small vertical padding on the section and put horizontal padding on the container.
4. Verify visually that the bubble background spans the full viewport but the text/image block stops at the same width as the rest of the page.

## Files to modify
- `src/components/site/HeroSection.tsx`

## Verification
- Build the app successfully.
- Take a Playwright screenshot of the landing page to confirm the bubble background reaches the edges while the hero text and image align with the sections below.
