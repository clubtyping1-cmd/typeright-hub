# News page in the "Insights" editorial layout

Restyle `/news` to match the reference: a big page title, a left category sidebar, one highlighted story in a split card, and a grid of latest articles below.

## What changes on the page

1. **Header** — remove the dark hero band. Replace with a large, tight, uppercase "NEWS" title on the page background, followed by a thin full-width rule.

2. **Left sidebar (desktop only)** — a "CATEGORIES" column listing the news categories that actually have published posts, each with a post count on the right. Clicking one filters the list; clicking again clears it. On mobile the sidebar collapses into a horizontal row of filter chips above the content.

3. **Featured story** — the newest published post shown as a two-column card: text panel on the left (small "HIGHLIGHTS" tag, large uppercase headline, then `CATEGORY | DATE` meta line), cover image filling the right half. Stacks vertically on mobile. Whole card is clickable through to the article.

4. **Latest articles** — heading reading "LATEST ARTICLES" (first word emphasised, second word muted), then a 3-column grid (2 on tablet, 1 on mobile) of compact cards: small cover thumbnail at the top-left of the card, a `CATEGORY | DATE` meta line, then a two-line headline. Cards sit on a light surface tile with subtle hover lift.

5. **Empty state** kept for when nothing is published; filtered-empty gets its own "no posts in this category" message.

The article page at `/news/{slug}` and the Admin Console News tab stay exactly as they are. Only presentation changes — no data model or server function edits.

## Technical notes

- `src/routes/news.index.tsx`: keep the existing loader and `useSuspenseQuery`; add local `useState` for the selected category and derive counts from the loaded posts. Swap `NewsHero` for the new title block.
- New `src/components/news/NewsCategorySidebar.tsx` (list + counts + mobile chip row) and `src/components/news/NewsCard.tsx` (grid card).
- Rewrite `NewsFeatured.tsx` as the split highlight card; retire `NewsHero.tsx` usage on the index (error state gets the same title block).
- Typography: uppercase tracking-tight headings via existing tokens; meta lines use `text-muted-foreground` with a `|` separator. All colours from existing semantic tokens — no hardcoded hex or `text-white`.
- Head metadata on the route is unchanged.
