# Activate enrolment after payment (admin-verified)

Payment stays offline: learner pays by bank transfer, an admin confirms the money arrived, then activates the enrolment from the Admin Console. Activation immediately gives the learner the course on their dashboard and books them into the class/exam slots you pick.

## Flow

```text
Learner submits Google Form + pays by transfer
        v
Admin Console -> Enrolments -> "Add enrolment"
  pick learner  |  pick programme  |  payment reference + amount + date paid
  tick the calendar slots they should attend
        v
Learner dashboard: course appears under "My courses",
selected classes/exams show on their calendar
```

## What the admin sees

A new **Enrolments** panel on `/admin`, next to the calendar and programmes panels:

- Table of existing enrolments: learner, programme, status (active / completed / suspended), payment reference, date enrolled.
- **Add enrolment** dialog:
  - Learner picker (searchable list of registered accounts by name/email).
  - Programme picker (from the programmes list already managed there).
  - Level and instructor (free text, optional — shown on the learner's course card).
  - Payment fields: reference/receipt number, amount paid (BND), date paid, optional note.
  - Slot checkboxes: upcoming classes and exams for that programme; ticked ones create roster entries.
- Row actions: edit (status, payment details, slots), and remove enrolment (also clears its roster entries), each with a confirm prompt.

If a learner has no account yet, the admin is told to have them sign up first — enrolment is tied to a real account.

## What the learner sees

- The course appears under **My courses** on their dashboard right after activation.
- The classes/exams they were booked into show an "Assigned to you" marker on the calendar (all scheduled slots stay visible as they are today).
- No payment UI is added for learners; nothing changes on the public course pages or the Google Form.

## Technical scope

Database (one migration):
- Add payment-tracking columns to `public.enrolments`: `payment_reference text`, `payment_amount_bnd numeric`, `paid_at timestamptz`, `payment_note text`, `activated_by uuid`, `activated_at timestamptz`.
- Existing RLS is sufficient: "Staff manage enrolments" (ALL) covers admin writes, "Learners read own enrolments" covers reads. The learner-update guard trigger already prevents learners from editing these fields; extend it to freeze the new columns too.

Server functions (`src/lib/classes.admin.functions.ts`, all behind `assertAdmin`):
- `upsertEnrolment` — creates/updates an enrolment row from the dialog payload (learner, programme slug + title, level, instructor, status, payment fields), stamps `activated_by`/`activated_at`, then syncs `class_attendees` rows for the ticked session ids.
- `deleteEnrolment` — removes the enrolment and its roster rows.
- Extend `getClassesAdminData` to return enrolment payment columns so the panel can render them.
- Each action writes to `admin_audit_log` via the existing `logAction` helper.

UI:
- New `src/components/admin/EnrolmentManager.tsx` (table + add/edit dialog), mounted in `src/routes/_authenticated/admin.index.tsx` alongside the programmes panel; it reuses the sessions/profiles/programmes data already fetched there.
- Learner dashboard needs no change — it already reads `enrolments` and the shared calendar.

## Out of scope

- Online card payments or an in-app checkout.
- Learner-side receipt upload or a self-service enrolment request queue.
- Changes to the subscription/billing system, which stays separate.
