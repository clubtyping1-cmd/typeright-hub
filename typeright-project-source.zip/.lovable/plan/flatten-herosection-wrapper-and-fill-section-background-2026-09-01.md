# Flatten HeroSection wrapper and fill section background

## Goal
Remove the inner content wrapper `<div>` in `HeroSection.tsx` so the soft bubble background fills the section background directly, while keeping the two-column text/image layout intact.

## Changes
1. In `src/components/site/HeroSection.tsx`:
   - Remove the inner `<div className="relative grid ...">` at line 37.
   - Move its grid classes (`grid grid-cols-1 items-center gap-10 py-8 lg:grid-cols-2 lg:gap-16 lg:py-12`) onto the `<section>` element.
   - Move `relative overflow-hidden rounded-3xl` from the outer card `<div>` to the `<section>` element and remove the now-empty card wrapper.
   - Keep `<BubbleBackground />` as a direct child of the section so it fills the section background.
   - Reconcile vertical padding so the hero keeps its current visual spacing.

## Verification
- Run the build to confirm no JSX nesting or className errors.
- Check the live preview to confirm the bubble backdrop fills the hero section and the text/image columns remain side-by-side on desktop.
