# Remove TRT/TRS Wording from Course Content

## Goal
Replace every "TRT" and "TRS" label in the public course content with generic language, keeping only "Keyboard Mastery Programme" and "Shorthand Training Programme".

## Scope
- `src/data/courses.ts`: update course `code` field and all user-facing copy for the two programmes.
- `src/components/courses/templates/TrainerTemplate.tsx`: replace "TRT / TRS instructor status" with a generic description.
- Any other files that surface "TRT" or "TRS" to learners (to be identified during the edit).

## What will change
1. **Course codes**: remove "TRT" and "TRS" from the displayed metadata, either by clearing the `code` field or replacing it with the programme name.
2. **Taglines and descriptions**: rewrite "TRT Application" / "TRS Application" / "TRS-supported practice" etc. to "TypeRight typing platform" / "TypeRight shorthand platform" / "platform-supported practice".
3. **Pricing labels**: rename "TRT Examination / Assessment" to "Examination / Assessment" and "TRS Retake Examination" to "Retake Examination", etc.
4. **Curriculum titles**: replace "TRT Online Practice" and "TRT Examination / Assessment" with programme-neutral titles.
5. **Includes, outcomes, and requirements**: replace TRT/TRS references with generic terms.
6. **Trainer pathway copy**: replace "TRT / TRS instructor training" with "typing and shorthand instructor training".

## What stays the same
- Internal `slug` values (`keyboard-mastery-trt`, `shorthand-training-trs`) will remain unchanged to avoid breaking URLs and routing.
- The `Train-the-Trainer` course remains as a future pathway.

## Verification
After the edit, search the codebase for `TRT` and `TRS` and confirm no public-facing text remains. Check the preview on `/courses` and the two course detail pages to ensure the titles and copy read cleanly.
