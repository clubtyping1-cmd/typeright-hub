# Plan: Make Testimonials Section White

## Goal
Change the background color of the `TestimonialsSection` on the home page from dark navy to white, while preserving readability and visual hierarchy.

## Changes
1. In `src/components/services/TestimonialsSection.tsx`:
   - Change the root `<section>` background from `bg-foreground` to `bg-background`.
   - Change all `text-background` text to `text-foreground`.
   - Update translucent accents (`bg-background/10`, `bg-background/15`, `border-background/15`, `bg-background/30`) to use `foreground` equivalents so they remain visible on white.
   - Keep the `dot-texture-light` overlay if it still provides subtle texture on white; remove or adjust if it conflicts.
   - Update partner logo filter from `brightness-0 invert` (white logos) to `brightness-0` (dark logos) so they remain visible on the white background.

## Verification
- Build the project and confirm no Tailwind/CSS errors.
- Visually verify the section renders with a white background and dark text in the preview.

## Out of Scope
- No changes to testimonial copy, carousel behavior, or partner logos beyond the color/filter adjustment.
