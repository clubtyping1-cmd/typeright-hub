# Move Requirements above course content on programme detail pages

Move the `Requirements` section so it appears immediately after the title/meta block and before the course overview, phases, curriculum and other content on programme-style course pages.

## Change

In `src/components/courses/templates/ProgrammeTemplate.tsx`, relocate the existing `CourseRequirements` render from below the progress report to the first child inside the main content stack, before `CourseOverview`.

Current order:

```text
CourseOverview
CoursePhases
CourseWhatYoullLearn
CourseModuleAreas
CourseCurriculum
CourseLevelsTable
CourseAssessment
CourseProgressReport
CourseRequirements  <-- move from here
CourseReviews
```

New order:

```text
CourseRequirements  <-- to here
CourseOverview
CoursePhases
CourseWhatYoullLearn
CourseModuleAreas
CourseCurriculum
CourseLevelsTable
CourseAssessment
CourseProgressReport
CourseReviews
```

No changes to `CourseRequirements.tsx` or to `TrainerTemplate.tsx` are needed; this only reorders the section within the programme template.
