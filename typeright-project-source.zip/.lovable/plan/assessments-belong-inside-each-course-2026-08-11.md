# Assessments belong inside each course

Right now "Assessment & certification" is its own category with a standalone course page. The exam is really the final stage of each programme, so it should live inside the course it belongs to.

## What changes

1. **Remove the standalone assessment product**
   - Delete the "Typing & Shorthand Assessment" entry from the catalogue and drop the `assessment` category entirely.
   - Delete the `/courses/assessments` page and the assessment-specific page template.
   - Remove "Assessment & certification" from the Courses dropdown in the top bar (desktop and mobile) and from the category grouping on the Courses listing page.

2. **Add an assessment section to each course**
   - Each course gains its own assessment/certification details: what the exam involves, how long it takes, what to expect on the day, fees for exam and retake, and what certificate is awarded.
   - This section renders on the course detail page for every course that has one, below the curriculum.
   - Exam and retake fees stay selectable in the enrolment panel of that course (TRT and TRS already list them).

3. **Per-course content**
   - Keyboard Mastery (TRT): typing exam ~1 hour, level determination Basic to Advanced, Certificate of Achievement plus Typing Level Transcript. Exam / upgrade BND 40, retake BND 25.
   - Shorthand Training (TRS): 2-hour timed dictation and transcription, instructor marking, result confirmed in about one week, Certificate of Achievement. Exam BND 40, retake BND 25.
   - AI-Enabled Clerical and AI-Enabled Secretarial: task-based practical assessment with a Certificate of Completion (no separate exam fee).
   - Progress Reports, Institutional Training, Train-the-Trainer: no assessment section.

## Technical notes

- `src/data/courses.ts`: drop the `typing-shorthand-assessment` slug and the `"assessment"` member of the category union; add an optional `assessment` object (`summary`, `format`, `steps`, `outcomes`, optional `fees`) to the `Course` type and populate it for TRT, TRS and the two AI programmes.
- Delete `src/routes/courses.assessments.tsx` and `src/components/courses/templates/AssessmentTemplate.tsx`; remove the `category === "assessment"` branch in `src/routes/courses.$courseSlug.tsx`.
- Add `src/components/courses/CourseAssessment.tsx` and render it from the `EventbriteLayout`-based templates (Programme template at minimum) when `course.assessment` exists.
- Update `src/components/site/TopBar.tsx`, `src/routes/courses.index.tsx` (`categoryLabels`, `categoryOrder`, `categoryTo`) and any assessment-linked hero/CTA buttons to point at the relevant course instead.
- The `cover-assessment.png` asset becomes unused; leave the file, remove the import.