# Add the TRMS logo across the site

Use the uploaded TRMS mark (T/R with gear + upward arrow, MS) as the brand logo everywhere the site currently shows the plain "TypeRight." text wordmark.

## What changes

- **Header (all pages)**: the logo image sits to the left of the "TypeRight." wordmark in the top bar, sized to fit the 64px-tall header, still linking to the home page.
- **Footer**: same logo + wordmark lockup replacing the text-only link.
- **Browser tab icon**: the favicon is replaced with the new mark, so tabs and bookmarks show the logo.

Since the logo is black on white, it is shown as-is on the light theme; no colour changes to the rest of the site.

## Technical notes

- Upload `Untitled_design_1-2.png` via the assets CLI to `src/assets/trms-logo.png.asset.json` and import the pointer where needed.
- Update `src/components/site/TopBar.tsx` and `src/components/site/SiteFooter.tsx` to render `<img>` with alt text "TypeRight Management & Services logo".
- Generate a real `public/favicon.ico` from the image (favicons must be actual files, not CDN pointers); `src/routes/__root.tsx` already references `/favicon.ico`.
