# Wavy transition on the About (ServicesHero) section

## Goal
Give the `#about` section a smooth wavy edge where it meets the neighbouring sections, matching the curved divider style in the reference screenshot.

## Changes

1. **Wave divider in `src/components/services/ServicesHero.tsx`**
   - Add an inline SVG wave at the **bottom** of the section (and mirrored at the **top** if wanted for symmetry with the dark testimonials section below / hero above).
   - The wave SVG uses `fill` set to the next section's background (`var(--background)`, white) so it visually "dips" into the grey `bg-secondary/50` section — a seamless wavy transition.
   - SVG is decorative: `aria-hidden`, absolutely positioned, `pointer-events-none`, full width, height ~48–64px.
   - Add bottom padding to the section content so text/buttons never collide with the wave.

## Technical notes
- Frontend only: `src/components/services/ServicesHero.tsx`.
- No new assets; pure inline SVG path with a semantic-token fill, so dark mode stays correct.
- Top wave will be included only if it looks right against the hero above; otherwise bottom-only.
