# Remove the cart and checkout, replace with a Google Form enrolment link

Course pages will stop collecting orders in-app. Every enrolment/enquiry button will open a Google Form in a new tab instead.

## What changes for visitors

- The cart icon and cart drawer disappear from the top bar.
- On a course page, the enrolment panel keeps showing price, level and instructor info, but the button becomes "Enrol via form" (or "Request a quotation" for quotation-only items) and opens the Google Form in a new tab.
- The checkout pages and the order confirmation page are gone.
- "My orders" / receipts are removed from the dashboard.
- Subscriptions, billing and the class/exam calendar are untouched.

## Google Form link

The form URL will live in one place (`src/lib/enrolment.ts`) so it is easy to change. Selected course, level and instructor are appended as query parameters only if you later give prefill field IDs; by default the plain form URL opens.

Note: I still need the Google Form URL. Until you send it, I will wire in a clearly marked placeholder constant.

## Technical scope

Delete:
- `src/lib/cart.tsx`, `src/components/site/CartSheet.tsx`
- `src/routes/_authenticated/checkout.index.tsx`, `src/routes/_authenticated/checkout.success.$orderNumber.tsx`
- `src/components/checkout/*` (header, order summary, payment instructions, MyOrders, status badge) and `src/components/dashboard/ReceiptsPanel.tsx`
- `src/lib/orders.functions.ts`, `src/lib/orders.pricing.ts`
- Keep `src/components/checkout/PhoneInput.tsx` + `src/lib/country-codes.ts` if still referenced elsewhere; otherwise remove.

Edit:
- `src/routes/__root.tsx` — drop `CartProvider` and `CartSheet`.
- `src/components/site/TopBar.tsx` — remove cart button, badge and `useCart`.
- `src/components/courses/CourseTicketCard.tsx` — replace add-to-cart/in-cart states with a single external-link button; keep level/instructor selectors as informational choices used to build the form link.
- `src/routes/courses.$courseSlug.tsx` and `src/components/courses/templates/*` — remove cart props/state, update copy that mentions "cart".
- `src/data/courses.ts` — `ctaMode: "cart"` becomes `"form"`; `"contact"` stays for quotation items.
- `src/lib/learning.functions.ts` — drop the orders/receipts query.
- `src/routes/_authenticated/dashboard.tsx` — remove receipts/orders section (dashboard stays: my courses + calendar).

Database: leave the `orders` and `order_items` tables in place (no data destroyed); they simply stop being read or written. Say the word if you want them dropped.
