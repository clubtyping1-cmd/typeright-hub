# Point "Explore Our Services" to Courses, remove the Contact page

## What changes

1. On the home hero, the **Explore Our Services** button now goes to the Courses page instead of scrolling to a section on the same page.
2. The **Contact Us** page is removed from the site, along with every link and button that pointed to it.

## Where contact links are removed

- Top bar: "Contact Us" in the main nav and in the mobile menu
- Footer: "Contact Us" link
- Home page final CTA: "Contact TypeRight" button (the "Explore Courses" button stays)
- Home hero slideshow: the secondary "Contact an Advisor" / "Talk to Our Team" buttons on two slides
- Courses listing: "Enquire" and "Contact TypeRight" buttons
- Course category pages and course detail layout: "Contact" / "Contact TypeRight" buttons
- Type for School: "Talk to our schools team" and "Contact our schools team" buttons
- TypeRight Business: "Talk to us" and "Contact us" buttons

Where a section would be left with no action at all, the remaining primary button (Courses or the enrolment form) stays so the section still reads as a call to action.

## Technical notes

- Delete `src/routes/contact.tsx`; the route tree regenerates automatically.
- `src/components/services/ServicesHero.tsx`: replace the `<a href="#services">` primary button with `<Link to="/courses">`.
- Remove the now-unused `secondary` CTA entries and their rendering in `src/components/site/HeroSlideshow.tsx`.
- Clean up unused `Link`/`Button` imports in any file left without them.
- The contact details (email, phone, address, hours) are not relocated anywhere as part of this change.
