# Admin console: calendar only

Strip the admin console down to a single purpose — scheduling. The only thing an admin can do is manage the calendar: when each class runs and when each exam takes place.

## What gets removed

Deleted entirely (routes and their admin-only server logic):

- Overview (stats + activity log)
- Orders
- Learning (enrolments, assessments, certificates, announcements)
- Subscriptions
- Enquiries
- Users / roles

The admin console becomes one page at `/admin`, which is the calendar. The tab nav disappears (nothing left to navigate between); the header keeps the Admin badge, "My dashboard" and "Sign out".

Note: order status, subscription approval, role granting and announcements will no longer be changeable from inside the app after this. Learner-facing pages that read that data still work; the data just becomes read-only in-app.

## Calendar: classes and exams in one place

Each calendar entry gains a **type**: Class or Exam. Same form and same fields for both:

- Type (Class / Exam)
- Programme, title, trainer
- Date, start and end time
- Venue or online meeting link
- Capacity, notes

Everything already built stays: month / week / list views, create, edit, reschedule, cancel, restore, delete, learner assignment with capacity, attendance marking, and automatic notices to assigned learners when an entry changes.

Exams are visually distinguished (a badge and a distinct colour) and can be filtered in the list view.

## Learner dashboard

Assigned entries continue to appear read-only, now labelled Class or Exam, with the same cancelled / rescheduled indicators.

## Technical notes

- Database: add `session_type text not null default 'class'` to `course_sessions`, constrained to `class` | `exam`. No other schema change.
- Delete routes `admin.index.tsx`, `admin.orders.tsx`, `admin.learning.tsx`, `admin.subscriptions.tsx`, `admin.enquiries.tsx`, `admin.users.tsx`, and `src/lib/learning.admin.functions.ts`.
- Move the class calendar into `admin.index.tsx` (route `/admin`) so `/admin` lands directly on it; remove `admin.classes.tsx` and the `NAV` array in `admin.tsx`.
- Trim `src/lib/admin.functions.ts` to `amIAdmin` (plus the guard helpers still used by `classes.admin.functions.ts`); drop `getAdminOverview` and the order/user/role admin functions.
- Extend `classes.constants.ts` with `SESSION_TYPES`, and thread `sessionType` through `upsertClass`, the admin form, and the learner `SessionCalendar`.
- Point the "Admin console" link in `TopBar.tsx` at `/admin`.