# Simpler admin calendar + paid-learner portal access

## 1. Declutter the admin console

Today `/admin` stacks everything on one long page: the calendar grid, a big always-open entry form, three filter dropdowns, the roster/attendance panel, the Programmes manager and the Enrolments manager. Restructure into three clean tabs at the top:

- **Calendar** — month/week/list views only. The entry form moves out of the page into a dialog opened by a single "New entry" button (or by clicking a day cell / an existing entry). Filters collapse into one compact row.
- **Enrolments** — the existing enrolment manager, unchanged in behaviour.
- **Programmes** — the existing programme manager, unchanged in behaviour.

Calendar view details:
- Day cells show a compact chip per entry (time, title, Class/Exam tag, cancelled/rescheduled tag).
- Clicking an entry opens a single side panel with everything for that slot: details, Edit, Cancel/Reinstate, Delete, and the learner roster with attendance marking — instead of the current stacked panels.
- Create/edit uses one dialog form; no permanently visible form on the page.

No CRUD capability is removed — create, edit, reschedule, cancel, reinstate and delete all stay.

## 2. Every learner sees every scheduled class

Confirmed behaviour to keep and make obvious: any class or exam created in the admin console appears on every signed-in learner's dashboard calendar (not just assigned learners). Alongside this:
- Learner calendar shows an "Assigned to you" marker on slots the learner is booked into.
- Cancelled entries show struck through with a Cancelled tag; rescheduled ones show the new time.
- After any admin change, the learner dashboard data is refreshed so new dates appear without a manual reload.

## 3. Access to the separate typing system

Learners with an **active enrolment** get a button on that course card in their dashboard that opens the external system in a new tab (plain link, no credentials passed — that system handles its own login). Learners with no active enrolment do not see the button.

The URL lives in one place (`src/lib/enrolment.ts`) so it can be swapped for the real address in a one-line change once you provide it. Until then it keeps the current placeholder.

## Technical notes

- `src/routes/_authenticated/admin.index.tsx` is split into `src/components/admin/calendar/` parts: `CalendarToolbar`, `MonthGrid`, `WeekGrid`, `EntryList`, `EntryFormDialog`, `SlotPanel` (details + actions + roster). The route file becomes a thin shell with the three tabs and shared queries/mutations.
- No database changes and no server-function signature changes; existing `getClassesAdminData`, `upsertClass`, `cancelClass`, `restoreClass`, `deleteClass`, `assignLearner`, `unassignLearner`, `markAttendance` are reused as-is.
- Mutations continue to invalidate both `admin-classes` and `dashboard` query keys so learner calendars update immediately.
- Portal button reads `PRACTICE_PORTAL_URL` from `src/lib/enrolment.ts` and renders only when `enrolment.status === "active"`.
