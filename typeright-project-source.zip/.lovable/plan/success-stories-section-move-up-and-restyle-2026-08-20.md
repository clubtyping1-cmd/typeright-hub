# Success stories section: move up and restyle

## Goal
Move the success stories above the "What we offer" carousel and rebuild it to match the reference layout: centered intro, horizontal card row, and a partner logo strip underneath.

## Changes

1. **Reorder on the landing page (`src/routes/index.tsx`)**
   - Render `TestimonialsSection` directly after `ServicesHero`, before `ServicesCarousel`.
   - Keep the rest of the page order unchanged (carousel, gallery, CTA, footer).

2. **Redesign `src/components/services/TestimonialsSection.tsx`**
   - Centered header block:
     - Small rounded "Trusted by" pill.
     - Large centered two-line heading, e.g. "They built real skills — now it's your turn".
     - Optional single trust line under the heading (no fake review-site badges).
   - Cards in a horizontal scrolling row (same Embla setup used by `ServicesCarousel`), showing ~3 cards on desktop, 1–2 on smaller screens with edge-peek.
   - Each card: quote text, small tag chips for the programme(s), then an avatar circle with name and role at the bottom. Cards use `bg-card`, rounded corners, subtle border — no icons/quote marks in the corner.
   - Keep the existing four testimonials; tags come from the current `course` field.
   - Remove the "View all success stories" link and the per-card course link.

3. **Partner logo strip**
   - Below the cards, a centered muted row of partner logos using the two uploaded marks (IBTE, Lifelong Learning Centre), registered as CDN assets.
   - Logos rendered at consistent height with reduced opacity, brightening on hover, and descriptive alt text.

## Technical notes
- Frontend only: `src/routes/index.tsx` and `TestimonialsSection.tsx`, plus two asset pointer files in `src/assets/`.
- Reuse `embla-carousel-react` already in the project; all colors via existing semantic tokens.
