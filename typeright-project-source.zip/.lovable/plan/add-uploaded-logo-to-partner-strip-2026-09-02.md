# Add Uploaded Logo to Partner Strip

## Goal
Add the uploaded "Asyura & Aliah Management & Training Services" logo (`KEYBOARD_DESIGN-3.png`) to the partner logo strip in `TestimonialsSection.tsx`, matching the existing logo dimensions.

## Changes

1. **Create CDN asset pointer**
   - Run `lovable-assets create` against `/mnt/user-uploads/KEYBOARD_DESIGN-3.png`.
   - Save the resulting pointer to `src/assets/asyura-aliah-logo.png.asset.json`.

2. **Update `src/components/services/TestimonialsSection.tsx`**
   - Import the new asset pointer.
   - Append a new entry to the `partners` array with the new logo URL and descriptive alt text.
   - Reuse the same height classes (`h-12 sm:h-14`) and layout styles as the existing partner logos.

## Verification
- Build/typecheck passes.
- Preview shows the new logo in the partner strip at the same size as IBTE, L3C, and PPB.
