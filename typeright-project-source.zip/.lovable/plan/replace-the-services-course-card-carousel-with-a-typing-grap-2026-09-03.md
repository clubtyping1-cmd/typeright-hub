# Replace the services course-card carousel with a typing graphic

## Goal
In the "What we offer" section (`#services` on the homepage), remove the Embla course-card carousel (cards, arrows, dot navigation) and replace it with one large generated typing illustration that matches the TypeRight blue/grey style.

## Changes

1. **Generate the image**
   - Use the image generation tool to create `src/assets/typing-illustration.jpg`: a clean, premium illustration of hands typing on a keyboard with subtle speed/accuracy motifs, in the site's light grey and navy/blue palette (peach/orange accents to match the bubble backdrop).

2. **`src/components/services/ServicesCarousel.tsx`**
   - Remove the Embla carousel: `useEmblaCarousel` setup, selected-index/snap state, the scrollable card list, prev/next buttons, and dot navigation.
   - Remove now-unused imports (`useEmblaCarousel`, `useState`/`useEffect`/`useCallback` if unused, `ChevronLeft`/`ChevronRight`, `cn` if unused).
   - In the right column, render the generated illustration: full-width, rounded-2xl, subtle border/shadow, descriptive alt text, `loading="lazy"`, responsive height that balances the left intro column.
   - Keep everything else untouched: bubble backdrop, eyebrow, bold heading, description, "See Courses" pill button (still links to `/courses`), and the three circular icon badges.
   - The component's `services` prop stays in the signature but is no longer rendered (or dropped — in that case update the usage in `src/routes/index.tsx` accordingly).

## Notes
- Pure presentation change; no routing, data, or backend impact.
- Verify: build log clean + Playwright screenshot of `#services`.
