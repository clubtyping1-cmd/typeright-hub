# Fix: PPB & Asyura & Aliah partner logos not visible

## Root cause (verified by inspecting the actual image files)

1. **Asyura & Aliah logo** — the artwork only occupies a small ~600x430 area in the middle of a huge 1500x1500 transparent canvas. At the strip's logo height (~56px), the actual mark shrinks to a tiny, nearly invisible blob.
2. **PPB logo** — it's a solid square with a white/off-white background (not transparent). On the section's white background it blends in completely.

## Changes

### 1. Crop the Asyura & Aliah logo
- Trim the image to its content bounding box (with a small margin) in the sandbox, then upload the cropped file as a new asset pointer (`src/assets/asyura-aliah-logo.png.asset.json`). No code change needed — the pointer URL is imported by `TestimonialsSection.tsx` already.

### 2. Frame the partner logos in cards
In `src/components/services/TestimonialsSection.tsx`, render each partner logo inside a small rounded card instead of a bare `<img>`:
- White card with a subtle border (`border-foreground/10`), light shadow, and padding — this gives the white-background PPB logo a visible frame and a consistent "logo tile" look for all four partners.
- Keep current logo height (`h-12 sm:h-14`), remove the opacity-90 hover effect inside the card (hover now lifts the card slightly instead).

## Technical details
- New asset uploaded via `lovable-assets create`; pointer JSON written directly from CLI output.
- No other sections or routes touched.
