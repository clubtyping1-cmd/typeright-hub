# Plan: Restore Soft Bubble Backdrop in Hero Section

## Goal
Revert the hero section background from the halftone texture image back to the soft bubble backdrop, filling the whole main hero section.

## Changes

1. **Recreate `src/components/site/BubbleBackground.tsx`**
   - Renders large, softly blurred circles using the brand palette (dark blue `#1E3A8A`, peach `#FDBA74`, warm off-white accents).
   - Absolutely positioned, `aria-hidden`, pointer-events-none, placed behind content.

2. **Update `src/components/site/HeroSection.tsx`**
   - Remove the halftone texture `<img>` overlay (and the `hero-texture.jpg` import).
   - Add `<BubbleBackground />` inside the hero's rounded container so the bubbles fill the entire main hero section behind both the text column and the photo.

3. **Cleanup**
   - Delete the now-unused `src/assets/hero-texture.jpg` asset import reference (file removal optional; import removed).

## Notes
- No layout, copy, button, or routing changes.
- Bubble opacity stays low so the headline, bullets, and buttons remain readable.
