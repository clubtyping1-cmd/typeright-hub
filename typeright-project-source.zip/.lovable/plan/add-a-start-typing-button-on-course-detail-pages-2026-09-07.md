# Add a "Start typing" button on course detail pages

## Goal
Add a clearly visible **"Start typing"** button to every course detail page. For now it will link to a new dummy page nested under the course detail route.

## Plan

1. **Create the dummy page route**
   - Add `src/routes/courses.$courseSlug.start-typing.tsx`.
   - Route ID: `/courses/$courseSlug/start-typing`.
   - Render a simple placeholder page with a heading (e.g. "Start typing — coming soon"), a short sentence, and a link back to the parent course detail page.
   - Add route-specific `head()` metadata (title, description, og:title, og:description, og:type, twitter:card).

2. **Add the button on course detail pages**
   - Update `src/components/courses/templates/EventbriteLayout.tsx` so the button appears on every course detail page.
   - Place a primary **"Start typing"** button near the existing CTA area (e.g. beside "All courses" in the organiser card or near the course title/meta section).
   - Use TanStack `<Link>` with `to="/courses/$courseSlug/start-typing"` and `params={{ courseSlug: course.slug }}`.

3. **Verify**
   - Run a build/typecheck to ensure the new route is generated correctly and the `Link` path matches `FileRoutesByPath`.
   - Check the preview to confirm the button renders on a course detail page and navigates to the placeholder.
