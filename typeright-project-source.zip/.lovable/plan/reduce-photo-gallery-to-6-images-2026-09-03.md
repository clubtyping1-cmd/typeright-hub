# Reduce Photo Gallery to 6 Images

## Goal
Trim the homepage photo carousel (`PhotoGallery`) from 12 images to 6 representative classroom and community photos.

## What will change
- Edit `src/components/services/PhotoGallery.tsx`.
- Keep the 6 most representative photos:
  1. iCentre Expo demo
  2. Meeting the community
  3. Evening upskilling class
  4. Digital Shorthand cohort
  5. Guided lab practice
  6. Graduation day
- Remove the remaining 6 carousel items and their imports.
- Preserve the existing carousel layout, captions, alt text, and styling.

## Out of scope
- No changes to carousel behavior, section heading, or background styling.
- No changes to other pages or components.
