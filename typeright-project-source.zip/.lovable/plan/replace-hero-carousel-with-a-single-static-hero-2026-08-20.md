# Replace hero carousel with a single static hero

## Goal
Remove the multi-slide carousel on the landing page and replace it with a single, static hero section.

## Plan

1. **Simplify `src/components/site/HeroSlideshow.tsx`**
   - Remove the slide array, carousel state, interval timer, prev/next buttons, and pagination dots.
   - Keep the two-column layout (text left, image right) with the first slide's content as the static hero:
     - Eyebrow: "Practical typing training in Brunei"
     - Heading: "Turn Everyday Typing into a Powerful Workplace Skill"
     - Subtitle: "Build the speed, accuracy, focus, and digital confidence needed to complete emails, reports, database entries, and administrative work more efficiently."
     - Three checkmark bullets
     - Two CTAs: "Explore Our Programmes" → `/courses`, "View Pricing" → `/pricing`
     - Trust line
     - Hero image: the existing IC_2 typing classroom photo
   - Keep the accent glow and framed image styling.

2. **Rename for clarity (optional)**
   - Rename the component to `HeroSection` or keep the file as `HeroSlideshow.tsx` and export `HeroSection` as an alias, updating `src/routes/index.tsx` accordingly. Prefer renaming the component to `HeroSection` and leaving the file path unchanged to avoid churn.

3. **Update `src/routes/index.tsx`**
   - Import `HeroSection` (or keep `HeroSlideshow` if the name is preserved).
   - Render the single hero section in the same place.

4. **Verify**
   - The landing page renders a single hero without carousel controls.
   - Both CTAs remain clickable.
   - No visual regressions on mobile or desktop.

## Technical notes
- This is a frontend-only change in `src/components/site/HeroSlideshow.tsx` and `src/routes/index.tsx`.
- No route, data, or backend changes are required.
