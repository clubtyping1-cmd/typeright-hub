# Halftone dot texture on section backgrounds

Add a subtle halftone dot pattern (like the reference image) behind the landing page's flat colour bands, so the sections read as textured rather than plain fills.

## Approach

Recreate the pattern in CSS instead of embedding the reference image — it scales cleanly, stays crisp on any screen, and picks up theme colours.

1. **New utilities in `src/styles.css`**
   - `@utility dot-texture` — a repeating radial-gradient dot grid (roughly 14px spacing, ~2px dots) using `color-mix` with `--foreground` at low opacity.
   - `@utility dot-texture-fade` — same grid with a `mask-image` linear gradient so the dots fade out towards one edge, matching the density gradient in the reference.

2. **Apply to sections (as an absolutely positioned `aria-hidden` overlay under the content)**
   - `src/components/services/ServicesHero.tsx` (grey band) — dots fading from top, subtle dark dots on grey.
   - `src/components/services/PhotoGallery.tsx` (grey band) — same treatment, fading upward for rhythm.
   - `src/components/services/TestimonialsSection.tsx` and `src/components/services/CompactCTA.tsx` (dark bands) — same pattern with light dots (`--background` mixed) at low opacity.
   - White sections (hero, services carousel, footer) stay clean so the texture stays an accent, not noise.

## Notes

- Texture opacity kept low (roughly 6–10%) so headings and images remain fully legible.
- All values come from existing semantic tokens; no hardcoded colours.
- Frontend only; no content or layout changes.

## Verification

- Check the build log is clean.
- Screenshot the landing page to confirm the texture is visible but subtle on both grey and dark bands.
