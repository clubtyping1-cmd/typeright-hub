# Hero Section Redesign (Hostinger-style)

Rework the home page hero so it reads as a clean two-column marketing hero instead of the current full-bleed coloured slide with a floating white card.

## What changes

- **Layout**: left column = text, right column = image. No coloured background block behind the whole slide; the hero sits on the normal page background with generous padding.
- **Left column** (per slide):
  - Small coloured eyebrow line (accent text) replacing the "Featured" pill.
  - Large heading, tight tracking, 2 lines max on desktop.
  - Three short benefit bullets with check icons (derived from each slide's supporting copy).
  - Two buttons side by side: a solid primary CTA and an outline secondary CTA.
  - One small reassurance line under the buttons (the existing "Suitable for..." trust text, shortened).
- **Right column**: the existing slide photo in a rounded frame, with a soft accent glow behind it.
- **Slideshow behaviour kept**: same three slides, autoplay every 6s, pause on hover, dot indicators moved under the left column, arrows kept but restyled as small subtle controls.
- **Mobile**: stacks to text first, image below; buttons full width.

## Content per slide

Each slide gains three bullet points and a secondary CTA:

1. Turn Everyday Typing into a Powerful Workplace Skill — bullets on speed, accuracy, digital confidence. CTAs: Explore Our Programmes / View Pricing.
2. Prepare for Government Exams with Confidence — bullets on typing speed, shorthand, clerical competency. CTAs: See Exam Prep / Explore Our Programmes.
3. Master Digital Shorthand for Faster Note-Taking — bullets on tablet or paper, meetings and dictation, structured strokes. CTAs: Explore Shorthand / View Pricing.

## Technical notes

- Only `src/components/site/HeroSlideshow.tsx` is edited; the `Slide` type gains `eyebrow`, `bullets: string[]`, and an optional `secondary` link. The per-slide `bg` colour field is dropped.
- Uses existing semantic tokens (`background`, `foreground`, `muted-foreground`, `accent`, `border`) and the existing `Button` component — no new colours or dependencies.
- `src/routes/index.tsx` is unchanged.
