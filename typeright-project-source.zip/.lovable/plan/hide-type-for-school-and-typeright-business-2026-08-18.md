# Hide "Type for School" and "TypeRight Business"

## Goal
Remove both entries from the site navigation so visitors can no longer reach these pages from the menus, while keeping the pages themselves intact for later use.

## What will change

### `src/components/site/TopBar.tsx`
- Remove the desktop nav links to `/type-for-school` and `/business`.
- Remove the matching items from the mobile dropdown menu.
- Clean up any now-unused imports.

### Pages kept
`src/routes/type-for-school.tsx` and `src/routes/business.tsx` stay in the project, so the URLs still work if visited directly. Nothing links to them.

## Out of scope
- No content, styling, database, or other page changes.
