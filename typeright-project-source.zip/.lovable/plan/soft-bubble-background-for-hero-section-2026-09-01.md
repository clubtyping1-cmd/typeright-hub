# Soft bubble background for hero section

Add a decorative soft-bubble backdrop behind the hero section, using the requested palette of dark blue, deep midnight, warm off-white, and light peach/orange.

## Approach

1. **Extend the design tokens in `src/styles.css`**
   - Add four new semantic color variables (converted to oklch):
     - `--bubble-dark-blue`: #1E3A8A
     - `--bubble-midnight`: #0B1220
     - `--bubble-cream`: #FFF7ED
     - `--bubble-peach`: #FDBA74
   - Register them in `@theme inline` so Tailwind utilities like `bg-bubble-dark-blue` work.

2. **Create a reusable `BubbleBackground` component**
   - `src/components/site/BubbleBackground.tsx`
   - Renders several absolutely positioned, large blurred circles/ellipses behind content.
   - Uses the new bubble tokens plus `opacity` and `blur` to keep the effect subtle (subtlety 5/10).
   - Circles vary in size and position so the composition feels organic, not repetitive.
   - `aria-hidden` and `pointer-events-none` so it does not interfere with content.

3. **Apply to `src/components/site/HeroSection.tsx`**
   - Wrap the existing hero content in a relative container.
   - Place `<BubbleBackground />` as the bottom layer inside the wrapper.
   - Keep the existing image glow (`bg-accent/10 blur-2xl`) or replace it with a bubble cluster that complements the new palette.
   - Ensure text remains fully legible: bubbles sit behind content, low opacity, large blur radius.

## Notes

- No layout or copy changes to the hero itself — only the decorative background layer.
- Responsive: bubbles scale down on smaller viewports and avoid overlapping the hero image's focal point.
- All colors live in the design system; no hardcoded hex classes in components.

## Verification

- Run a build/typecheck to confirm new tokens compile.
- Screenshot the hero section to confirm bubbles are visible but do not reduce readability of the headline, bullets, or image.