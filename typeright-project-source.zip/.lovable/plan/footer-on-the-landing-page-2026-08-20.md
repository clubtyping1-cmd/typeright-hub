# Footer on the landing page

## Goal
Show a proper site footer at the bottom of the home page, listing only pages that are actually live and linked in the site navigation.

## What exists today
`src/components/site/SiteFooter.tsx` exists but is not rendered on the home page, and it only links Home, Courses and About.

## What will change

### `src/components/site/SiteFooter.tsx`
Rebuild into a fuller, responsive footer with three areas:
- Brand column: TRMS logo, one-line description of TypeRight Hub.
- Explore column (only pages currently reachable from the top bar): Home, Courses, Core programmes, About, News, Pricing.
- Account column: Log in, Sign up.
- Bottom bar: copyright line.

Excluded on purpose because they are hidden or removed from the site: Type for School, TypeRight Business, Train-the-Trainer, Contact, Dashboard/Billing.

### `src/routes/index.tsx`
Render `<SiteFooter />` as the last element of the landing page.

## Styling
Uses existing design tokens (`bg-background`, `border-border`, `text-muted-foreground`, `text-accent`) so it matches the light-grey / blue theme. No new colours or dependencies.

## Out of scope
No changes to other pages, content, or backend.
