# Class Calendar Management

Adds a full class scheduling system to the Admin console, with learner-specific class listings on the dashboard.

## Admin: Classes

New tab `Admin -> Classes`, behind the existing admin-only role gate.

Create / edit a class with:
- Programme (course), class title, trainer
- Date, start time, end time
- Mode: onsite (venue) or online (meeting link)
- Capacity and notes
- Status: scheduled, rescheduled, cancelled

Actions: edit, reschedule (change date/time; marks the class rescheduled), cancel (keeps the record, marks it cancelled with a reason), delete.

Views: **Month** grid, **Week** grid, and a **List** view with filters by programme, trainer and status.

Per-class roster panel:
- Assign learners picked from the people enrolled in that programme
- Shows "X of Y seats filled" and blocks assigning beyond capacity
- Attendance marking per learner: present, absent, late, excused

## Learner dashboard

The calendar switches from "any session for my programmes" to "classes I'm assigned to":
- Upcoming assigned classes only, showing programme, date, time, venue or join link, trainer and status
- Cancelled classes shown struck through with a clear Cancelled tag; rescheduled ones tagged with the new time
- Fully read-only for learners
- A "Schedule updates" list surfaces recent change notices

## Notifications

When an assigned class is rescheduled or cancelled, a notice is written for every assigned learner and shows on their dashboard. In-app only; no email sending in this change.

## Technical notes

Database migration:
- `course_sessions` gains `capacity int`, `status text` (scheduled/rescheduled/cancelled), `cancellation_reason text`, `original_starts_at timestamptz`.
- New `class_attendees` table: `session_id`, `user_id`, `enrolment_id`, `attendance_status` (unmarked/present/absent/late/excused), `marked_at`, unique on (session_id, user_id). GRANTs for `authenticated` and `service_role`; RLS so learners read only their own rows and admins/instructors manage all.
- `course_sessions` RLS: add a learner SELECT policy scoped to sessions they are assigned to, keeping existing admin write policies.
- Change notices reuse the existing `notifications` table with `type = 'class_update'`.

Server functions:
- New `src/lib/classes.admin.functions.ts` — list classes with attendee counts, upsert / reschedule / cancel / delete, list eligible learners per programme, assign / unassign, mark attendance. All behind `requireSupabaseAuth` + `assertAdmin`, with `logAction` audit entries.
- `getDashboard` in `src/lib/learning.functions.ts` — sessions query joins `class_attendees` for the signed-in user and returns class status plus recent `class_update` notifications.

UI:
- `src/routes/_authenticated/admin.classes.tsx` plus components under `src/components/admin/classes/` (month/week/list views, class form dialog, roster and attendance panel).
- `src/components/dashboard/SessionCalendar.tsx` updated for status badges and assigned-only, read-only classes; new schedule-updates list on the dashboard.
- Mutations invalidate the dashboard and admin class queries so both views refresh immediately after a change.