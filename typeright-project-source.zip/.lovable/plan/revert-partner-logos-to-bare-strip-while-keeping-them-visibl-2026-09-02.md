# Revert partner logos to bare strip while keeping them visible

## Goal
Restore the partner logo strip in `TestimonialsSection.tsx` to the previous layout (logos displayed inline without card frames), while ensuring the PPB and Asyura & Aliah logos remain easy to see on the white background.

## Changes

### 1. Remove the card frames
In `src/components/services/TestimonialsSection.tsx`, replace the current card-wrapped logo markup with the previous bare inline layout:
- Remove the `rounded-xl border border-foreground/10 bg-card px-6 py-4 shadow-sm` wrapper.
- Render each logo as a direct `<img>` inside the flex container with the existing partner gap.

### 2. Keep the cropped Asyura & Aliah logo
- The already-cropped asset at `src/assets/asyura-aliah-logo.png.asset.json` stays as-is so the artwork renders at the correct size.

### 3. Ensure visibility without frames
- Apply a subtle drop shadow (`drop-shadow-sm` or `shadow-sm`) directly to each logo image so the white-background PPB logo has visible edges against the white section.
- Keep logos in full color (no invert/brightness filters).
- Maintain the current height classes (`h-12 sm:h-14`) so the strip matches the surrounding scale.

## Out of scope
- No changes to other sections or routes.
- No new assets or uploads.
