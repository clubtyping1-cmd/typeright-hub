Remove buttons from the pricing cards

1. Remove the button block at the bottom of each pricing card in `src/routes/pricing.tsx` (currently lines 199-210). This includes removing the "Current plan", "Teams quotation", and "Sign up via form" buttons.

2. Remove the related current-plan logic that is only used to decide the button state:
   - `mySubscription` import and server function call
   - `isSignedIn` state and `useEffect` calling `supabase.auth.getUser()`
   - `useQuery` for the user's subscription
   - `currentPlanCode` and `isCurrent` variables

3. Remove now-unused imports: `Button`, `Link`, `useServerFn`, `ENROLMENT_FORM_URL`, and `mySubscription`.

4. Verify that the page still compiles and that the remaining interval toggle, plan cards, and FAQ section render correctly without buttons.
