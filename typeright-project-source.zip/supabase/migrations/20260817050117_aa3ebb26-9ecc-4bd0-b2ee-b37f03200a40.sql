CREATE TABLE public.badges (
  code text PRIMARY KEY,
  label text NOT NULL,
  description text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.badges TO authenticated;
GRANT ALL ON public.badges TO service_role;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "badges_read_authenticated" ON public.badges FOR SELECT TO authenticated USING (true);
CREATE POLICY "badges_admin_manage" ON public.badges FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.badges (code, label, description, sort_order) VALUES
  ('new_learner','New Learner','Joined TypeRight Hub and started the journey.',1),
  ('active_learner','Active Learner','Attending classes and practising consistently.',2),
  ('course_completed','Course Completed','Finished a full TypeRight programme.',3),
  ('assessment_passed','Assessment Passed','Passed a TypeRight assessment.',4),
  ('certified_learner','Certified Learner','Awarded an official TypeRight certificate.',5),
  ('perfect_attendance','Perfect Attendance','Attended every scheduled class.',6),
  ('most_improved','Most Improved','Showed outstanding progress over time.',7),
  ('top_performer','Top Performer','Among the highest scorers in the cohort.',8),
  ('keyboard_master','Keyboard Master','Mastered speed and accuracy on the keyboard.',9),
  ('shorthand_master','Shorthand Master','Mastered digital shorthand techniques.',10),
  ('ai_skills_champion','AI Skills Champion','Excelled in AI literacy and applied AI skills.',11),
  ('future_trainer','Future Trainer','On the pathway to becoming a TypeRight trainer.',12);

CREATE TABLE public.learner_levels (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  level integer NOT NULL DEFAULT 1,
  level_name text NOT NULL DEFAULT 'Beginner',
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.learner_levels TO authenticated;
GRANT ALL ON public.learner_levels TO service_role;
ALTER TABLE public.learner_levels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "learner_levels_read_own" ON public.learner_levels FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "learner_levels_admin_all" ON public.learner_levels FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.learner_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_code text NOT NULL REFERENCES public.badges(code) ON DELETE CASCADE,
  awarded_by uuid,
  awarded_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, badge_code)
);
GRANT SELECT ON public.learner_badges TO authenticated;
GRANT ALL ON public.learner_badges TO service_role;
ALTER TABLE public.learner_badges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "learner_badges_read_own" ON public.learner_badges FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "learner_badges_admin_all" ON public.learner_badges FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));