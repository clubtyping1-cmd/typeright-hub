
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'org_admin';

CREATE TABLE public.subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  kind text NOT NULL DEFAULT 'individual',
  cta_label text NOT NULL DEFAULT 'Subscribe',
  is_active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT plan_kind_check CHECK (kind IN ('individual','team'))
);
GRANT SELECT ON public.subscription_plans TO anon, authenticated;
GRANT ALL ON public.subscription_plans TO service_role;
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "plans public read" ON public.subscription_plans FOR SELECT USING (is_active OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "plans admin write" ON public.subscription_plans FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_plans_updated BEFORE UPDATE ON public.subscription_plans FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.plan_prices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id) ON DELETE CASCADE,
  interval text NOT NULL,
  amount_bnd numeric(10,2),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT interval_check CHECK (interval IN ('weekly','monthly','annual','custom')),
  UNIQUE (plan_id, interval)
);
CREATE INDEX plan_prices_plan_idx ON public.plan_prices(plan_id);
GRANT SELECT ON public.plan_prices TO anon, authenticated;
GRANT ALL ON public.plan_prices TO service_role;
ALTER TABLE public.plan_prices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "prices public read" ON public.plan_prices FOR SELECT USING (true);
CREATE POLICY "prices admin write" ON public.plan_prices FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_prices_updated BEFORE UPDATE ON public.plan_prices FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.entitlements (
  code text PRIMARY KEY,
  description text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.entitlements TO anon, authenticated;
GRANT ALL ON public.entitlements TO service_role;
ALTER TABLE public.entitlements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "entitlements public read" ON public.entitlements FOR SELECT USING (true);
CREATE POLICY "entitlements admin write" ON public.entitlements FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.plan_entitlements (
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id) ON DELETE CASCADE,
  entitlement_code text NOT NULL REFERENCES public.entitlements(code) ON DELETE CASCADE,
  PRIMARY KEY (plan_id, entitlement_code)
);
GRANT SELECT ON public.plan_entitlements TO anon, authenticated;
GRANT ALL ON public.plan_entitlements TO service_role;
ALTER TABLE public.plan_entitlements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "plan_ent public read" ON public.plan_entitlements FOR SELECT USING (true);
CREATE POLICY "plan_ent admin write" ON public.plan_entitlements FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.organisations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_email text,
  contact_phone text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organisations TO authenticated;
GRANT ALL ON public.organisations TO service_role;
ALTER TABLE public.organisations ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_orgs_updated BEFORE UPDATE ON public.organisations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.organisation_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organisation_id uuid NOT NULL REFERENCES public.organisations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  member_role text NOT NULL DEFAULT 'learner',
  status text NOT NULL DEFAULT 'active',
  invited_email text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (organisation_id, user_id),
  CONSTRAINT org_member_role_check CHECK (member_role IN ('org_admin','learner')),
  CONSTRAINT org_member_status_check CHECK (status IN ('active','suspended','removed'))
);
CREATE INDEX org_members_org_idx ON public.organisation_members(organisation_id);
CREATE INDEX org_members_user_idx ON public.organisation_members(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organisation_members TO authenticated;
GRANT ALL ON public.organisation_members TO service_role;
ALTER TABLE public.organisation_members ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_org_members_updated BEFORE UPDATE ON public.organisation_members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.is_org_admin(_user_id uuid, _org_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.organisation_members
    WHERE user_id = _user_id AND organisation_id = _org_id
      AND member_role = 'org_admin' AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.my_org_ids(_user_id uuid)
RETURNS TABLE(organisation_id uuid) LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT organisation_id FROM public.organisation_members
  WHERE user_id = _user_id AND status = 'active';
$$;

CREATE POLICY "orgs admin all" ON public.organisations FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "orgs members read" ON public.organisations FOR SELECT TO authenticated USING (id IN (SELECT organisation_id FROM public.my_org_ids(auth.uid())));
CREATE POLICY "orgs org_admin update" ON public.organisations FOR UPDATE TO authenticated USING (public.is_org_admin(auth.uid(), id)) WITH CHECK (public.is_org_admin(auth.uid(), id));

CREATE POLICY "org_members admin all" ON public.organisation_members FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "org_members self read" ON public.organisation_members FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "org_members org_admin read" ON public.organisation_members FOR SELECT TO authenticated USING (public.is_org_admin(auth.uid(), organisation_id));
CREATE POLICY "org_members org_admin insert" ON public.organisation_members FOR INSERT TO authenticated WITH CHECK (public.is_org_admin(auth.uid(), organisation_id));
CREATE POLICY "org_members org_admin update" ON public.organisation_members FOR UPDATE TO authenticated USING (public.is_org_admin(auth.uid(), organisation_id)) WITH CHECK (public.is_org_admin(auth.uid(), organisation_id));
CREATE POLICY "org_members org_admin delete" ON public.organisation_members FOR DELETE TO authenticated USING (public.is_org_admin(auth.uid(), organisation_id));

CREATE TABLE public.organisation_licences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organisation_id uuid NOT NULL REFERENCES public.organisations(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id),
  seats_total int NOT NULL DEFAULT 0,
  starts_at timestamptz,
  ends_at timestamptz,
  status text NOT NULL DEFAULT 'active',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT licence_status_check CHECK (status IN ('active','expired','cancelled'))
);
CREATE INDEX org_licences_org_idx ON public.organisation_licences(organisation_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organisation_licences TO authenticated;
GRANT ALL ON public.organisation_licences TO service_role;
ALTER TABLE public.organisation_licences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "licences admin all" ON public.organisation_licences FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "licences org read" ON public.organisation_licences FOR SELECT TO authenticated USING (organisation_id IN (SELECT organisation_id FROM public.my_org_ids(auth.uid())));
CREATE TRIGGER trg_licences_updated BEFORE UPDATE ON public.organisation_licences FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.organisation_licence_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  licence_id uuid NOT NULL REFERENCES public.organisation_licences(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz,
  UNIQUE (licence_id, user_id)
);
CREATE INDEX licence_assign_user_idx ON public.organisation_licence_assignments(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organisation_licence_assignments TO authenticated;
GRANT ALL ON public.organisation_licence_assignments TO service_role;
ALTER TABLE public.organisation_licence_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "lassign admin all" ON public.organisation_licence_assignments FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "lassign self read" ON public.organisation_licence_assignments FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "lassign org_admin read" ON public.organisation_licence_assignments FOR SELECT TO authenticated USING (licence_id IN (SELECT l.id FROM public.organisation_licences l WHERE public.is_org_admin(auth.uid(), l.organisation_id)));
CREATE POLICY "lassign org_admin insert" ON public.organisation_licence_assignments FOR INSERT TO authenticated WITH CHECK (licence_id IN (SELECT l.id FROM public.organisation_licences l WHERE public.is_org_admin(auth.uid(), l.organisation_id)));
CREATE POLICY "lassign org_admin delete" ON public.organisation_licence_assignments FOR DELETE TO authenticated USING (licence_id IN (SELECT l.id FROM public.organisation_licences l WHERE public.is_org_admin(auth.uid(), l.organisation_id)));

CREATE TABLE public.organisation_enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organisation_name text NOT NULL,
  contact_name text NOT NULL,
  contact_email text NOT NULL,
  contact_phone text,
  seats int,
  plan_interest text,
  notes text,
  status text NOT NULL DEFAULT 'new',
  handled_by uuid REFERENCES auth.users(id),
  handled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT enquiry_status_check CHECK (status IN ('new','contacted','quoted','converted','closed'))
);
GRANT INSERT ON public.organisation_enquiries TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON public.organisation_enquiries TO authenticated;
GRANT ALL ON public.organisation_enquiries TO service_role;
ALTER TABLE public.organisation_enquiries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "enquiries public submit" ON public.organisation_enquiries FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "enquiries admin read" ON public.organisation_enquiries FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "enquiries admin write" ON public.organisation_enquiries FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "enquiries admin delete" ON public.organisation_enquiries FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_enquiries_updated BEFORE UPDATE ON public.organisation_enquiries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES public.subscription_plans(id),
  price_id uuid REFERENCES public.plan_prices(id),
  organisation_id uuid REFERENCES public.organisations(id),
  status text NOT NULL DEFAULT 'pending_payment',
  current_period_start timestamptz,
  current_period_end timestamptz,
  grace_until timestamptz,
  activated_at timestamptz,
  cancelled_at timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT sub_status_check CHECK (status IN ('pending_payment','trial','active','past_due','grace','paused','cancelled','expired','suspended'))
);
CREATE INDEX subs_user_idx ON public.subscriptions(user_id);
CREATE INDEX subs_status_idx ON public.subscriptions(status);
CREATE INDEX subs_period_end_idx ON public.subscriptions(current_period_end);
GRANT SELECT, INSERT, UPDATE ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "subs self read" ON public.subscriptions FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "subs self insert" ON public.subscriptions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "subs self cancel" ON public.subscriptions FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "subs admin all" ON public.subscriptions FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_subs_updated BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.subscription_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid NOT NULL REFERENCES public.subscriptions(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  from_status text,
  to_status text,
  actor_id uuid,
  notes text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sub_events_sub_idx ON public.subscription_events(subscription_id);
GRANT SELECT, INSERT ON public.subscription_events TO authenticated;
GRANT ALL ON public.subscription_events TO service_role;
ALTER TABLE public.subscription_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sub_events self read" ON public.subscription_events FOR SELECT TO authenticated USING (subscription_id IN (SELECT id FROM public.subscriptions WHERE user_id = auth.uid()));
CREATE POLICY "sub_events admin all" ON public.subscription_events FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.subscription_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid NOT NULL REFERENCES public.subscriptions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount_bnd numeric(10,2) NOT NULL,
  currency text NOT NULL DEFAULT 'BND',
  method text NOT NULL DEFAULT 'bank_transfer',
  status text NOT NULL DEFAULT 'pending_verification',
  reference text,
  proof_path text,
  billing_period_start timestamptz,
  billing_period_end timestamptz,
  approved_by uuid REFERENCES auth.users(id),
  approved_at timestamptz,
  rejected_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT pay_method_check CHECK (method IN ('bank_transfer','manual','online')),
  CONSTRAINT pay_status_check CHECK (status IN ('pending_verification','approved','rejected','refunded'))
);
CREATE INDEX sub_pay_user_idx ON public.subscription_payments(user_id);
CREATE INDEX sub_pay_sub_idx ON public.subscription_payments(subscription_id);
GRANT SELECT, INSERT, UPDATE ON public.subscription_payments TO authenticated;
GRANT ALL ON public.subscription_payments TO service_role;
ALTER TABLE public.subscription_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pay self read" ON public.subscription_payments FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "pay self insert" ON public.subscription_payments FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "pay self update proof" ON public.subscription_payments FOR UPDATE TO authenticated USING (user_id = auth.uid() AND status = 'pending_verification') WITH CHECK (user_id = auth.uid());
CREATE POLICY "pay admin all" ON public.subscription_payments FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_sub_pay_updated BEFORE UPDATE ON public.subscription_payments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.promo_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  description text,
  discount_percent int,
  discount_amount_bnd numeric(10,2),
  applies_to_plan_id uuid REFERENCES public.subscription_plans(id),
  max_redemptions int,
  redeemed_count int NOT NULL DEFAULT 0,
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.promo_codes TO authenticated;
GRANT ALL ON public.promo_codes TO service_role;
ALTER TABLE public.promo_codes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "promo read" ON public.promo_codes FOR SELECT TO authenticated USING (is_active);
CREATE POLICY "promo admin write" ON public.promo_codes FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_promo_updated BEFORE UPDATE ON public.promo_codes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.promo_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  promo_id uuid NOT NULL REFERENCES public.promo_codes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  subscription_id uuid REFERENCES public.subscriptions(id) ON DELETE SET NULL,
  amount_bnd numeric(10,2),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.promo_redemptions TO authenticated;
GRANT ALL ON public.promo_redemptions TO service_role;
ALTER TABLE public.promo_redemptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "promo_red self read" ON public.promo_redemptions FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "promo_red admin all" ON public.promo_redemptions FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "promo_red self insert" ON public.promo_redemptions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON public.notifications(user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif self read" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notif self update" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "notif admin all" ON public.notifications FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.has_entitlement(_user_id uuid, _code text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.subscriptions s
    JOIN public.plan_entitlements pe ON pe.plan_id = s.plan_id
    WHERE s.user_id = _user_id
      AND pe.entitlement_code = _code
      AND s.status IN ('active','trial','grace')
      AND (s.current_period_end IS NULL OR s.current_period_end > now())
  ) OR EXISTS (
    SELECT 1
    FROM public.organisation_licence_assignments a
    JOIN public.organisation_licences l ON l.id = a.licence_id
    JOIN public.plan_entitlements pe ON pe.plan_id = l.plan_id
    WHERE a.user_id = _user_id
      AND a.revoked_at IS NULL
      AND l.status = 'active'
      AND pe.entitlement_code = _code
      AND (l.ends_at IS NULL OR l.ends_at > now())
  );
$$;

INSERT INTO public.entitlements (code, description) VALUES
  ('trt_full_access','Full access to TRT Digital Typing practice application'),
  ('trs_full_access','Full access to TRS Digital Shorthand practice application'),
  ('trt_preview','Limited TRT preview access'),
  ('trs_preview','Limited TRS preview access'),
  ('advanced_progress','Advanced progress analytics and history'),
  ('monthly_summary','Monthly practice summary report'),
  ('organisation_reporting','Organisation-level reporting and dashboards'),
  ('priority_registration','Priority course and assessment registration'),
  ('subscriber_discount','Subscriber discount on selected separate purchases');

INSERT INTO public.subscription_plans (code, name, description, kind, cta_label, sort_order) VALUES
  ('trt','TRT Practice','Continuous access to the TRT Digital Typing practice application, structured passages, timed exercises and WPM tracking.','individual','Start TRT Practice',1),
  ('trs','TRS Practice','Continuous access to the TRS Digital Shorthand practice application, dictations, transcription drills and speed building.','individual','Start TRS Practice',2),
  ('complete','Complete Practice','Everything in TRT and TRS Practice, combined dashboard, monthly summaries and subscriber perks.','individual','Get Complete Access',3),
  ('teams','TypeRight Teams','Multi-learner licences, organisation dashboards, reporting and centralised billing for schools, ministries and companies.','team','Request a Quotation',4);

INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'weekly', 15 FROM public.subscription_plans WHERE code = 'trt';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'monthly', 50 FROM public.subscription_plans WHERE code = 'trt';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'annual', 500 FROM public.subscription_plans WHERE code = 'trt';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'weekly', 15 FROM public.subscription_plans WHERE code = 'trs';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'monthly', 50 FROM public.subscription_plans WHERE code = 'trs';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'annual', 500 FROM public.subscription_plans WHERE code = 'trs';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'monthly', 90 FROM public.subscription_plans WHERE code = 'complete';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'annual', 900 FROM public.subscription_plans WHERE code = 'complete';
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd) SELECT id, 'custom', NULL FROM public.subscription_plans WHERE code = 'teams';

INSERT INTO public.plan_entitlements (plan_id, entitlement_code)
SELECT p.id, e.code FROM public.subscription_plans p, public.entitlements e
WHERE (p.code = 'trt'      AND e.code IN ('trt_full_access','trt_preview'))
   OR (p.code = 'trs'      AND e.code IN ('trs_full_access','trs_preview'))
   OR (p.code = 'complete' AND e.code IN ('trt_full_access','trs_full_access','trt_preview','trs_preview','advanced_progress','monthly_summary','priority_registration','subscriber_discount'))
   OR (p.code = 'teams'    AND e.code IN ('trt_full_access','trs_full_access','organisation_reporting','advanced_progress','monthly_summary'));

CREATE POLICY "proofs uploader read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-proofs' AND owner = auth.uid());
CREATE POLICY "proofs admin read" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'payment-proofs' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "proofs uploader insert" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'payment-proofs' AND owner = auth.uid());
CREATE POLICY "proofs uploader delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'payment-proofs' AND owner = auth.uid());
