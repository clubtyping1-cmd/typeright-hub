CREATE TABLE public.news_posts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  excerpt text,
  body text,
  category text NOT NULL DEFAULT 'Announcement',
  cover_url text,
  author text NOT NULL DEFAULT 'TypeRight Hub',
  published_at timestamp with time zone NOT NULL DEFAULT now(),
  is_published boolean NOT NULL DEFAULT false,
  created_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.news_posts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.news_posts TO authenticated;
GRANT ALL ON public.news_posts TO service_role;

ALTER TABLE public.news_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read published news"
ON public.news_posts FOR SELECT
USING (is_published = true);

CREATE POLICY "Admins read all news"
ON public.news_posts FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins manage news"
ON public.news_posts FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER news_posts_updated_at BEFORE UPDATE ON public.news_posts
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX news_posts_published_idx ON public.news_posts (is_published, published_at DESC);

INSERT INTO public.news_posts (slug, title, excerpt, body, category, author, published_at, is_published) VALUES
('ai-literacy-programme-opens-enrolment-q3-2026',
 'AI Literacy programme opens enrolment for Q3 2026',
 'Our workplace AI course now accepts learners for the July–September intake, with new modules on Copilot for Office 365.',
 E'Bandar Seri Begawan – TypeRight Hub has opened enrolment for the Q3 2026 intake of the AI Literacy for the Workplace programme.\n\nThe July–September intake introduces new modules covering Microsoft Copilot for Office 365, prompt writing for clerical tasks, and responsible use of AI tools in government and corporate offices.\n\nPlaces are limited and allocated on a first-come basis. Learners may enrol through the official enrolment form.',
 'Announcement', 'TypeRight Hub', '2026-07-24T02:00:00Z', true),
('secretarial-services-examination-preparation-schedule',
 'Secretarial Services Examination preparation schedule',
 'Updated preparation schedule and practice sessions for the upcoming government examination cycle.',
 E'TypeRight Hub has published the updated preparation schedule for the Secretarial Services Examination cycle.\n\nThe schedule includes weekly practice sessions, timed typing benchmarks and shorthand dictation drills. Learners enrolled in the TRS programme will see their assigned sessions on the dashboard calendar.',
 'Examinations', 'TypeRight Hub', '2026-07-10T02:00:00Z', true),
('digital-shorthand-now-available-in-malay',
 'Digital Shorthand now available in Malay',
 'TypeRight''s shorthand programme has expanded with a full Malay track, complementing the existing English curriculum.',
 E'TypeRight Hub has expanded its Digital Shorthand programme with a complete Malay-language track.\n\nThe new track mirrors the English curriculum across all levels, from foundation outlines to advanced dictation speeds, and is delivered by trainers experienced in bilingual clerical practice.',
 'Programme update', 'TypeRight Hub', '2026-06-28T02:00:00Z', true),
('new-workforce-training-partnership-announced',
 'New workforce training partnership announced',
 'TypeRight is partnering with local organisations to deliver on-site clerical and AI training programmes.',
 E'TypeRight Hub has announced new partnerships with local organisations to deliver on-site clerical and AI training.\n\nThe partnerships allow organisations to run tailored typing, shorthand and AI literacy sessions at their own premises, with progress reporting for supervisors.',
 'Partnership', 'TypeRight Hub', '2026-06-12T02:00:00Z', true),
('open-day-for-students-and-jobseekers',
 'Open day for students and jobseekers',
 'Join us for a free open day showcasing our digital learning systems and career pathways.',
 E'TypeRight Hub is hosting a free open day for students and jobseekers.\n\nVisitors can try the digital typing and shorthand practice systems, meet trainers, and learn about career pathways in clerical, secretarial and AI-enabled administrative roles.',
 'Community', 'TypeRight Hub', '2026-06-01T02:00:00Z', true);