BEGIN;

-- Allow daily pricing
ALTER TABLE public.plan_prices
  DROP CONSTRAINT IF EXISTS interval_check;
ALTER TABLE public.plan_prices
  ADD CONSTRAINT interval_check CHECK (interval IN ('daily','weekly','monthly','annual','custom'));

-- Deactivate the Teams plan and its custom price
UPDATE public.plan_prices
SET is_active = false
WHERE interval = 'custom'
  AND plan_id IN (SELECT id FROM public.subscription_plans WHERE code = 'teams');

UPDATE public.subscription_plans
SET is_active = false
WHERE code = 'teams';

-- Remove annual prices for individual plans
DELETE FROM public.plan_prices
WHERE interval = 'annual'
  AND plan_id IN (SELECT id FROM public.subscription_plans WHERE code IN ('trt','trs','complete'));

-- Ensure daily prices exist for individual plans
INSERT INTO public.plan_prices (plan_id, interval, amount_bnd)
SELECT id, 'daily', 2
FROM public.subscription_plans
WHERE code IN ('trt','trs','complete')
ON CONFLICT (plan_id, interval) DO UPDATE
  SET amount_bnd = 2, is_active = true;

-- Set weekly and monthly prices for individual plans
UPDATE public.plan_prices
SET amount_bnd = 10, is_active = true
WHERE interval = 'weekly'
  AND plan_id IN (SELECT id FROM public.subscription_plans WHERE code IN ('trt','trs','complete'));

UPDATE public.plan_prices
SET amount_bnd = 35, is_active = true
WHERE interval = 'monthly'
  AND plan_id IN (SELECT id FROM public.subscription_plans WHERE code IN ('trt','trs','complete'));

COMMIT;