GRANT SELECT ON public.subscription_plans TO anon, authenticated;
GRANT SELECT ON public.plan_prices TO anon, authenticated;
GRANT SELECT ON public.plan_entitlements TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.subscription_plans TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.plan_prices TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.plan_entitlements TO authenticated;
GRANT ALL ON public.subscription_plans TO service_role;
GRANT ALL ON public.plan_prices TO service_role;
GRANT ALL ON public.plan_entitlements TO service_role;