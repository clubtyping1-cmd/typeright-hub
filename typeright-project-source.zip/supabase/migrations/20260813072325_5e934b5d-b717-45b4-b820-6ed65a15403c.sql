-- 1) plan_prices: restrict public read to active prices only
DROP POLICY IF EXISTS "prices public read" ON public.plan_prices;
CREATE POLICY "prices public read active" ON public.plan_prices
  FOR SELECT TO anon, authenticated
  USING (is_active = true);

-- 2) Lock down SECURITY DEFINER functions exposed through the API
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.guard_enrolment_learner_update() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_org_admin(uuid, uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.my_org_ids(uuid) FROM PUBLIC, anon, authenticated;

-- Keep role/entitlement checks callable by signed-in users only
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_entitlement(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_entitlement(uuid, text) TO authenticated;

GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.has_entitlement(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.is_org_admin(uuid, uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.my_org_ids(uuid) TO service_role;