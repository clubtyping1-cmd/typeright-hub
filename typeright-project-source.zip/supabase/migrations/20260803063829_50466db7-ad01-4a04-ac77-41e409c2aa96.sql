-- ANNOUNCEMENTS
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  audience text NOT NULL DEFAULT 'all',
  link_url text,
  published_at timestamptz NOT NULL DEFAULT now(),
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.announcements TO authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in users read active announcements" ON public.announcements
  FOR SELECT TO authenticated USING (is_active AND published_at <= now());
CREATE POLICY "Admins manage announcements" ON public.announcements
  FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER announcements_updated_at BEFORE UPDATE ON public.announcements
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ENROLMENTS
CREATE TABLE public.enrolments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_slug text NOT NULL,
  title text NOT NULL,
  level_name text,
  instructor_name text,
  status text NOT NULL DEFAULT 'active',
  progress_percent integer NOT NULL DEFAULT 0,
  next_lesson_title text,
  source_order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  last_accessed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, course_slug, level_name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.enrolments TO authenticated;
GRANT ALL ON public.enrolments TO service_role;
ALTER TABLE public.enrolments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own enrolments" ON public.enrolments
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE POLICY "Learners touch own last access" ON public.enrolments
  FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Staff manage enrolments" ON public.enrolments
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE TRIGGER enrolments_updated_at BEFORE UPDATE ON public.enrolments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Guard: learners may only change last_accessed_at on their own rows
CREATE OR REPLACE FUNCTION public.guard_enrolment_learner_update()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor') THEN
    RETURN NEW;
  END IF;
  NEW.course_slug := OLD.course_slug;
  NEW.title := OLD.title;
  NEW.level_name := OLD.level_name;
  NEW.instructor_name := OLD.instructor_name;
  NEW.status := OLD.status;
  NEW.progress_percent := OLD.progress_percent;
  NEW.next_lesson_title := OLD.next_lesson_title;
  NEW.completed_at := OLD.completed_at;
  NEW.user_id := OLD.user_id;
  RETURN NEW;
END;
$$;
CREATE TRIGGER enrolments_guard_learner BEFORE UPDATE ON public.enrolments
  FOR EACH ROW EXECUTE FUNCTION public.guard_enrolment_learner_update();

-- COURSE SESSIONS
CREATE TABLE public.course_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_slug text NOT NULL,
  title text NOT NULL,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz,
  mode text NOT NULL DEFAULT 'onsite',
  location text,
  join_url text,
  instructor_name text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.course_sessions TO authenticated;
GRANT ALL ON public.course_sessions TO service_role;
ALTER TABLE public.course_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in users read sessions" ON public.course_sessions
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff manage sessions" ON public.course_sessions
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE TRIGGER course_sessions_updated_at BEFORE UPDATE ON public.course_sessions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ASSESSMENT ATTEMPTS
CREATE TABLE public.assessment_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_slug text,
  assessment_name text NOT NULL,
  scheduled_at timestamptz,
  status text NOT NULL DEFAULT 'scheduled',
  score numeric,
  wpm integer,
  remarks text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.assessment_attempts TO authenticated;
GRANT ALL ON public.assessment_attempts TO service_role;
ALTER TABLE public.assessment_attempts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own attempts" ON public.assessment_attempts
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE POLICY "Staff manage attempts" ON public.assessment_attempts
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE TRIGGER assessment_attempts_updated_at BEFORE UPDATE ON public.assessment_attempts
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- CERTIFICATES
CREATE TABLE public.certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  course_slug text,
  title text NOT NULL,
  certificate_number text NOT NULL UNIQUE,
  issued_at timestamptz NOT NULL DEFAULT now(),
  file_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.certificates TO authenticated;
GRANT ALL ON public.certificates TO service_role;
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Learners read own certificates" ON public.certificates
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));
CREATE POLICY "Admins manage certificates" ON public.certificates
  FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER certificates_updated_at BEFORE UPDATE ON public.certificates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX idx_enrolments_user ON public.enrolments(user_id);
CREATE INDEX idx_sessions_course_start ON public.course_sessions(course_slug, starts_at);
CREATE INDEX idx_attempts_user ON public.assessment_attempts(user_id);
CREATE INDEX idx_certificates_user ON public.certificates(user_id);