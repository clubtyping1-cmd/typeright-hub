ALTER TABLE public.course_sessions
  ADD COLUMN IF NOT EXISTS session_type text NOT NULL DEFAULT 'class';

ALTER TABLE public.course_sessions
  DROP CONSTRAINT IF EXISTS course_sessions_session_type_check;

ALTER TABLE public.course_sessions
  ADD CONSTRAINT course_sessions_session_type_check
  CHECK (session_type IN ('class','exam'));