DROP POLICY IF EXISTS "plans public read" ON public.subscription_plans;
CREATE POLICY "plans public read active" ON public.subscription_plans FOR SELECT TO anon, authenticated USING (is_active);