ALTER TABLE public.course_sessions
  ADD COLUMN IF NOT EXISTS capacity integer,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'scheduled',
  ADD COLUMN IF NOT EXISTS cancellation_reason text,
  ADD COLUMN IF NOT EXISTS original_starts_at timestamptz;

CREATE TABLE IF NOT EXISTS public.class_attendees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.course_sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  enrolment_id uuid REFERENCES public.enrolments(id) ON DELETE SET NULL,
  attendance_status text NOT NULL DEFAULT 'unmarked',
  marked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.class_attendees TO authenticated;
GRANT ALL ON public.class_attendees TO service_role;

ALTER TABLE public.class_attendees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Learners read own class assignments"
  ON public.class_attendees FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Staff read all class assignments"
  ON public.class_attendees FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));

CREATE POLICY "Staff manage class assignments"
  ON public.class_attendees FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor'));

CREATE TRIGGER class_attendees_updated_at
  BEFORE UPDATE ON public.class_attendees
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE POLICY "Learners read assigned sessions"
  ON public.course_sessions FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.class_attendees a
    WHERE a.session_id = course_sessions.id AND a.user_id = auth.uid()
  ));