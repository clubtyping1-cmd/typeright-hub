ALTER TABLE public.enrolments
  ADD COLUMN IF NOT EXISTS payment_reference text,
  ADD COLUMN IF NOT EXISTS payment_amount_bnd numeric,
  ADD COLUMN IF NOT EXISTS paid_at timestamptz,
  ADD COLUMN IF NOT EXISTS payment_note text,
  ADD COLUMN IF NOT EXISTS activated_by uuid,
  ADD COLUMN IF NOT EXISTS activated_at timestamptz;

CREATE OR REPLACE FUNCTION public.guard_enrolment_learner_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'instructor') THEN
    RETURN NEW;
  END IF;
  NEW.course_slug := OLD.course_slug;
  NEW.title := OLD.title;
  NEW.level_name := OLD.level_name;
  NEW.instructor_name := OLD.instructor_name;
  NEW.status := OLD.status;
  NEW.progress_percent := OLD.progress_percent;
  NEW.next_lesson_title := OLD.next_lesson_title;
  NEW.completed_at := OLD.completed_at;
  NEW.user_id := OLD.user_id;
  NEW.payment_reference := OLD.payment_reference;
  NEW.payment_amount_bnd := OLD.payment_amount_bnd;
  NEW.paid_at := OLD.paid_at;
  NEW.payment_note := OLD.payment_note;
  NEW.activated_by := OLD.activated_by;
  NEW.activated_at := OLD.activated_at;
  RETURN NEW;
END;
$function$;