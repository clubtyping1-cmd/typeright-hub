CREATE TABLE public.programmes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  default_instructor text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.programmes TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.programmes TO authenticated;
GRANT ALL ON public.programmes TO service_role;

ALTER TABLE public.programmes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Signed-in users can view programmes"
  ON public.programmes FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins manage programmes"
  ON public.programmes FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER programmes_updated_at BEFORE UPDATE ON public.programmes
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.programmes (slug, title, default_instructor, sort_order) VALUES
  ('keyboard-mastery-trt', 'Keyboard Mastery Programme (TRT)', 'Hjh Noraini Abdullah', 1),
  ('shorthand-training-trs', 'Shorthand Training Programme (TRS)', 'Puan Hasnah Ismail', 2),
  ('ai-clerical-admin', 'AI-Enabled Clerical Operations & Administrative Support', 'Dr Aisyah Rahman', 3),
  ('ai-secretarial-executive', 'AI-Enabled Secretarial, PA & Executive Support', 'Dr Aisyah Rahman', 4),
  ('train-the-trainer', 'Future Train-the-Trainer Pathway', 'Hjh Noraini Abdullah', 5);