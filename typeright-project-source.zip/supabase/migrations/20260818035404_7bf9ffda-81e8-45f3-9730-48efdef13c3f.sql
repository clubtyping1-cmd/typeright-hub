DROP POLICY IF EXISTS "plans admin write" ON public.subscription_plans;
CREATE POLICY "plans admin insert" ON public.subscription_plans FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "plans admin update" ON public.subscription_plans FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "plans admin delete" ON public.subscription_plans FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

DROP POLICY IF EXISTS "prices admin write" ON public.plan_prices;
CREATE POLICY "prices admin insert" ON public.plan_prices FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "prices admin update" ON public.plan_prices FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "prices admin delete" ON public.plan_prices FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

DROP POLICY IF EXISTS "plan_ent admin write" ON public.plan_entitlements;
CREATE POLICY "plan_ent admin insert" ON public.plan_entitlements FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "plan_ent admin update" ON public.plan_entitlements FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "plan_ent admin delete" ON public.plan_entitlements FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));