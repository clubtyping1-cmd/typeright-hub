export const NEWS_CATEGORIES = [
  "Announcement",
  "Examinations",
  "Programme update",
  "Partnership",
  "Community",
] as const;

export type NewsPost = {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  body: string | null;
  category: string;
  cover_url: string | null;
  author: string;
  published_at: string;
  is_published: boolean;
};

export function slugifyTitle(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
}

export function readTime(body: string | null | undefined) {
  const words = (body ?? "").trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
}