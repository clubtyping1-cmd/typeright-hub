export const CLASS_STATUSES = ["scheduled", "rescheduled", "cancelled"] as const;
export const ATTENDANCE_STATUSES = ["unmarked", "present", "absent", "late", "excused"] as const;
export const SESSION_TYPES = ["class", "exam"] as const;

export type ClassStatus = (typeof CLASS_STATUSES)[number];
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];
export type SessionType = (typeof SESSION_TYPES)[number];