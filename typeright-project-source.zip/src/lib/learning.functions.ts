import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Everything the learner dashboard needs, in one round-trip. */
export const getDashboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [profile, announcement, enrolments, attempts, certificates] = await Promise.all([
      supabase
        .from("profiles")
        .select("id, email, display_name, avatar_url, created_at")
        .eq("id", userId)
        .maybeSingle(),
      supabase
        .from("announcements")
        .select("id, title, body, link_url, published_at")
        .order("published_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase
        .from("enrolments")
        .select(
          "id, course_slug, title, level_name, instructor_name, status, progress_percent, next_lesson_title, started_at, completed_at, last_accessed_at",
        )
        .eq("user_id", userId)
        .order("last_accessed_at", { ascending: false, nullsFirst: false }),
      supabase
        .from("assessment_attempts")
        .select("id, course_slug, assessment_name, scheduled_at, status, score, wpm, remarks")
        .eq("user_id", userId)
        .order("scheduled_at", { ascending: false, nullsFirst: false }),
      supabase
        .from("certificates")
        .select("id, course_slug, title, certificate_number, issued_at, file_url")
        .eq("user_id", userId)
        .order("issued_at", { ascending: false }),
    ]);

    const enrolmentRows = enrolments.data ?? [];

    // All upcoming classes and exams are visible to every signed-in learner.
    const [{ data: sessionRows }, { data: myAttendance }] = await Promise.all([
      supabase
        .from("course_sessions")
        .select(
          "id, course_slug, title, starts_at, ends_at, mode, location, join_url, instructor_name, status, cancellation_reason, original_starts_at, session_type",
        )
        .gte("starts_at", new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString())
        .order("starts_at", { ascending: true }),
      supabase
        .from("class_attendees")
        .select("id, session_id, attendance_status")
        .eq("user_id", userId),
    ]);

    const attendanceBySession = new Map<string, string>(
      (myAttendance ?? []).map((a: any) => [a.session_id, a.attendance_status]),
    );

    const sessions = (sessionRows ?? []).map((s: any) => ({
      ...s,
      attendance_status: attendanceBySession.get(s.id) ?? null,
    }));

    const { data: classUpdates } = await supabase
      .from("notifications")
      .select("id, title, body, created_at, read_at")
      .eq("user_id", userId)
      .eq("type", "class_update")
      .order("created_at", { ascending: false })
      .limit(6);

    return {
      profile: profile.data,
      announcement: announcement.data,
      enrolments: enrolmentRows,
      sessions,
      classUpdates: classUpdates ?? [],
      attempts: attempts.data ?? [],
      certificates: certificates.data ?? [],
    };

  });

/** Marks a course as recently accessed by the signed-in learner. */
export const touchCourseAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ courseSlug: z.string().trim().min(1).max(80) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("enrolments")
      .update({ last_accessed_at: new Date().toISOString() })
      .eq("user_id", context.userId)
      .eq("course_slug", data.courseSlug);
    if (error) console.error("touchCourseAccess failed", error);
    return { ok: true };
  });

/** Lets a learner update their own display name from the dashboard profile card. */
export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ displayName: z.string().trim().min(1).max(80) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({ display_name: data.displayName })
      .eq("id", context.userId);
    if (error) throw new Error("Could not update your profile.");
    return { ok: true };
  });
/** Achievement level + badges for the signed-in learner. */
export const getMyAchievements = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [catalog, mine, level] = await Promise.all([
      supabase.from("badges").select("code, label, description, sort_order").order("sort_order"),
      supabase.from("learner_badges").select("badge_code, awarded_at").eq("user_id", userId),
      supabase.from("learner_levels").select("level, level_name, updated_at").eq("user_id", userId).maybeSingle(),
    ]);
    return {
      badges: catalog.data ?? [],
      earned: mine.data ?? [],
      level: level.data ?? null,
    };
  });
