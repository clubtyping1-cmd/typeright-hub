import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

import type { Database } from "@/integrations/supabase/types";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/admin.guards";

const COLS =
  "id, slug, title, excerpt, body, category, cover_url, author, published_at, is_published";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient<Database>(process.env["SUPABASE_URL"]!, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

/** Public: every published post, newest first. */
export const listPublishedNews = createServerFn({ method: "GET" }).handler(async () => {
  const { data, error } = await publicClient()
    .from("news_posts")
    .select(COLS)
    .eq("is_published", true)
    .order("published_at", { ascending: false });
  if (error) {
    console.error("listPublishedNews failed", error);
    return { posts: [] as any[] };
  }
  return { posts: data ?? [] };
});

/** Public: one published post by slug. */
export const getNewsPost = createServerFn({ method: "GET" })
  .inputValidator((data: { slug: string }) => z.object({ slug: z.string().min(1) }).parse(data))
  .handler(async ({ data }) => {
    const { data: row, error } = await publicClient()
      .from("news_posts")
      .select(COLS)
      .eq("slug", data.slug)
      .eq("is_published", true)
      .maybeSingle();
    if (error) console.error("getNewsPost failed", error);
    return { post: row ?? null };
  });

/** Admin: every post, published or draft. */
export const listAllNews = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("news_posts")
      .select(COLS)
      .order("published_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { posts: data ?? [] };
  });

const postSchema = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().min(1).max(90),
  title: z.string().min(1).max(200),
  excerpt: z.string().max(600).nullable(),
  body: z.string().max(20000).nullable(),
  category: z.string().min(1).max(60),
  coverUrl: z.string().max(1000).nullable(),
  author: z.string().min(1).max(120),
  publishedAt: z.string().min(1),
  isPublished: z.boolean(),
});

export const upsertNewsPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => postSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const row = {
      slug: data.slug,
      title: data.title,
      excerpt: data.excerpt,
      body: data.body,
      category: data.category,
      cover_url: data.coverUrl,
      author: data.author,
      published_at: new Date(data.publishedAt).toISOString(),
      is_published: data.isPublished,
      created_by: context.userId,
    };
    const query = data.id
      ? context.supabase.from("news_posts").update(row).eq("id", data.id)
      : context.supabase.from("news_posts").insert(row);
    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteNewsPost = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string }) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase.from("news_posts").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });