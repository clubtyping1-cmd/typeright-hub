import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin, logAction } from "@/lib/admin.guards";
import { ATTENDANCE_STATUSES, CLASS_STATUSES, SESSION_TYPES } from "@/lib/classes.constants";
import { SESSION_MODES } from "@/lib/learning.constants";

const SESSION_COLS =
  "id, course_slug, title, starts_at, ends_at, mode, location, join_url, instructor_name, notes, capacity, status, cancellation_reason, original_starts_at, session_type";

async function notifyAttendees(
  context: { supabase: any; userId: string },
  sessionId: string,
  title: string,
  body: string,
) {
  const { data: rows } = await context.supabase
    .from("class_attendees")
    .select("user_id")
    .eq("session_id", sessionId);
  const users: string[] = (rows ?? []).map((r: any) => r.user_id);
  if (!users.length) return;
  const { error } = await context.supabase.from("notifications").insert(
    users.map((uid) => ({
      user_id: uid,
      type: "class_update",
      title,
      body,
      payload: { session_id: sessionId },
    })),
  );
  if (error) console.error("notifyAttendees failed", error);
}

/** Every class plus its roster, for the admin calendar. */
export const getClassesAdminData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabase } = context;
    const [sessions, attendees, profiles, enrolments, programmes] = await Promise.all([
      supabase.from("course_sessions").select(SESSION_COLS).order("starts_at", { ascending: true }),
      supabase
        .from("class_attendees")
        .select("id, session_id, user_id, enrolment_id, attendance_status, marked_at"),
      supabase.from("profiles").select("id, email, display_name"),
      supabase
        .from("enrolments")
        .select(
          "id, user_id, course_slug, title, level_name, instructor_name, status, payment_reference, payment_amount_bnd, paid_at, payment_note, activated_at, created_at",
        )
        .order("created_at", { ascending: false }),
      supabase
        .from("programmes")
        .select("id, slug, title, default_instructor, is_active, sort_order")
        .order("sort_order", { ascending: true }),
    ]);
    return {
      sessions: sessions.data ?? [],
      attendees: attendees.data ?? [],
      profiles: profiles.data ?? [],
      enrolments: enrolments.data ?? [],
      programmes: programmes.data ?? [],
    };
  });

/** Create or update a programme that calendar entries can be scheduled against. */
export const upsertProgramme = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        slug: z
          .string()
          .trim()
          .min(2)
          .max(80)
          .regex(/^[a-z0-9-]+$/, "Use lowercase letters, numbers and hyphens only."),
        title: z.string().trim().min(2).max(160),
        defaultInstructor: z.string().trim().max(120).nullable().optional(),
        isActive: z.boolean().optional(),
        sortOrder: z.number().int().min(0).max(999).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const row = {
      slug: data.slug,
      title: data.title,
      default_instructor: data.defaultInstructor || null,
      is_active: data.isActive ?? true,
      sort_order: data.sortOrder ?? 0,
    };
    const { error } = await (data.id
      ? context.supabase.from("programmes").update(row).eq("id", data.id)
      : context.supabase.from("programmes").insert(row));
    if (error) {
      console.error("upsertProgramme failed", error);
      throw new Error(
        error.code === "23505" ? "That programme code is already in use." : "Could not save this programme.",
      );
    }
    await logAction(context, data.id ? "programme.updated" : "programme.created", "programme", data.id ?? data.slug);
    return { ok: true };
  });

/** Removes a programme. Blocked while calendar entries still reference it. */
export const deleteProgramme = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), slug: z.string().trim().min(1) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { count } = await context.supabase
      .from("course_sessions")
      .select("id", { count: "exact", head: true })
      .eq("course_slug", data.slug);
    if ((count ?? 0) > 0) {
      throw new Error("This programme still has calendar entries. Remove or reassign them first.");
    }
    const { error } = await context.supabase.from("programmes").delete().eq("id", data.id);
    if (error) throw new Error("Could not delete this programme.");
    await logAction(context, "programme.deleted", "programme", data.id, { slug: data.slug });
    return { ok: true };
  });

export const upsertClass = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        sessionType: z.enum(SESSION_TYPES).optional(),
        courseSlug: z.string().trim().min(1),
        title: z.string().trim().min(1),
        startsAt: z.string().min(4),
        endsAt: z.string().nullable().optional(),
        mode: z.enum(SESSION_MODES),
        location: z.string().trim().max(200).nullable().optional(),
        joinUrl: z.string().trim().max(400).nullable().optional(),
        instructorName: z.string().trim().max(120).nullable().optional(),
        capacity: z.number().int().min(1).max(500).nullable().optional(),
        notes: z.string().trim().max(1000).nullable().optional(),
        status: z.enum(CLASS_STATUSES).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const startsAt = new Date(data.startsAt).toISOString();

    let previousStart: string | null = null;
    let previousStatus: string | null = null;
    if (data.id) {
      const { data: existing } = await context.supabase
        .from("course_sessions")
        .select("starts_at, status, original_starts_at")
        .eq("id", data.id)
        .maybeSingle();
      previousStart = existing?.starts_at ?? null;
      previousStatus = existing?.status ?? null;
    }

    const rescheduled =
      Boolean(data.id) && previousStart != null && new Date(previousStart).getTime() !== new Date(startsAt).getTime();

    const row = {
      course_slug: data.courseSlug,
      session_type: data.sessionType ?? "class",
      title: data.title,
      starts_at: startsAt,
      ends_at: data.endsAt ? new Date(data.endsAt).toISOString() : null,
      mode: data.mode,
      location: data.location || null,
      join_url: data.joinUrl || null,
      instructor_name: data.instructorName || null,
      capacity: data.capacity ?? null,
      notes: data.notes || null,
      status: data.status ?? (rescheduled ? "rescheduled" : previousStatus ?? "scheduled"),
      ...(rescheduled ? { original_starts_at: previousStart, status: "rescheduled" } : {}),
    };

    const { data: saved, error } = await (data.id
      ? context.supabase.from("course_sessions").update(row).eq("id", data.id).select("id").maybeSingle()
      : context.supabase.from("course_sessions").insert(row).select("id").maybeSingle());
    if (error) {
      console.error("upsertClass failed", error);
      throw new Error("Could not save this class.");
    }

    const sessionId = data.id ?? saved?.id;
    if (rescheduled && sessionId) {
      await notifyAttendees(
        context,
        sessionId,
        `Class rescheduled: ${data.title}`,
        `Your class now starts on ${new Date(startsAt).toLocaleString()}.`,
      );
    }
    await logAction(context, data.id ? "class.updated" : "class.created", "course_session", sessionId ?? data.courseSlug, {
      rescheduled,
    });
    return { ok: true, id: sessionId };
  });

export const cancelClass = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({ id: z.string().uuid(), reason: z.string().trim().max(400).optional() })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: existing, error } = await context.supabase
      .from("course_sessions")
      .update({ status: "cancelled", cancellation_reason: data.reason || null })
      .eq("id", data.id)
      .select("title")
      .maybeSingle();
    if (error) throw new Error("Could not cancel this class.");
    await notifyAttendees(
      context,
      data.id,
      `Class cancelled: ${existing?.title ?? "Class"}`,
      data.reason || "This class has been cancelled.",
    );
    await logAction(context, "class.cancelled", "course_session", data.id, { reason: data.reason ?? null });
    return { ok: true };
  });

export const restoreClass = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase
      .from("course_sessions")
      .update({ status: "scheduled", cancellation_reason: null })
      .eq("id", data.id);
    if (error) throw new Error("Could not restore this class.");
    await notifyAttendees(context, data.id, "Class reinstated", "A cancelled class is running again.");
    await logAction(context, "class.restored", "course_session", data.id);
    return { ok: true };
  });

export const deleteClass = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    await notifyAttendees(context, data.id, "Class removed", "A class on your schedule has been removed.");
    const { error } = await context.supabase.from("course_sessions").delete().eq("id", data.id);
    if (error) throw new Error("Could not delete this class.");
    await logAction(context, "class.deleted", "course_session", data.id);
    return { ok: true };
  });

export const assignLearner = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        sessionId: z.string().uuid(),
        userId: z.string().uuid(),
        enrolmentId: z.string().uuid().nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const [{ data: session }, { count }] = await Promise.all([
      context.supabase.from("course_sessions").select("capacity, title, starts_at").eq("id", data.sessionId).maybeSingle(),
      context.supabase
        .from("class_attendees")
        .select("id", { count: "exact", head: true })
        .eq("session_id", data.sessionId),
    ]);
    if (session?.capacity != null && (count ?? 0) >= session.capacity) {
      throw new Error("This class is already full.");
    }
    const { error } = await context.supabase.from("class_attendees").insert({
      session_id: data.sessionId,
      user_id: data.userId,
      enrolment_id: data.enrolmentId ?? null,
    });
    if (error) {
      console.error("assignLearner failed", error);
      throw new Error("Could not assign this learner (they may already be on the list).");
    }
    const { error: notifyError } = await context.supabase.from("notifications").insert({
      user_id: data.userId,
      type: "class_update",
      title: `You've been added to ${session?.title ?? "a class"}`,
      body: session?.starts_at ? `Starts ${new Date(session.starts_at).toLocaleString()}.` : null,
      payload: { session_id: data.sessionId },
    });
    if (notifyError) console.error("assignLearner notify failed", notifyError);
    await logAction(context, "class.learner_assigned", "course_session", data.sessionId, { user_id: data.userId });
    return { ok: true };
  });

export const unassignLearner = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase.from("class_attendees").delete().eq("id", data.id);
    if (error) throw new Error("Could not remove this learner from the class.");
    await logAction(context, "class.learner_unassigned", "class_attendee", data.id);
    return { ok: true };
  });

export const markAttendance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({ id: z.string().uuid(), attendanceStatus: z.enum(ATTENDANCE_STATUSES) })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase
      .from("class_attendees")
      .update({
        attendance_status: data.attendanceStatus,
        marked_at: data.attendanceStatus === "unmarked" ? null : new Date().toISOString(),
      })
      .eq("id", data.id);
    if (error) throw new Error("Could not save attendance.");
    return { ok: true };
  });
/** Activates (or updates) a learner's enrolment after an admin verifies payment. */
export const upsertEnrolment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid().optional(),
        userId: z.string().uuid(),
        courseSlug: z.string().trim().min(1).max(80),
        title: z.string().trim().min(1).max(160),
        levelName: z.string().trim().max(120).nullable().optional(),
        instructorName: z.string().trim().max(120).nullable().optional(),
        status: z.enum(["active", "completed", "suspended"]).default("active"),
        paymentReference: z.string().trim().max(120).nullable().optional(),
        paymentAmountBnd: z.number().min(0).max(1000000).nullable().optional(),
        paidAt: z.string().trim().min(1).nullable().optional(),
        paymentNote: z.string().trim().max(500).nullable().optional(),
        sessionIds: z.array(z.string().uuid()).max(200).default([]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabase } = context;

    const row = {
      user_id: data.userId,
      course_slug: data.courseSlug,
      title: data.title,
      level_name: data.levelName || null,
      instructor_name: data.instructorName || null,
      status: data.status,
      payment_reference: data.paymentReference || null,
      payment_amount_bnd: data.paymentAmountBnd ?? null,
      paid_at: data.paidAt ? new Date(data.paidAt).toISOString() : null,
      payment_note: data.paymentNote || null,
      activated_by: context.userId,
      activated_at: new Date().toISOString(),
    };

    let enrolmentId = data.id;
    if (enrolmentId) {
      const { error } = await supabase.from("enrolments").update(row).eq("id", enrolmentId);
      if (error) {
        console.error("upsertEnrolment update failed", error);
        throw new Error("Could not save this enrolment.");
      }
    } else {
      const { data: inserted, error } = await supabase
        .from("enrolments")
        .insert(row)
        .select("id")
        .single();
      if (error) {
        console.error("upsertEnrolment insert failed", error);
        throw new Error(
          error.code === "23505"
            ? "This learner is already enrolled in that programme and level."
            : "Could not create this enrolment.",
        );
      }
      enrolmentId = inserted.id as string;
    }

    // Sync the learner's calendar roster to exactly the ticked slots.
    const { data: existing } = await supabase
      .from("class_attendees")
      .select("id, session_id")
      .eq("user_id", data.userId)
      .eq("enrolment_id", enrolmentId);

    const current = new Set<string>((existing ?? []).map((r: any) => r.session_id));
    const wanted = new Set(data.sessionIds);

    const toAdd = data.sessionIds.filter((sid) => !current.has(sid));
    const toRemove = (existing ?? []).filter((r: any) => !wanted.has(r.session_id));

    if (toAdd.length) {
      const { error } = await supabase.from("class_attendees").insert(
        toAdd.map((sid) => ({
          session_id: sid,
          user_id: data.userId,
          enrolment_id: enrolmentId,
          attendance_status: "unmarked",
        })),
      );
      if (error) console.error("enrolment roster insert failed", error);
    }
    if (toRemove.length) {
      const { error } = await supabase
        .from("class_attendees")
        .delete()
        .in("id", toRemove.map((r: any) => r.id));
      if (error) console.error("enrolment roster delete failed", error);
    }

    await logAction(
      context,
      data.id ? "enrolment.updated" : "enrolment.activated",
      "enrolment",
      enrolmentId,
      { course_slug: data.courseSlug, slots: data.sessionIds.length },
    );
    return { ok: true, id: enrolmentId };
  });

/** Removes an enrolment and any calendar slots it booked. */
export const deleteEnrolment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    await context.supabase.from("class_attendees").delete().eq("enrolment_id", data.id);
    const { error } = await context.supabase.from("enrolments").delete().eq("id", data.id);
    if (error) {
      console.error("deleteEnrolment failed", error);
      throw new Error("Could not remove this enrolment.");
    }
    await logAction(context, "enrolment.deleted", "enrolment", data.id);
    return { ok: true };
  });
