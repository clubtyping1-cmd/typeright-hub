export const ENROLMENT_STATUSES = ["active", "completed", "paused"] as const;
export const ATTEMPT_STATUSES = ["scheduled", "pending_result", "passed", "failed"] as const;
export const SESSION_MODES = ["onsite", "online", "hybrid"] as const;
