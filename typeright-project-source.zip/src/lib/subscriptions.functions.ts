import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin, logAction } from "@/lib/admin.guards";

export const PLAN_CODES = ["trt", "trs", "complete", "teams"] as const;
export const INTERVALS = ["daily", "weekly", "monthly", "annual", "custom"] as const;
export const SUBSCRIPTION_STATUSES = [
  "pending_payment",
  "trial",
  "active",
  "past_due",
  "grace",
  "paused",
  "cancelled",
  "expired",
  "suspended",
] as const;

function periodEndFor(interval: string, from = new Date()): Date | null {
  const d = new Date(from);
  if (interval === "daily") d.setDate(d.getDate() + 1);
  else if (interval === "weekly") d.setDate(d.getDate() + 7);
  else if (interval === "monthly") d.setMonth(d.getMonth() + 1);
  else if (interval === "annual") d.setFullYear(d.getFullYear() + 1);
  else return null;
  return d;
}

/** Public — used by the pricing page. Reads plans + prices + entitlement mapping. */
export const listPublicPlans = createServerFn({ method: "GET" }).handler(async () => {
  const { createClient } = await import("@supabase/supabase-js");
  const url = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL!;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY ?? process.env.VITE_SUPABASE_PUBLISHABLE_KEY!;
  const client = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
  const [plans, prices, mapping] = await Promise.all([
    client
      .from("subscription_plans")
      .select("id, code, name, description, kind, cta_label, sort_order")
      .eq("is_active", true)
      .order("sort_order"),
    client.from("plan_prices").select("id, plan_id, interval, amount_bnd").eq("is_active", true),
    client.from("plan_entitlements").select("plan_id, entitlement_code"),
  ]);
  if (plans.error || prices.error || mapping.error) {
    throw new Error("Could not load plans.");
  }
  return {
    plans: plans.data ?? [],
    prices: prices.data ?? [],
    entitlements: mapping.data ?? [],
  };
});

/** Signed-in learner's active subscription (may be null). */
export const mySubscription = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("subscriptions")
      .select(
        "id, status, current_period_start, current_period_end, activated_at, cancel_at_period_end, cancelled_at, plan_id, price_id, subscription_plans!inner(code, name, cta_label), plan_prices(interval, amount_bnd)",
      )
      .eq("user_id", context.userId)
      .in("status", ["trial", "active", "past_due", "grace", "paused", "cancelled"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw new Error("Could not load subscription.");
    return data;
  });

export const myEntitlements = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("has_entitlement", {
      _user_id: context.userId,
      _code: "trt_full_access",
    });
    // Simpler: fetch all codes and check each via one query
    const codes = [
      "trt_full_access",
      "trs_full_access",
      "trt_preview",
      "trs_preview",
      "advanced_progress",
      "monthly_summary",
      "organisation_reporting",
      "priority_registration",
      "subscriber_discount",
    ];
    const results: Record<string, boolean> = {};
    for (const code of codes) {
      const { data: has } = await context.supabase.rpc("has_entitlement", {
        _user_id: context.userId,
        _code: code,
      });
      results[code] = has === true;
    }
    return { entitlements: results, sample: data === true, error: error?.message ?? null };
  });

/**
/** Public — submit a Teams quotation enquiry. Accepts anon submissions. */
export const submitTeamsEnquiry = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        organisationName: z.string().trim().min(2).max(160),
        contactName: z.string().trim().min(2).max(160),
        contactEmail: z.string().trim().email().max(200),
        contactPhone: z.string().trim().max(40).optional(),
        seats: z.number().int().positive().max(100000).optional(),
        planInterest: z.string().trim().max(60).optional(),
        notes: z.string().trim().max(2000).optional(),
        // honeypot
        website: z.string().max(0).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    if (data.website && data.website.length > 0) return { ok: true }; // silently drop bots
    const { createClient } = await import("@supabase/supabase-js");
    const url = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL!;
    const key = process.env.SUPABASE_PUBLISHABLE_KEY ?? process.env.VITE_SUPABASE_PUBLISHABLE_KEY!;
    const client = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { error } = await client.from("organisation_enquiries").insert({
      organisation_name: data.organisationName,
      contact_name: data.contactName,
      contact_email: data.contactEmail,
      contact_phone: data.contactPhone ?? null,
      seats: data.seats ?? null,
      plan_interest: data.planInterest ?? null,
      notes: data.notes ?? null,
    });
    if (error) throw new Error("Could not submit enquiry. Please try again.");
    return { ok: true };
  });

// ============ ADMIN ============

export const adminListSubscriptions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("subscriptions")
      .select(
        "id, user_id, status, current_period_start, current_period_end, cancel_at_period_end, created_at, subscription_plans!inner(code, name), plan_prices(interval, amount_bnd), profiles!subscriptions_user_id_fkey(email, display_name)",
      )
      .order("created_at", { ascending: false });
    if (error) {
      // Fallback without embedded profile if the FK name resolution differs.
      const alt = await context.supabase
        .from("subscriptions")
        .select(
          "id, user_id, status, current_period_start, current_period_end, cancel_at_period_end, created_at, subscription_plans!inner(code, name), plan_prices(interval, amount_bnd)",
        )
        .order("created_at", { ascending: false });
      if (alt.error) throw new Error("Could not load subscriptions.");
      return alt.data ?? [];
    }
    return data ?? [];
  });

export const adminListPendingPayments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("subscription_payments")
      .select(
        "id, subscription_id, user_id, amount_bnd, method, status, reference, proof_path, created_at, subscriptions!inner(status, subscription_plans!inner(code, name), plan_prices(interval))",
      )
      .in("status", ["pending_verification"])
      .order("created_at", { ascending: false });
    if (error) throw new Error("Could not load pending payments.");
    return data ?? [];
  });

export const adminApprovePayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ paymentId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: payment, error: payErr } = await context.supabase
      .from("subscription_payments")
      .select("id, subscription_id, user_id, amount_bnd, subscriptions!inner(id, status, plan_id, price_id, plan_prices(interval))")
      .eq("id", data.paymentId)
      .maybeSingle();
    if (payErr || !payment) throw new Error("Payment not found.");
    const sub = (payment as any).subscriptions;
    const interval: string = sub?.plan_prices?.interval ?? "monthly";
    const now = new Date();
    const periodEnd = periodEndFor(interval, now);

    // Idempotency: only approve if not already approved
    const { data: updated, error: updErr } = await context.supabase
      .from("subscription_payments")
      .update({
        status: "approved",
        approved_by: context.userId,
        approved_at: now.toISOString(),
      })
      .eq("id", data.paymentId)
      .eq("status", "pending_verification")
      .select("id")
      .maybeSingle();
    if (updErr) throw new Error("Could not approve payment.");
    if (!updated) return { ok: true, alreadyApplied: true };

    const { error: subErr } = await context.supabase
      .from("subscriptions")
      .update({
        status: "active",
        activated_at: now.toISOString(),
        current_period_start: now.toISOString(),
        current_period_end: periodEnd?.toISOString() ?? null,
      })
      .eq("id", payment.subscription_id);
    if (subErr) throw new Error("Could not activate subscription.");

    await context.supabase.from("subscription_events").insert({
      subscription_id: payment.subscription_id,
      event_type: "payment.approved",
      from_status: sub?.status ?? null,
      to_status: "active",
      actor_id: context.userId,
      notes: `Approved BND ${payment.amount_bnd}`,
    });
    await context.supabase.from("notifications").insert({
      user_id: payment.user_id,
      type: "subscription.activated",
      title: "Subscription activated",
      body: "Your payment has been approved. Practice access is now unlocked.",
    });
    await logAction(context, "subscription.payment_approved", "subscription_payment", data.paymentId, {
      amount: payment.amount_bnd,
    });
    return { ok: true };
  });

export const adminRejectPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ paymentId: z.string().uuid(), reason: z.string().max(500).optional() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: payment } = await context.supabase
      .from("subscription_payments")
      .select("id, subscription_id, user_id")
      .eq("id", data.paymentId)
      .maybeSingle();
    if (!payment) throw new Error("Payment not found.");
    const { error } = await context.supabase
      .from("subscription_payments")
      .update({
        status: "rejected",
        rejected_reason: data.reason ?? null,
        approved_by: context.userId,
        approved_at: new Date().toISOString(),
      })
      .eq("id", data.paymentId)
      .eq("status", "pending_verification");
    if (error) throw new Error("Could not reject payment.");
    await context.supabase.from("subscription_events").insert({
      subscription_id: payment.subscription_id,
      event_type: "payment.rejected",
      actor_id: context.userId,
      notes: data.reason ?? null,
    });
    await context.supabase.from("notifications").insert({
      user_id: payment.user_id,
      type: "subscription.payment_rejected",
      title: "Payment could not be verified",
      body: data.reason ?? "Please review your payment reference and try again.",
    });
    await logAction(context, "subscription.payment_rejected", "subscription_payment", data.paymentId);
    return { ok: true };
  });

export const adminChangeSubscriptionStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        subscriptionId: z.string().uuid(),
        status: z.enum(SUBSCRIPTION_STATUSES),
        notes: z.string().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { data: existing } = await context.supabase
      .from("subscriptions")
      .select("id, status, user_id")
      .eq("id", data.subscriptionId)
      .maybeSingle();
    if (!existing) throw new Error("Subscription not found.");
    const { error } = await context.supabase
      .from("subscriptions")
      .update({ status: data.status })
      .eq("id", data.subscriptionId);
    if (error) throw new Error("Could not update subscription.");
    await context.supabase.from("subscription_events").insert({
      subscription_id: data.subscriptionId,
      event_type: "admin.status_changed",
      from_status: existing.status,
      to_status: data.status,
      actor_id: context.userId,
      notes: data.notes ?? null,
    });
    await logAction(context, "subscription.status_changed", "subscription", data.subscriptionId, {
      from: existing.status,
      to: data.status,
    });
    return { ok: true };
  });

export const adminMetrics = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const [subs, pending] = await Promise.all([
      context.supabase
        .from("subscriptions")
        .select("id, status, plan_id, price_id, current_period_end, cancel_at_period_end, subscription_plans!inner(code), plan_prices(interval, amount_bnd)"),
      context.supabase.from("subscription_payments").select("id", { count: "exact", head: true }).eq("status", "pending_verification"),
    ]);
    const rows = (subs.data ?? []) as any[];
    const active = rows.filter((s) => s.status === "active");
    let mrr = 0;
    for (const s of active) {
      const amt = Number(s.plan_prices?.amount_bnd ?? 0);
      const interval = s.plan_prices?.interval;
      if (interval === "daily") mrr += amt * 30;
      else if (interval === "weekly") mrr += amt * 4.33;
      else if (interval === "monthly") mrr += amt;
      else if (interval === "annual") mrr += amt / 12;
    }
    const upcoming = rows.filter(
      (s) => s.status === "active" && s.current_period_end && new Date(s.current_period_end) < new Date(Date.now() + 7 * 24 * 3600 * 1000),
    ).length;
    const distribution: Record<string, number> = {};
    for (const s of rows) {
      const code = s.subscription_plans?.code ?? "unknown";
      distribution[code] = (distribution[code] ?? 0) + 1;
    }
    return {
      activeCount: active.length,
      pendingPayments: pending.count ?? 0,
      cancelled: rows.filter((s) => s.status === "cancelled").length,
      expired: rows.filter((s) => s.status === "expired").length,
      pastDue: rows.filter((s) => s.status === "past_due").length,
      upcomingRenewals: upcoming,
      mrr: Math.round(mrr * 100) / 100,
      arr: Math.round(mrr * 12 * 100) / 100,
      distribution,
    };
  });

export const adminListEnquiries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data, error } = await context.supabase
      .from("organisation_enquiries")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error("Could not load enquiries.");
    return data ?? [];
  });

export const adminUpdateEnquiryStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        enquiryId: z.string().uuid(),
        status: z.enum(["new", "contacted", "quoted", "converted", "closed"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { error } = await context.supabase
      .from("organisation_enquiries")
      .update({
        status: data.status,
        handled_by: context.userId,
        handled_at: new Date().toISOString(),
      })
      .eq("id", data.enquiryId);
    if (error) throw new Error("Could not update enquiry.");
    await logAction(context, "enquiry.status_changed", "organisation_enquiry", data.enquiryId, {
      status: data.status,
    });
    return { ok: true };
  });

/** Admin sweep: transition expired subscriptions. Called from the admin dashboard. */
export const runRenewalSweep = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const nowIso = new Date().toISOString();
    const { data: due } = await context.supabase
      .from("subscriptions")
      .select("id, status, cancel_at_period_end")
      .in("status", ["active", "grace"])
      .lt("current_period_end", nowIso);
    let expired = 0;
    for (const s of (due ?? []) as any[]) {
      const to = s.cancel_at_period_end ? "cancelled" : "expired";
      const { error } = await context.supabase
        .from("subscriptions")
        .update({ status: to })
        .eq("id", s.id);
      if (!error) {
        expired += 1;
        await context.supabase.from("subscription_events").insert({
          subscription_id: s.id,
          event_type: "auto.period_ended",
          from_status: s.status,
          to_status: to,
        });
      }
    }
    await logAction(context, "renewal.sweep", "system", "sweep", { transitioned: expired });
    return { transitioned: expired };
  });
