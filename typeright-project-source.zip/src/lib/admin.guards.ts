/** Client-safe helpers shared by admin server functions (no server-only imports). */
export const ORDER_STATUSES = ["pending_payment", "paid", "confirmed", "cancelled"] as const;
export const ROLES = ["admin", "instructor", "user"] as const;

export type AdminCtx = { supabase: any; userId: string };

export async function assertAdmin(context: AdminCtx) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) {
    console.error("assertAdmin: role check failed", error);
    throw new Error("Could not verify your permissions.");
  }
  if (!data) throw new Error("Forbidden");
}

export async function logAction(
  context: AdminCtx,
  action: string,
  targetType: string,
  targetId: string,
  details: Record<string, unknown> = {},
) {
  const { error } = await context.supabase.from("admin_audit_log").insert({
    actor_id: context.userId,
    action,
    target_type: targetType,
    target_id: targetId,
    details,
  });
  if (error) console.error("logAction failed", error);
}
