import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const amIAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: data === true };
  });

/** Admin: learners with their level and badges. */
export const getLearnerProgress = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) throw new Error("Forbidden");

    const [profiles, levels, badges, awarded] = await Promise.all([
      context.supabase.from("profiles").select("id, email, display_name").order("email"),
      context.supabase.from("learner_levels").select("user_id, level, level_name"),
      context.supabase.from("badges").select("code, label, description, sort_order").order("sort_order"),
      context.supabase.from("learner_badges").select("user_id, badge_code, awarded_at"),
    ]);

    return {
      profiles: profiles.data ?? [],
      levels: levels.data ?? [],
      badges: badges.data ?? [],
      awarded: awarded.data ?? [],
    };
  });

/** Admin: set a learner's achievement level. */
export const setLearnerLevel = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        level: z.number().int().min(1).max(5),
        levelName: z.string().trim().min(1).max(40),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) throw new Error("Forbidden");

    const { error } = await context.supabase.from("learner_levels").upsert(
      {
        user_id: data.userId,
        level: data.level,
        level_name: data.levelName,
        updated_by: context.userId,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" },
    );
    if (error) throw new Error("Could not save the level.");
    return { ok: true };
  });

/** Admin: award or revoke a badge for a learner. */
export const setLearnerBadge = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        userId: z.string().uuid(),
        badgeCode: z.string().trim().min(1).max(60),
        awarded: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) throw new Error("Forbidden");

    if (data.awarded) {
      const { error } = await context.supabase
        .from("learner_badges")
        .upsert(
          { user_id: data.userId, badge_code: data.badgeCode, awarded_by: context.userId },
          { onConflict: "user_id,badge_code" },
        );
      if (error) throw new Error("Could not award the badge.");
    } else {
      const { error } = await context.supabase
        .from("learner_badges")
        .delete()
        .eq("user_id", data.userId)
        .eq("badge_code", data.badgeCode);
      if (error) throw new Error("Could not remove the badge.");
    }
    return { ok: true };
  });
