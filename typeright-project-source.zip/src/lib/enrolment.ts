/**
 * Enrolment is handled through an external Google Form.
 * Replace this placeholder with the live form URL.
 */
export const ENROLMENT_FORM_URL = "https://forms.gle/j3n6eYcKfN7XnHNg9";

/**
 * External practice/class portal opened by the "Start your typing" button
 * on an active enrolment.
 */
export const PRACTICE_PORTAL_URL = "https://app.typerightms.com/TypingStudent/login.php";

/**
 * Builds the enrolment form link. Selected course/level/instructor are passed
 * as plain query parameters so they can be prefilled later if field IDs are added.
 */
export function buildEnrolmentFormUrl(input: {
  courseTitle: string;
  option?: string;
  levelName?: string;
  instructorName?: string;
}) {
  const params = new URLSearchParams();
  params.set("course", input.courseTitle);
  if (input.option) params.set("option", input.option);
  if (input.levelName) params.set("level", input.levelName);
  if (input.instructorName) params.set("instructor", input.instructorName);
  return `${ENROLMENT_FORM_URL}?${params.toString()}`;
}
