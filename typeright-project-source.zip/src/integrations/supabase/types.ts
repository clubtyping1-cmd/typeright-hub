export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_audit_log: {
        Row: {
          action: string
          actor_id: string
          created_at: string
          details: Json
          id: string
          target_id: string | null
          target_type: string
        }
        Insert: {
          action: string
          actor_id: string
          created_at?: string
          details?: Json
          id?: string
          target_id?: string | null
          target_type: string
        }
        Update: {
          action?: string
          actor_id?: string
          created_at?: string
          details?: Json
          id?: string
          target_id?: string | null
          target_type?: string
        }
        Relationships: []
      }
      announcements: {
        Row: {
          audience: string
          body: string | null
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          link_url: string | null
          published_at: string
          title: string
          updated_at: string
        }
        Insert: {
          audience?: string
          body?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          link_url?: string | null
          published_at?: string
          title: string
          updated_at?: string
        }
        Update: {
          audience?: string
          body?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          link_url?: string | null
          published_at?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      assessment_attempts: {
        Row: {
          assessment_name: string
          course_slug: string | null
          created_at: string
          id: string
          remarks: string | null
          scheduled_at: string | null
          score: number | null
          status: string
          updated_at: string
          user_id: string
          wpm: number | null
        }
        Insert: {
          assessment_name: string
          course_slug?: string | null
          created_at?: string
          id?: string
          remarks?: string | null
          scheduled_at?: string | null
          score?: number | null
          status?: string
          updated_at?: string
          user_id: string
          wpm?: number | null
        }
        Update: {
          assessment_name?: string
          course_slug?: string | null
          created_at?: string
          id?: string
          remarks?: string | null
          scheduled_at?: string | null
          score?: number | null
          status?: string
          updated_at?: string
          user_id?: string
          wpm?: number | null
        }
        Relationships: []
      }
      badges: {
        Row: {
          code: string
          created_at: string
          description: string
          label: string
          sort_order: number
        }
        Insert: {
          code: string
          created_at?: string
          description?: string
          label: string
          sort_order?: number
        }
        Update: {
          code?: string
          created_at?: string
          description?: string
          label?: string
          sort_order?: number
        }
        Relationships: []
      }
      certificates: {
        Row: {
          certificate_number: string
          course_slug: string | null
          created_at: string
          file_url: string | null
          id: string
          issued_at: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          certificate_number: string
          course_slug?: string | null
          created_at?: string
          file_url?: string | null
          id?: string
          issued_at?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          certificate_number?: string
          course_slug?: string | null
          created_at?: string
          file_url?: string | null
          id?: string
          issued_at?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      class_attendees: {
        Row: {
          attendance_status: string
          created_at: string
          enrolment_id: string | null
          id: string
          marked_at: string | null
          session_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          attendance_status?: string
          created_at?: string
          enrolment_id?: string | null
          id?: string
          marked_at?: string | null
          session_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          attendance_status?: string
          created_at?: string
          enrolment_id?: string | null
          id?: string
          marked_at?: string | null
          session_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "class_attendees_enrolment_id_fkey"
            columns: ["enrolment_id"]
            isOneToOne: false
            referencedRelation: "enrolments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "class_attendees_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "course_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      course_sessions: {
        Row: {
          cancellation_reason: string | null
          capacity: number | null
          course_slug: string
          created_at: string
          ends_at: string | null
          id: string
          instructor_name: string | null
          join_url: string | null
          location: string | null
          mode: string
          notes: string | null
          original_starts_at: string | null
          session_type: string
          starts_at: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          cancellation_reason?: string | null
          capacity?: number | null
          course_slug: string
          created_at?: string
          ends_at?: string | null
          id?: string
          instructor_name?: string | null
          join_url?: string | null
          location?: string | null
          mode?: string
          notes?: string | null
          original_starts_at?: string | null
          session_type?: string
          starts_at: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          cancellation_reason?: string | null
          capacity?: number | null
          course_slug?: string
          created_at?: string
          ends_at?: string | null
          id?: string
          instructor_name?: string | null
          join_url?: string | null
          location?: string | null
          mode?: string
          notes?: string | null
          original_starts_at?: string | null
          session_type?: string
          starts_at?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      enrolments: {
        Row: {
          activated_at: string | null
          activated_by: string | null
          completed_at: string | null
          course_slug: string
          created_at: string
          id: string
          instructor_name: string | null
          last_accessed_at: string | null
          level_name: string | null
          next_lesson_title: string | null
          paid_at: string | null
          payment_amount_bnd: number | null
          payment_note: string | null
          payment_reference: string | null
          progress_percent: number
          source_order_id: string | null
          started_at: string
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          activated_at?: string | null
          activated_by?: string | null
          completed_at?: string | null
          course_slug: string
          created_at?: string
          id?: string
          instructor_name?: string | null
          last_accessed_at?: string | null
          level_name?: string | null
          next_lesson_title?: string | null
          paid_at?: string | null
          payment_amount_bnd?: number | null
          payment_note?: string | null
          payment_reference?: string | null
          progress_percent?: number
          source_order_id?: string | null
          started_at?: string
          status?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          activated_at?: string | null
          activated_by?: string | null
          completed_at?: string | null
          course_slug?: string
          created_at?: string
          id?: string
          instructor_name?: string | null
          last_accessed_at?: string | null
          level_name?: string | null
          next_lesson_title?: string | null
          paid_at?: string | null
          payment_amount_bnd?: number | null
          payment_note?: string | null
          payment_reference?: string | null
          progress_percent?: number
          source_order_id?: string | null
          started_at?: string
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "enrolments_source_order_id_fkey"
            columns: ["source_order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      entitlements: {
        Row: {
          code: string
          created_at: string
          description: string
        }
        Insert: {
          code: string
          created_at?: string
          description: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string
        }
        Relationships: []
      }
      learner_badges: {
        Row: {
          awarded_at: string
          awarded_by: string | null
          badge_code: string
          id: string
          user_id: string
        }
        Insert: {
          awarded_at?: string
          awarded_by?: string | null
          badge_code: string
          id?: string
          user_id: string
        }
        Update: {
          awarded_at?: string
          awarded_by?: string | null
          badge_code?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "learner_badges_badge_code_fkey"
            columns: ["badge_code"]
            isOneToOne: false
            referencedRelation: "badges"
            referencedColumns: ["code"]
          },
        ]
      }
      learner_levels: {
        Row: {
          created_at: string
          level: number
          level_name: string
          updated_at: string
          updated_by: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          level?: number
          level_name?: string
          updated_at?: string
          updated_by?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          level?: number
          level_name?: string
          updated_at?: string
          updated_by?: string | null
          user_id?: string
        }
        Relationships: []
      }
      news_posts: {
        Row: {
          author: string
          body: string | null
          category: string
          cover_url: string | null
          created_at: string
          created_by: string | null
          excerpt: string | null
          id: string
          is_published: boolean
          published_at: string
          slug: string
          title: string
          updated_at: string
        }
        Insert: {
          author?: string
          body?: string | null
          category?: string
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string
          slug: string
          title: string
          updated_at?: string
        }
        Update: {
          author?: string
          body?: string | null
          category?: string
          cover_url?: string | null
          created_at?: string
          created_by?: string | null
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string
          slug?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          payload: Json
          read_at: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          payload?: Json
          read_at?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          payload?: Json
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      order_items: {
        Row: {
          course_slug: string
          created_at: string
          id: string
          instructor_name: string | null
          level_name: string | null
          line_total: number
          order_id: string
          quotation_required: boolean
          title: string
          unit_price: number
        }
        Insert: {
          course_slug: string
          created_at?: string
          id?: string
          instructor_name?: string | null
          level_name?: string | null
          line_total?: number
          order_id: string
          quotation_required?: boolean
          title: string
          unit_price?: number
        }
        Update: {
          course_slug?: string
          created_at?: string
          id?: string
          instructor_name?: string | null
          level_name?: string | null
          line_total?: number
          order_id?: string
          quotation_required?: boolean
          title?: string
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          contact_email: string
          contact_name: string
          contact_phone: string
          created_at: string
          currency: string
          id: string
          notes: string | null
          order_number: string
          organisation: string | null
          payment_method: string
          status: string
          subtotal: number
          total: number
          updated_at: string
          user_id: string
        }
        Insert: {
          contact_email: string
          contact_name: string
          contact_phone: string
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          order_number: string
          organisation?: string | null
          payment_method?: string
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          contact_email?: string
          contact_name?: string
          contact_phone?: string
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          order_number?: string
          organisation?: string | null
          payment_method?: string
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      organisation_enquiries: {
        Row: {
          contact_email: string
          contact_name: string
          contact_phone: string | null
          created_at: string
          handled_at: string | null
          handled_by: string | null
          id: string
          notes: string | null
          organisation_name: string
          plan_interest: string | null
          seats: number | null
          status: string
          updated_at: string
        }
        Insert: {
          contact_email: string
          contact_name: string
          contact_phone?: string | null
          created_at?: string
          handled_at?: string | null
          handled_by?: string | null
          id?: string
          notes?: string | null
          organisation_name: string
          plan_interest?: string | null
          seats?: number | null
          status?: string
          updated_at?: string
        }
        Update: {
          contact_email?: string
          contact_name?: string
          contact_phone?: string | null
          created_at?: string
          handled_at?: string | null
          handled_by?: string | null
          id?: string
          notes?: string | null
          organisation_name?: string
          plan_interest?: string | null
          seats?: number | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      organisation_licence_assignments: {
        Row: {
          assigned_at: string
          id: string
          licence_id: string
          revoked_at: string | null
          user_id: string
        }
        Insert: {
          assigned_at?: string
          id?: string
          licence_id: string
          revoked_at?: string | null
          user_id: string
        }
        Update: {
          assigned_at?: string
          id?: string
          licence_id?: string
          revoked_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organisation_licence_assignments_licence_id_fkey"
            columns: ["licence_id"]
            isOneToOne: false
            referencedRelation: "organisation_licences"
            referencedColumns: ["id"]
          },
        ]
      }
      organisation_licences: {
        Row: {
          created_at: string
          ends_at: string | null
          id: string
          notes: string | null
          organisation_id: string
          plan_id: string
          seats_total: number
          starts_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          ends_at?: string | null
          id?: string
          notes?: string | null
          organisation_id: string
          plan_id: string
          seats_total?: number
          starts_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          ends_at?: string | null
          id?: string
          notes?: string | null
          organisation_id?: string
          plan_id?: string
          seats_total?: number
          starts_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "organisation_licences_organisation_id_fkey"
            columns: ["organisation_id"]
            isOneToOne: false
            referencedRelation: "organisations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "organisation_licences_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      organisation_members: {
        Row: {
          created_at: string
          id: string
          invited_email: string | null
          member_role: string
          organisation_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invited_email?: string | null
          member_role?: string
          organisation_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invited_email?: string | null
          member_role?: string
          organisation_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organisation_members_organisation_id_fkey"
            columns: ["organisation_id"]
            isOneToOne: false
            referencedRelation: "organisations"
            referencedColumns: ["id"]
          },
        ]
      }
      organisations: {
        Row: {
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          id: string
          name: string
          notes: string | null
          updated_at: string
        }
        Insert: {
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          name: string
          notes?: string | null
          updated_at?: string
        }
        Update: {
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      plan_entitlements: {
        Row: {
          entitlement_code: string
          plan_id: string
        }
        Insert: {
          entitlement_code: string
          plan_id: string
        }
        Update: {
          entitlement_code?: string
          plan_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "plan_entitlements_entitlement_code_fkey"
            columns: ["entitlement_code"]
            isOneToOne: false
            referencedRelation: "entitlements"
            referencedColumns: ["code"]
          },
          {
            foreignKeyName: "plan_entitlements_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      plan_prices: {
        Row: {
          amount_bnd: number | null
          created_at: string
          id: string
          interval: string
          is_active: boolean
          plan_id: string
          updated_at: string
        }
        Insert: {
          amount_bnd?: number | null
          created_at?: string
          id?: string
          interval: string
          is_active?: boolean
          plan_id: string
          updated_at?: string
        }
        Update: {
          amount_bnd?: number | null
          created_at?: string
          id?: string
          interval?: string
          is_active?: boolean
          plan_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "plan_prices_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      programmes: {
        Row: {
          created_at: string
          default_instructor: string | null
          id: string
          is_active: boolean
          slug: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          default_instructor?: string | null
          id?: string
          is_active?: boolean
          slug: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          default_instructor?: string | null
          id?: string
          is_active?: boolean
          slug?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      promo_codes: {
        Row: {
          applies_to_plan_id: string | null
          code: string
          created_at: string
          description: string | null
          discount_amount_bnd: number | null
          discount_percent: number | null
          expires_at: string | null
          id: string
          is_active: boolean
          max_redemptions: number | null
          redeemed_count: number
          starts_at: string | null
          updated_at: string
        }
        Insert: {
          applies_to_plan_id?: string | null
          code: string
          created_at?: string
          description?: string | null
          discount_amount_bnd?: number | null
          discount_percent?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_redemptions?: number | null
          redeemed_count?: number
          starts_at?: string | null
          updated_at?: string
        }
        Update: {
          applies_to_plan_id?: string | null
          code?: string
          created_at?: string
          description?: string | null
          discount_amount_bnd?: number | null
          discount_percent?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_redemptions?: number | null
          redeemed_count?: number
          starts_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_codes_applies_to_plan_id_fkey"
            columns: ["applies_to_plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      promo_redemptions: {
        Row: {
          amount_bnd: number | null
          created_at: string
          id: string
          promo_id: string
          subscription_id: string | null
          user_id: string
        }
        Insert: {
          amount_bnd?: number | null
          created_at?: string
          id?: string
          promo_id: string
          subscription_id?: string | null
          user_id: string
        }
        Update: {
          amount_bnd?: number | null
          created_at?: string
          id?: string
          promo_id?: string
          subscription_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "promo_redemptions_promo_id_fkey"
            columns: ["promo_id"]
            isOneToOne: false
            referencedRelation: "promo_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "promo_redemptions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_events: {
        Row: {
          actor_id: string | null
          created_at: string
          event_type: string
          from_status: string | null
          id: string
          notes: string | null
          payload: Json
          subscription_id: string
          to_status: string | null
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          event_type: string
          from_status?: string | null
          id?: string
          notes?: string | null
          payload?: Json
          subscription_id: string
          to_status?: string | null
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          event_type?: string
          from_status?: string | null
          id?: string
          notes?: string | null
          payload?: Json
          subscription_id?: string
          to_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscription_events_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_payments: {
        Row: {
          amount_bnd: number
          approved_at: string | null
          approved_by: string | null
          billing_period_end: string | null
          billing_period_start: string | null
          created_at: string
          currency: string
          id: string
          method: string
          proof_path: string | null
          reference: string | null
          rejected_reason: string | null
          status: string
          subscription_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_bnd: number
          approved_at?: string | null
          approved_by?: string | null
          billing_period_end?: string | null
          billing_period_start?: string | null
          created_at?: string
          currency?: string
          id?: string
          method?: string
          proof_path?: string | null
          reference?: string | null
          rejected_reason?: string | null
          status?: string
          subscription_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_bnd?: number
          approved_at?: string | null
          approved_by?: string | null
          billing_period_end?: string | null
          billing_period_start?: string | null
          created_at?: string
          currency?: string
          id?: string
          method?: string
          proof_path?: string | null
          reference?: string | null
          rejected_reason?: string | null
          status?: string
          subscription_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscription_payments_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          code: string
          created_at: string
          cta_label: string
          description: string | null
          id: string
          is_active: boolean
          kind: string
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          cta_label?: string
          description?: string | null
          id?: string
          is_active?: boolean
          kind?: string
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          cta_label?: string
          description?: string | null
          id?: string
          is_active?: boolean
          kind?: string
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          activated_at: string | null
          cancel_at_period_end: boolean
          cancelled_at: string | null
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          grace_until: string | null
          id: string
          organisation_id: string | null
          plan_id: string
          price_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          activated_at?: string | null
          cancel_at_period_end?: boolean
          cancelled_at?: string | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          grace_until?: string | null
          id?: string
          organisation_id?: string | null
          plan_id: string
          price_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          activated_at?: string | null
          cancel_at_period_end?: boolean
          cancelled_at?: string | null
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          grace_until?: string | null
          id?: string
          organisation_id?: string | null
          plan_id?: string
          price_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_organisation_id_fkey"
            columns: ["organisation_id"]
            isOneToOne: false
            referencedRelation: "organisations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_price_id_fkey"
            columns: ["price_id"]
            isOneToOne: false
            referencedRelation: "plan_prices"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_order_number: { Args: never; Returns: string }
      has_entitlement: {
        Args: { _code: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_org_admin: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
      my_org_ids: {
        Args: { _user_id: string }
        Returns: {
          organisation_id: string
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "instructor" | "user" | "org_admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "instructor", "user", "org_admin"],
    },
  },
} as const
