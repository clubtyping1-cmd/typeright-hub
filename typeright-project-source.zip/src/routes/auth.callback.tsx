import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth/callback")({
  head: () => ({
    meta: [{ title: "Signing you in — TypeRight Hub" }],
  }),
  component: AuthCallback,
});

function AuthCallback() {
  const navigate = useNavigate();
  const [message, setMessage] = useState("Signing you in…");

  useEffect(() => {
    const go = async () => {
      const { data } = await supabase.auth.getSession();
      const stored = typeof window !== "undefined" ? sessionStorage.getItem("post_auth_redirect") : null;
      const dest = stored && stored.startsWith("/") && !stored.startsWith("//") ? stored : "/dashboard";
      if (stored) sessionStorage.removeItem("post_auth_redirect");
      if (data.session) {
        navigate({ to: dest, replace: true });
      } else {
        setMessage("Waiting for session…");
      }
    };
    void go();
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) void go();
    });
    const timeout = setTimeout(() => {
      setMessage("Sign-in didn't complete. Redirecting…");
      navigate({ to: "/auth", replace: true });
    }, 8000);
    return () => {
      sub.subscription.unsubscribe();
      clearTimeout(timeout);
    };
  }, [navigate]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-background text-foreground">
      <p className="text-sm text-muted-foreground">{message}</p>
    </main>
  );
}