import { createFileRoute } from "@tanstack/react-router";

import { ServicesHero } from "@/components/services/ServicesHero";
import { ServicesCarousel } from "@/components/services/ServicesCarousel";
import { TestimonialsSection } from "@/components/services/TestimonialsSection";
import { PhotoGallery } from "@/components/services/PhotoGallery";
import { CompactCTA } from "@/components/services/CompactCTA";
import { TopBar } from "@/components/site/TopBar";
import { HeroSection } from "@/components/site/HeroSection";

import { SiteFooter } from "@/components/site/SiteFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title:
          "TypeRight Hub — Digital Typing & Shorthand Training in Brunei",
      },
      {
        name: "description",
        content:
          "TypeRight provides digital typing, shorthand and trainer certification programmes with competency assessments for students, professionals and organisations in Brunei Darussalam.",
      },
      {
        property: "og:title",
        content: "TypeRight Hub — Digital Learning, Assessment & Workforce Development",
      },
      {
        property: "og:description",
        content:
          "Practical training and competency assessments in digital typing and shorthand for Brunei's workforce.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen bg-background text-foreground [scroll-behavior:smooth]">
      <TopBar />
      <HeroSection />

      <ServicesHero />

      <TestimonialsSection />

      <ServicesCarousel
        eyebrow="What we offer"
        heading="Learn essential career and digital skills"
        description="Digital typing and shorthand — the same programmes you can explore and enrol in on our Courses page."
      />

      <PhotoGallery />
      <CompactCTA />
      <SiteFooter />
    </main>
  );
}
