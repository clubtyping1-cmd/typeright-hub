import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap, Users, Sparkles, CheckCircle2, ExternalLink } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";
import { ENROLMENT_FORM_URL } from "@/lib/enrolment";

export const Route = createFileRoute("/type-for-school")({
  head: () => ({
    meta: [
      { title: "Type for School — Typing Clubs in Brunei" },
      {
        name: "description",
        content:
          "TypeRight school clubs bring fun, structured digital typing, shorthand and AI literacy sessions to Brunei schools as after-school or co-curricular programmes.",
      },
      { property: "og:title", content: "Type for School — Typing Clubs in Brunei" },
      {
        property: "og:description",
        content:
          "After-school typing clubs for Brunei schools. Build digital confidence, speed and accuracy through weekly instructor-led sessions.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TypeForSchoolPage,
});

const benefits = [
  {
    icon: GraduationCap,
    title: "Build real keyboard confidence",
    body: "Students move from hunt-and-peck to accurate touch typing through short, focused drills designed for young learners.",
  },
  {
    icon: Users,
    title: "Skills that show in every subject",
    body: "Faster, more accurate typing and digital note-taking help students complete assignments, research and projects with less friction.",
  },
  {
    icon: Sparkles,
    title: "Certificates and milestones",
    body: "Progressive badges, timed benchmarks and certificates keep students motivated and give parents something to celebrate.",
  },
];

const steps = [
  {
    title: "1. Set up the club",
    body: "Choose a weekly slot after school or during a co-curricular block. We supply the curriculum, materials and coach.",
  },
  {
    title: "2. Weekly sessions",
    body: "Instructor-led drills, games, shorthand warm-ups and AI literacy mini-lessons that fit the school term.",
  },
  {
    title: "3. Track and celebrate",
    body: "Term reports show words-per-minute growth, accuracy gains and completed milestones for every student.",
  },
];

const formats = [
  {
    title: "Onsite at school",
    body: "A TypeRight coach runs the club in the school's computer lab or classroom with school devices.",
  },
  {
    title: "Online after school",
    body: "Live virtual sessions students can join from home — ideal for older students or holiday programmes.",
  },
  {
    title: "Hybrid",
    body: "Alternate onsite coaching with online practice weeks so students keep momentum between sessions.",
  },
];

function TypeForSchoolPage() {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />

      <section className="border-b border-border bg-gradient-to-br from-primary/95 to-primary text-primary-foreground">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">For schools</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-bold tracking-tight sm:text-5xl">
            Typing clubs for Brunei schools
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-primary-foreground/80">
            Give students a fun, structured place to master digital typing, shorthand and everyday AI literacy
            — one weekly session at a time.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <a href={ENROLMENT_FORM_URL} target="_blank" rel="noopener noreferrer">
                Register a school club
                <ExternalLink className="ml-2 h-4 w-4" aria-hidden />
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Why schools run a TypeRight club</h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          A co-curricular programme that builds digital fluency, confidence and certificates students can use for life.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {benefits.map(({ icon: Icon, title, body }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/15 text-accent">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-secondary/40">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-foreground">How a school club runs</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.title} className="rounded-2xl border border-border bg-card p-6">
                <p className="text-sm font-semibold text-accent">{s.title}</p>
                <p className="mt-3 text-sm text-muted-foreground">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Flexible club formats</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {formats.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6">
              <p className="text-sm font-semibold text-accent">{f.title}</p>
              <p className="mt-3 text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 rounded-2xl border border-border bg-card p-6">
          <h3 className="text-lg font-semibold text-foreground">Every club includes</h3>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {[
              "Instructor-led weekly sessions",
              "Student progress tracking",
              "Practice drills and games",
              "Term-end certificates",
              "Parent progress reports",
              "Optional inter-school benchmarks",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2 text-sm text-foreground">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 text-center sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Ready to start a TypeRight club?</h2>
        <p className="mt-4 text-muted-foreground">
          Register your school and we'll share a term plan, schedule and pricing options.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <a href={ENROLMENT_FORM_URL} target="_blank" rel="noopener noreferrer">
              Register a school club
              <ExternalLink className="ml-2 h-4 w-4" aria-hidden />
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}
