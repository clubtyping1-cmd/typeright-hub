import { createFileRoute, Link, notFound, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";
import { ProgrammeTemplate } from "@/components/courses/templates/ProgrammeTemplate";
import { TrainerTemplate } from "@/components/courses/templates/TrainerTemplate";
import { getCourseBySlug } from "@/data/courses";
import { touchCourseAccess } from "@/lib/learning.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/courses/$courseSlug/")({
  loader: ({ params }) => {
    const course = getCourseBySlug(params.courseSlug);
    if (!course) throw notFound();
    return {
      course: {
        slug: course.slug,
        title: course.title,
        tagline: course.tagline,
      },
    };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Course not found — TypeRight Hub" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const { course } = loaderData;
    const title = `${course.title} — TypeRight Hub`;
    return {
      meta: [
        { title },
        { name: "description", content: course.tagline },
        { property: "og:title", content: title },
        { property: "og:description", content: course.tagline },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: CourseDetailPage,
  pendingComponent: CoursePending,
  errorComponent: CourseError,
  notFoundComponent: CourseNotFound,
});

function CoursePending() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <p className="text-sm font-medium text-muted-foreground">Loading course…</p>
      </section>
    </main>
  );
}

function CourseError({ reset }: { error: Error; reset: () => void }) {
  const router = useRouter();

  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-3xl font-semibold">Course couldn&apos;t load</h1>
        <p className="mt-2 text-muted-foreground">
          Please try opening the course again.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Button
            onClick={() => {
              router.invalidate();
              reset();
            }}
          >
            Try again
          </Button>
          <Button asChild variant="outline">
            <Link to="/courses">Back to all courses</Link>
          </Button>
        </div>
      </section>
    </main>
  );
}

function CourseNotFound() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-3xl font-semibold">Course not found</h1>
        <p className="mt-2 text-muted-foreground">
          This course doesn&apos;t exist or has been moved.
        </p>
        <div className="mt-6">
          <Button asChild>
            <Link to="/courses">Back to all courses</Link>
          </Button>
        </div>
      </section>
    </main>
  );
}

function CourseDetailPage() {
  const { courseSlug } = Route.useParams();
  const course = getCourseBySlug(courseSlug);

  if (!course) return <CourseNotFound />;

  const levels = course.levels ?? [];
  const [levelId, setLevelId] = useState<string>(levels[0]?.level ?? "");

  const touch = useServerFn(touchCourseAccess);
  useEffect(() => {
    let cancelled = false;
    void supabase.auth.getSession().then(({ data }) => {
      if (cancelled || !data.session) return;
      void touch({ data: { courseSlug: course.slug } }).catch(() => {});
    });
    return () => {
      cancelled = true;
    };
  }, [course.slug]);

  const templateProps = {
    course,
    levels,
    levelId,
    setLevelId,
  };

  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />
      {course.category === "trainer" ? (
        <TrainerTemplate {...templateProps} />
      ) : (
        <ProgrammeTemplate {...templateProps} />
      )}
    </main>
  );
}
