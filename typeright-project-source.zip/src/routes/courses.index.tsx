import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ExternalLink } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";
import { CourseCard } from "@/components/courses/CourseCard";
import { courses, type Course } from "@/data/courses";
import { ENROLMENT_FORM_URL } from "@/lib/enrolment";

export const Route = createFileRoute("/courses/")({
  head: () => ({
    meta: [
      { title: "Courses — TypeRight Hub" },
      {
        name: "description",
        content:
          "Explore TypeRight's core courses: Digital Typing, Digital Shorthand (English & Malay) and AI Literacy for the modern Brunei workplace.",
      },
      { property: "og:title", content: "Courses — TypeRight Hub" },
      {
        property: "og:description",
        content:
          "Digital Typing, Digital Shorthand and AI Literacy courses for students, professionals and organisations in Brunei.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CoursesPage,
});

const categoryLabels: Record<Course["category"], string> = {
  programme: "Core programmes",
  trainer: "Train-the-trainer",
};

const categoryOrder: Course["category"][] = ["programme"];

const categoryTo: Record<Course["category"], string> = {
  programme: "/courses/programmes",
  trainer: "/courses/trainer",
};

function CoursesPage() {
  const grouped = categoryOrder
    .map((cat) => ({ cat, items: courses.filter((c) => c.category === cat) }))
    .filter((g) => g.items.length > 0);

  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />

      <section className="border-b border-border bg-gradient-to-b from-secondary/60 to-background">
        <div className="mx-auto max-w-7xl px-6 py-16 sm:py-20">
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-accent">
            Our courses
          </p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
            Products, programmes and services
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            The full TypeRight Hub catalogue — keyboard mastery, shorthand and
            AI-enabled clerical and executive support programmes.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <a href={ENROLMENT_FORM_URL} target="_blank" rel="noopener noreferrer">
                Enrol via form
                <ExternalLink className="ml-2 h-4 w-4" aria-hidden />
              </a>
            </Button>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            One enrolment form covers all courses — select your programme, level
            and instructor inside the form.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 sm:py-20 space-y-14">
        {grouped.map(({ cat, items }) => (
          <div key={cat}>
            <div className="flex items-end justify-between gap-4">
              <h2 className="text-2xl font-semibold tracking-tight text-foreground">
                {categoryLabels[cat]}
              </h2>
              <Link
                to={categoryTo[cat]}
                className="shrink-0 text-sm font-medium text-accent hover:underline"
              >
                View all
                <ArrowRight className="ml-1 inline h-4 w-4" aria-hidden />
              </Link>
            </div>
            <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {items.slice(0, 3).map((c) => (
                <CourseCard key={c.slug} course={c} />
              ))}
            </div>
          </div>
        ))}
      </section>

      <section className="bg-secondary/40 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            Not sure which course fits you?
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Tell us your goals and we'll recommend a learning pathway for you or
            your organisation.
          </p>
        </div>
      </section>
    </main>
  );
}