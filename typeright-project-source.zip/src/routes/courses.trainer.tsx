import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/courses/CategoryPage";

export const Route = createFileRoute("/courses/trainer")({
  head: () => ({
    meta: [
      { title: "Train-the-trainer — TypeRight Hub" },
      { name: "description", content: "Certify your own trainers to deliver TypeRight programmes in-house." },
      { property: "og:title", content: "Train-the-trainer — TypeRight Hub" },
      { property: "og:description", content: "Certify your own trainers to deliver TypeRight programmes in-house." },
    ],
  }),
  component: () => (
    <CategoryPage
      category="trainer"
      eyebrow="Train-the-trainer"
      title="Certify your in-house trainers"
      intro="Equip your team to deliver TypeRight programmes with confidence, quality and consistency."
    />
  ),
});