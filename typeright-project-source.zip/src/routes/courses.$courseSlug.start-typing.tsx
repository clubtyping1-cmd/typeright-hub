import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Keyboard } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/courses/$courseSlug/start-typing")({
  head: () => ({
    meta: [
      { title: "Start typing — TypeRight Hub" },
      {
        name: "description",
        content: "Launch the TypeRight typing practice workspace for this course.",
      },
      { property: "og:title", content: "Start typing — TypeRight Hub" },
      {
        property: "og:description",
        content: "Launch the TypeRight typing practice workspace for this course.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: StartTypingPage,
});

function StartTypingPage() {
  const { courseSlug } = Route.useParams();

  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />

      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Keyboard className="h-8 w-8" aria-hidden />
        </div>

        <h1 className="mt-6 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          Start typing
        </h1>

        <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-muted-foreground">
          The typing workspace for this course is coming soon. Check back shortly to
          practise lessons, drills and timed tests.
        </p>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild variant="outline">
            <Link
              to="/courses/$courseSlug"
              params={{ courseSlug }}
              className="inline-flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden />
              Back to course
            </Link>
          </Button>
        </div>
      </section>
    </main>
  );
}
