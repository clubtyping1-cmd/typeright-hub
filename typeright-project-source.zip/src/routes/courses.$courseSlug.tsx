import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/courses/$courseSlug")({
  component: CourseSlugLayout,
});

function CourseSlugLayout() {
  return <Outlet />;
}
