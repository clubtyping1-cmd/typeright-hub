import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";

import { TopBar } from "@/components/site/TopBar";
import { SiteFooter } from "@/components/site/SiteFooter";
import { NewsFeatured } from "@/components/news/NewsFeatured";
import { NewsCard } from "@/components/news/NewsCard";
import { NewsCategorySidebar } from "@/components/news/NewsCategorySidebar";
import { listPublishedNews } from "@/lib/news.functions";
import type { NewsPost } from "@/lib/news.constants";

const newsQuery = queryOptions({
  queryKey: ["news", "published"],
  queryFn: () => listPublishedNews(),
});

const title = "News — TypeRight Hub";
const description =
  "Announcements, examination schedules and programme updates from TypeRight Hub in Brunei Darussalam.";

export const Route = createFileRoute("/news/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(newsQuery),
  component: NewsIndex,
  errorComponent: NewsError,
});

function PageTitle() {
  return (
    <div className="mx-auto max-w-6xl px-6 pt-14 sm:pt-20">
      <h1 className="text-5xl font-extrabold uppercase tracking-tight text-foreground sm:text-6xl">
        News
      </h1>
      <div className="mt-10 border-t border-border" />
    </div>
  );
}

function NewsError() {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <PageTitle />
      <div className="mx-auto max-w-6xl px-6 py-20 text-muted-foreground">
        We couldn't load the news right now. Please try again shortly.
      </div>
      <SiteFooter />
    </div>
  );
}

function NewsIndex() {
  const { data } = useSuspenseQuery(newsQuery);
  const posts = (data?.posts ?? []) as NewsPost[];
  const [selected, setSelected] = useState<string | null>(null);

  const categories = useMemo(() => {
    const counts = new Map<string, number>();
    posts.forEach((p) => counts.set(p.category, (counts.get(p.category) ?? 0) + 1));
    return [...counts.entries()].map(([category, count]) => ({ category, count }));
  }, [posts]);

  const filtered = selected ? posts.filter((p) => p.category === selected) : posts;
  const [featured, ...rest] = filtered;

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main>
        <PageTitle />

        <section className="mx-auto max-w-6xl px-6 py-10 sm:py-14">
          {posts.length === 0 ? (
            <p className="text-muted-foreground">
              There are no news posts yet. Please check back soon.
            </p>
          ) : (
            <div className="grid gap-10 lg:grid-cols-[200px_1fr] lg:gap-12">
              <NewsCategorySidebar
                items={categories}
                selected={selected}
                onSelect={setSelected}
              />

              <div className="min-w-0">
                {filtered.length === 0 ? (
                  <p className="text-muted-foreground">
                    There are no posts in this category yet.
                  </p>
                ) : (
                  <>
                    {featured && <NewsFeatured post={featured} />}

                    {rest.length > 0 && (
                      <div className="mt-16">
                        <h2 className="text-lg font-bold uppercase tracking-tight text-foreground">
                          Latest <span className="text-muted-foreground">Articles</span>
                        </h2>
                        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                          {rest.map((post) => (
                            <NewsCard key={post.id} post={post} />
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
