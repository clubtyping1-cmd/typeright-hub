import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Loader2 } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { listPublicPlans } from "@/lib/subscriptions.functions";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — TypeRight Hub" },
      { name: "description", content: "Choose a Digital Typing or Digital Shorthand practice subscription in BND, daily, weekly or monthly." },
      { property: "og:title", content: "Pricing — TypeRight Hub" },
      { property: "og:description", content: "Digital typing and shorthand practice subscriptions in BND, daily, weekly or monthly." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PricingPage,
});

type Interval = "daily" | "weekly" | "monthly";

const ENTITLEMENT_LABEL: Record<string, string> = {
  trt_full_access: "Full Digital Typing practice",
  trs_full_access: "Full Digital Shorthand practice",
  trt_preview: "Typing preview passages",
  trs_preview: "Shorthand preview dictations",
  advanced_progress: "Advanced progress analytics",
  monthly_summary: "Monthly practice summary",
  organisation_reporting: "Organisation-level reporting",
  priority_registration: "Priority course & assessment registration",
  subscriber_discount: "Subscriber discount on selected purchases",
};

const PLAN_HIGHLIGHTS: Record<string, string[]> = {
  trt: [
    "Structured passages by difficulty",
    "Timed typing exercises",
    "WPM and accuracy tracking",
    "Basic, Beginner, Intermediate & Advanced pathways",
    "Performance history",
    "Assessment-readiness indicator",
  ],
  trs: [
    "Fundamental and advanced exercises",
    "Dictation recordings",
    "Speed-building practice",
    "Transcription drills",
    "Practice history",
    "Exam preparation",
  ],
  complete: [
    "Everything in Digital Typing + Digital Shorthand",
    "Combined learner dashboard",
    "Monthly practice summary",
    "Priority registration",
    "Subscriber discounts",
  ],
};

function PricingPage() {
  const load = useServerFn(listPublicPlans);
  const [interval, setInterval] = useState<Interval>("monthly");

  const { data, isLoading } = useQuery({ queryKey: ["public-plans"], queryFn: () => load() });

  const priceByPlanInterval = useMemo(() => {
    const map = new Map<string, number | null>();
    for (const p of data?.prices ?? []) {
      map.set(`${p.plan_id}:${p.interval}`, p.amount_bnd == null ? null : Number(p.amount_bnd));
    }
    return map;
  }, [data]);

  const entitlementsByPlan = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const pe of data?.entitlements ?? []) {
      const arr = map.get(pe.plan_id) ?? [];
      arr.push(pe.entitlement_code);
      map.set(pe.plan_id, arr);
    }
    return map;
  }, [data]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopBar />
      <main>
        <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-accent">Subscriptions</p>
            <h1 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">Practice access, priced in BND</h1>
            <p className="mt-4 text-lg text-muted-foreground">
              Continuous access to Digital Typing and Digital Shorthand practice apps.
              Formal courses, official exams and certificates remain separate purchases.
            </p>
          </div>

          <div className="mt-10 flex items-center justify-center">
            <div role="tablist" className="inline-flex rounded-full border border-border bg-card p-1">
              {(["daily", "weekly", "monthly"] as Interval[]).map((i) => (
                <button
                  key={i}
                  role="tab"
                  aria-selected={interval === i}
                  onClick={() => setInterval(i)}
                  className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
                    interval === i ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {i[0].toUpperCase() + i.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="mt-16 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {(data?.plans ?? []).map((plan: any) => {
                const rawPrice = priceByPlanInterval.get(`${plan.id}:${interval}`);
                const noPriceForInterval = rawPrice == null;
                const codes = entitlementsByPlan.get(plan.id) ?? [];
                const featured = plan.code === "complete";
                return (
                  <article
                    key={plan.id}
                    className={`flex flex-col rounded-2xl border p-6 ${
                      featured ? "border-accent/60 bg-accent/5 shadow-sm" : "border-border bg-card"
                    }`}
                  >
                    {featured && (
                      <p className="mb-3 inline-flex w-fit rounded-full bg-accent/20 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-accent">
                        Best value
                      </p>
                    )}
                    <h2 className="text-xl font-semibold text-foreground">{plan.name}</h2>
                    <p className="mt-1.5 min-h-[3rem] text-sm text-muted-foreground">{plan.description}</p>
                    <div className="mt-5 min-h-[3.5rem]">
                      {noPriceForInterval ? (
                        <p className="text-sm text-muted-foreground">Not available {interval}</p>
                      ) : (
                        <div>
                          <span className="text-3xl font-bold">BND {rawPrice}</span>
                          <span className="ml-1 text-sm text-muted-foreground">/ {interval}</span>
                        </div>
                      )}
                    </div>

                    <ul className="mt-4 space-y-2 text-sm">
                      {(PLAN_HIGHLIGHTS[plan.code] ?? []).map((h) => (
                        <li key={h} className="flex items-start gap-2">
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>

                    {codes.length > 0 && (
                      <div className="mt-4 border-t border-border/60 pt-4">
                        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Includes entitlements</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {codes.map((c) => ENTITLEMENT_LABEL[c] ?? c).join(" · ")}
                        </p>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}

          <section className="mt-20">
            <h2 className="text-2xl font-bold tracking-tight">Frequently asked</h2>
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <FAQ q="Are formal courses and certificates included?" a="No. Subscriptions grant continuous access to the Digital Typing and Digital Shorthand practice apps only. Formal programmes, official examinations, retakes, certificates and transcripts remain separate purchases." />
              <FAQ q="How do I subscribe?" a="Complete the sign-up form and pay by Brunei bank transfer. Once our team verifies your payment, your plan is activated and appears on your dashboard." />
              <FAQ q="Can I cancel at any time?" a="Yes. Let us know and we will stop future renewal. You keep access until the end of your paid period, and your progress is preserved if you rejoin later." />
              <FAQ q="Do you offer discounts for schools or ministries?" a="Yes — request a Teams quotation. We tailor seat counts, billing cycles and organisation reporting to your needs." />
            </div>
          </section>
        </section>
      </main>
    </div>
  );
}

function FAQ({ q, a }: { q: string; a: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h3 className="text-base font-semibold text-foreground">{q}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{a}</p>
    </div>
  );
}
