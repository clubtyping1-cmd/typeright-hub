import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { submitTeamsEnquiry } from "@/lib/subscriptions.functions";

export const Route = createFileRoute("/pricing/teams")({
  head: () => ({
    meta: [
      { title: "Request a TypeRight Teams quotation" },
      { name: "description", content: "Get a tailored quotation for schools, ministries and organisations." },
      { property: "og:title", content: "Request a TypeRight Teams quotation" },
      { property: "og:description", content: "Multi-learner licences, dashboards and centralised billing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TeamsEnquiryPage,
});

function TeamsEnquiryPage() {
  const send = useServerFn(submitTeamsEnquiry);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    organisationName: "",
    contactName: "",
    contactEmail: "",
    contactPhone: "",
    seats: "",
    planInterest: "",
    notes: "",
    website: "",
  });

  const mutation = useMutation({
    mutationFn: () =>
      send({
        data: {
          organisationName: form.organisationName,
          contactName: form.contactName,
          contactEmail: form.contactEmail,
          contactPhone: form.contactPhone || undefined,
          seats: form.seats ? Number(form.seats) : undefined,
          planInterest: form.planInterest || undefined,
          notes: form.notes || undefined,
          website: form.website,
        },
      }),
    onSuccess: () => {
      toast.success("Thanks — we'll follow up shortly.");
      navigate({ to: "/pricing" });
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not submit enquiry."),
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <TopBar />
      <main className="mx-auto max-w-3xl px-4 py-14 sm:px-6">
        <Link to="/pricing" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ChevronLeft className="h-4 w-4" /> Back to pricing
        </Link>
        <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">Request a Teams quotation</h1>
        <p className="mt-2 text-muted-foreground">
          Tell us about your organisation and we'll prepare a tailored quotation with seats, plan mix and payment terms.
        </p>
        <form
          className="mt-8 grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!form.organisationName || !form.contactName || !form.contactEmail) {
              toast.error("Please fill in organisation name, contact name and email.");
              return;
            }
            mutation.mutate();
          }}
        >
          <input
            type="text"
            name="website"
            autoComplete="off"
            tabIndex={-1}
            aria-hidden
            value={form.website}
            onChange={(e) => setForm({ ...form, website: e.target.value })}
            className="hidden"
          />
          <div className="grid gap-2">
            <Label htmlFor="orgName">Organisation name</Label>
            <Input id="orgName" value={form.organisationName} onChange={(e) => setForm({ ...form, organisationName: e.target.value })} required />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="contactName">Contact name</Label>
              <Input id="contactName" value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="contactEmail">Contact email</Label>
              <Input id="contactEmail" type="email" value={form.contactEmail} onChange={(e) => setForm({ ...form, contactEmail: e.target.value })} required />
            </div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="contactPhone">Phone (optional)</Label>
              <Input id="contactPhone" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="seats">Estimated seats</Label>
              <Input id="seats" type="number" min={1} value={form.seats} onChange={(e) => setForm({ ...form, seats: e.target.value })} />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="planInterest">Plan of interest</Label>
            <Input id="planInterest" placeholder="Typing, Shorthand, Complete, or mix" value={form.planInterest} onChange={(e) => setForm({ ...form, planInterest: e.target.value })} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="notes">What are you trying to achieve?</Label>
            <Textarea id="notes" rows={5} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
          <Button type="submit" size="lg" disabled={mutation.isPending}>
            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Submit enquiry
          </Button>
        </form>
      </main>
    </div>
  );
}
