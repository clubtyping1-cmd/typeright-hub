import { createFileRoute } from "@tanstack/react-router";

import { TopBar } from "@/components/site/TopBar";
import { SiteFooter } from "@/components/site/SiteFooter";
import { AboutCompany } from "@/components/about/AboutCompany";
import { AboutPillars } from "@/components/about/AboutPillars";

const title = "Who We Are — TypeRight Hub";
const description =
  "TypeRight Management & Services is a Brunei-based training and digital-learning provider. Discover our vision, mission and three strategic thrusts.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main>
        <AboutCompany />
        <AboutPillars />
      </main>
      <SiteFooter />
    </div>
  );
}
