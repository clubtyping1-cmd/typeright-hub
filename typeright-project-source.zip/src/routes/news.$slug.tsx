import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { SiteFooter } from "@/components/site/SiteFooter";
import { getNewsPost } from "@/lib/news.functions";
import { readTime, type NewsPost } from "@/lib/news.constants";

const postQuery = (slug: string) =>
  queryOptions({
    queryKey: ["news", "post", slug],
    queryFn: () => getNewsPost({ data: { slug } }),
  });

export const Route = createFileRoute("/news/$slug")({
  loader: async ({ context, params }) => {
    const result = await context.queryClient.ensureQueryData(postQuery(params.slug));
    if (!result?.post) throw notFound();
    return result;
  },
  head: ({ loaderData }) => {
    const post = (loaderData as { post?: NewsPost } | undefined)?.post;
    if (!post) {
      return { meta: [{ title: "Not found — TypeRight Hub" }, { name: "robots", content: "noindex" }] };
    }
    const description = post.excerpt ?? `${post.title} — TypeRight Hub news.`;
    const meta: Array<Record<string, string>> = [
      { title: `${post.title} — TypeRight Hub` },
      { name: "description", content: description },
      { property: "og:title", content: post.title },
      { property: "og:description", content: description },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (post.cover_url?.startsWith("https://")) {
      meta.push({ property: "og:image", content: post.cover_url });
      meta.push({ name: "twitter:image", content: post.cover_url });
    }
    return { meta };
  },
  component: NewsArticle,
  notFoundComponent: NewsMissing,
  errorComponent: NewsMissing,
});

function NewsMissing() {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <div className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-2xl font-semibold text-foreground">This article isn't available</h1>
        <p className="mt-2 text-muted-foreground">It may have been moved or unpublished.</p>
        <Link to="/news" className="mt-6 inline-block text-sm font-semibold text-accent hover:underline">
          Back to all news
        </Link>
      </div>
      <SiteFooter />
    </div>
  );
}

function NewsArticle() {
  const { slug } = Route.useParams();
  const { data } = useSuspenseQuery(postQuery(slug));
  const post = data?.post as NewsPost | null;
  if (!post) return <NewsMissing />;

  const date = new Date(post.published_at).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main>
        <article className="mx-auto max-w-3xl px-6 py-12 sm:py-16">
          <Link
            to="/news"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            All news
          </Link>

          <span className="mt-6 inline-flex items-center rounded-full bg-accent/10 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-accent">
            {post.category}
          </span>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            {post.title}
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {post.author} · {date} · {readTime(post.body ?? post.excerpt)} min read
          </p>

          {post.cover_url && (
            <img
              src={post.cover_url}
              alt={post.title}
              className="mt-8 w-full rounded-2xl object-cover"
            />
          )}

          {post.excerpt && (
            <p className="mt-8 text-lg font-medium leading-relaxed text-foreground">{post.excerpt}</p>
          )}

          <div className="mt-6 space-y-4 text-base leading-relaxed text-foreground/85">
            {(post.body ?? "")
              .split(/\n{2,}/)
              .filter(Boolean)
              .map((para, i) => (
                <p key={i}>{para}</p>
              ))}
          </div>
        </article>
      </main>
      <SiteFooter />
    </div>
  );
}