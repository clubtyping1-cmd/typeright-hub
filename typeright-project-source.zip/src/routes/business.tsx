import { createFileRoute, Link } from "@tanstack/react-router";
import { Briefcase, BookOpen, Award, Users, CheckCircle2 } from "lucide-react";

import { TopBar } from "@/components/site/TopBar";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/business")({
  head: () => ({
    meta: [
      { title: "TypeRight Business — Teach TypeRight as a Freelancer" },
      {
        name: "description",
        content:
          "Become a certified TypeRight instructor or freelance trainer. Teach digital typing, shorthand and AI literacy in Brunei with proven curriculum and ongoing support.",
      },
      { property: "og:title", content: "TypeRight Business — Teach TypeRight as a Freelancer" },
      {
        property: "og:description",
        content:
          "Build your own training practice by teaching TypeRight courses. Get certified, receive materials and grow your freelance instructor business.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BusinessPage,
});

const benefits = [
  {
    icon: BookOpen,
    title: "Proven curriculum",
    body: "Teach from structured, workplace-tested programmes in Digital Typing, Digital Shorthand and AI Literacy.",
  },
  {
    icon: Award,
    title: "Certified instructor status",
    body: "Complete our train-the-trainer pathway and carry an official TypeRight instructor credential.",
  },
  {
    icon: Users,
    title: "Start your own practice",
    body: "Run classes for schools, individuals or organisations under your own freelance brand with our backing.",
  },
];

const steps = [
  {
    title: "1. Apply",
    body: "Tell us about your background, teaching goals and the audience you'd like to serve.",
  },
  {
    title: "2. Train and certify",
    body: "Join the TypeRight train-the-trainer programme and learn delivery, assessment and classroom management.",
  },
  {
    title: "3. Start teaching",
    body: "Use our materials to run your first classes, with ongoing coaching and quality checks as you grow.",
  },
];

const teachable = [
  {
    title: "Digital Typing",
    body: "Touch typing, speed drills, accuracy and workplace document production.",
  },
  {
    title: "Digital Shorthand",
    body: "English and Malay shorthand for note-taking, minutes and dictation.",
  },
  {
    title: "AI Literacy",
    body: "Practical prompting, drafting, review and automation for clerical and executive work.",
  },
];

const support = [
  "Complete lesson plans and slide decks",
  "Assessments and answer keys",
  "Certificate templates",
  "Coach access and peer tutor community",
  "Marketing guidance and brand assets",
  "Ongoing curriculum updates",
];

function BusinessPage() {
  return (
    <div className="min-h-screen bg-background">
      <TopBar />

      <section className="border-b border-border bg-gradient-to-br from-primary/95 to-primary text-primary-foreground">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
          <p className="text-sm font-semibold uppercase tracking-widest text-accent">For freelancers</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-bold tracking-tight sm:text-5xl">
            Teach TypeRight, build your own training practice
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-primary-foreground/80">
            Become a certified TypeRight instructor and deliver keyboard, shorthand and AI literacy training
            on your own terms — for schools, professionals and organisations across Brunei.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/courses/trainer">Explore train-the-trainer</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Why teach with TypeRight</h2>
        <p className="mt-3 max-w-2xl text-muted-foreground">
          A complete pathway for freelancers and aspiring instructors who want to run their own classes with a trusted curriculum.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {benefits.map(({ icon: Icon, title, body }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/15 text-accent">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-secondary/40">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-foreground">How the pathway works</h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.title} className="rounded-2xl border border-border bg-card p-6">
                <p className="text-sm font-semibold text-accent">{s.title}</p>
                <p className="mt-3 text-sm text-muted-foreground">{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">What you can teach</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {teachable.map((t) => (
            <div key={t.title} className="rounded-2xl border border-border bg-card p-6">
              <p className="text-sm font-semibold text-accent">{t.title}</p>
              <p className="mt-3 text-sm text-muted-foreground">{t.body}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 rounded-2xl border border-border bg-card p-6">
          <h3 className="text-lg font-semibold text-foreground">Support you receive as an instructor</h3>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {support.map((item) => (
              <li key={item} className="flex items-start gap-2 text-sm text-foreground">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16 text-center sm:px-6">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Ready to teach with TypeRight?</h2>
        <p className="mt-4 text-muted-foreground">
          Start with the train-the-trainer programme to begin your instructor pathway.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/courses/trainer">Explore train-the-trainer</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
