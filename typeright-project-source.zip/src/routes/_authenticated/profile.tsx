import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { LogOut, Home, Loader2, ShieldCheck, GraduationCap } from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { getDashboard, getMyAchievements } from "@/lib/learning.functions";
import { amIAdmin } from "@/lib/admin.functions";
import { ProfileCard } from "@/components/dashboard/ProfileCard";
import { EnrolledCourseCard } from "@/components/dashboard/EnrolledCourseCard";
import { SessionCalendar } from "@/components/dashboard/SessionCalendar";
import { LevelCard } from "@/components/profile/LevelCard";
import { BadgeGrid } from "@/components/profile/BadgeGrid";


export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "My profile — TypeRight Hub" },
      { name: "description", content: "Your TypeRight Hub profile: level, badges, courses and class calendar." },
      { property: "og:title", content: "My profile — TypeRight Hub" },
      { property: "og:description", content: "Track your learning level, badges and upcoming classes." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();
  const fetchDashboard = useServerFn(getDashboard);
  const fetchAchievements = useServerFn(getMyAchievements);
  const checkAdmin = useServerFn(amIAdmin);

  const { data, isLoading } = useQuery({ queryKey: ["dashboard"], queryFn: () => fetchDashboard() });
  const { data: achievements } = useQuery({
    queryKey: ["my-achievements"],
    queryFn: () => fetchAchievements(),
  });
  const { data: adminData } = useQuery({ queryKey: ["am-i-admin"], queryFn: () => checkAdmin() });

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await router.invalidate();
    navigate({ to: "/auth", replace: true });
  };

  const enrolments = data?.enrolments ?? [];
  const sessions = data?.sessions ?? [];

  const nextSessionFor = (slug: string) =>
    sessions.find((s: any) => s.course_slug === slug && new Date(s.starts_at) >= new Date()) ?? null;

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="text-xl font-bold tracking-tight">
            TypeRight<span className="text-accent">.</span>
          </Link>
          <div className="flex items-center gap-2">
            {adminData?.isAdmin && (
              <Button variant="ghost" size="sm" asChild>
                <Link to="/admin">
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  Admin
                </Link>
              </Button>
            )}
            <Button variant="ghost" size="sm" asChild>
              <Link to="/">
                <Home className="mr-2 h-4 w-4" />
                Home
              </Link>
            </Button>
            <Button variant="outline" size="sm" onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" />
              Sign out
            </Button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <h1 className="sr-only">My profile</h1>

        {isLoading ? (
          <div className="flex items-center gap-2 py-24 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading your profile…
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
              <ProfileCard profile={(data as any)?.profile ?? null} isAdmin={adminData?.isAdmin} />
              <LevelCard level={(achievements as any)?.level ?? null} />
            </div>

            <BadgeGrid
              badges={((achievements as any)?.badges ?? []) as any}
              earned={((achievements as any)?.earned ?? []) as any}
            />


            <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
              <div>
                <h2 className="mb-3 text-lg font-semibold">My courses</h2>
                {enrolments.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-border p-8 text-center">
                    <GraduationCap className="mx-auto h-6 w-6 text-muted-foreground" />
                    <p className="mt-3 text-sm text-muted-foreground">
                      You're not enrolled in any programme yet.
                    </p>
                    <Button asChild size="sm" className="mt-4">
                      <Link to="/courses">Browse courses</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="grid gap-4 sm:grid-cols-2">
                    {enrolments.map((e: any) => (
                      <EnrolledCourseCard
                        key={e.id}
                        enrolment={e}
                        nextSession={nextSessionFor(e.course_slug) as any}
                      />
                    ))}
                  </div>
                )}
              </div>
              <SessionCalendar sessions={sessions as any} />
            </div>
          </div>
        )}
      </section>
    </main>
  );
}
