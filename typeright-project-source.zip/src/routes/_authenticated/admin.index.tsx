import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { format } from "date-fns";
import { CalendarDays, Loader2, Plus } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { type Programme } from "@/components/admin/ProgrammeManager";
import { NewsManager } from "@/components/admin/NewsManager";
import { LearnerProgressManager } from "@/components/admin/LearnerProgressManager";
import { CalendarGrid } from "@/components/admin/calendar/CalendarGrid";
import { EntryList } from "@/components/admin/calendar/EntryList";
import { EntryFormDialog } from "@/components/admin/calendar/EntryFormDialog";
import { SlotSheet } from "@/components/admin/calendar/SlotSheet";
import { getClassesAdminData } from "@/lib/classes.admin.functions";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Calendar — TypeRight Hub admin" },
      { name: "description", content: "Schedule classes and exams, assign learners and mark attendance." },
      { property: "og:title", content: "Calendar — TypeRight Hub admin" },
      { property: "og:description", content: "Internal class and exam scheduling for TypeRight Hub." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ClassesAdmin,
});

function ClassesAdmin() {
  const fetchData = useServerFn(getClassesAdminData);
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin-classes"], queryFn: () => fetchData() });

  const [view, setView] = useState<"month" | "week" | "list">("month");
  const [cursor, setCursor] = useState(new Date());
  const [filterProgramme, setFilterProgramme] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [defaultDate, setDefaultDate] = useState<string | undefined>(undefined);

  const sessions: any[] = data?.sessions ?? [];
  const attendees: any[] = data?.attendees ?? [];
  const profiles: any[] = data?.profiles ?? [];
  const enrolments: any[] = data?.enrolments ?? [];
  const programmes: Programme[] = (data?.programmes ?? []) as Programme[];

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-classes"] });
    queryClient.invalidateQueries({ queryKey: ["dashboard"] });
  };

  const filtered = useMemo(
    () =>
      sessions.filter(
        (s) =>
          (filterProgramme === "all" || s.course_slug === filterProgramme) &&
          (filterType === "all" || (s.session_type ?? "class") === filterType),
      ),
    [sessions, filterProgramme, filterType],
  );

  const countFor = (id: string) => attendees.filter((a) => a.session_id === id).length;
  const selected = sessions.find((s) => s.id === selectedId) ?? null;

  const openNew = (day?: Date) => {
    setEditing(null);
    setDefaultDate(day ? format(day, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd"));
    setFormOpen(true);
  };

  if (isLoading) {
    return (
      <div className="flex min-h-64 items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Admin console</h1>
          <p className="text-sm text-muted-foreground">
            Everything scheduled here shows on every learner's profile calendar.
          </p>
        </div>
        <Button onClick={() => openNew()}>
          <Plus className="mr-1.5 h-4 w-4" /> New entry
        </Button>
      </header>

      <Tabs defaultValue="calendar">
        <TabsList>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="learners">Learners</TabsTrigger>
          <TabsTrigger value="news">News</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="mt-4 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <Tabs value={view} onValueChange={(v) => setView(v as any)}>
              <TabsList>
                <TabsTrigger value="month">Month</TabsTrigger>
                <TabsTrigger value="week">Week</TabsTrigger>
                <TabsTrigger value="list">List</TabsTrigger>
              </TabsList>
            </Tabs>
            <Select value={filterProgramme} onValueChange={setFilterProgramme}>
              <SelectTrigger className="w-52">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All programmes</SelectItem>
                {programmes.map((p) => (
                  <SelectItem key={p.id} value={p.slug}>
                    {p.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="class">Classes</SelectItem>
                <SelectItem value="exam">Exams</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {view === "list" ? (
            <EntryList sessions={filtered} countFor={countFor} onPick={(s) => setSelectedId(s.id)} />
          ) : (
            <CalendarGrid
              mode={view}
              cursor={cursor}
              setCursor={setCursor}
              sessions={filtered}
              countFor={countFor}
              onPick={(s) => setSelectedId(s.id)}
              onAddOn={(day) => openNew(day)}
            />
          )}

          {filtered.length === 0 && view !== "list" && (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <CalendarDays className="h-4 w-4" aria-hidden /> No entries yet — add one to publish it to learners.
            </p>
          )}
        </TabsContent>

        <TabsContent value="learners" className="mt-4">
          <LearnerProgressManager />
        </TabsContent>

        <TabsContent value="news" className="mt-4">
          <NewsManager />
        </TabsContent>
      </Tabs>

      <SlotSheet
        session={selected}
        onOpenChange={(v) => !v && setSelectedId(null)}
        attendees={attendees.filter((a) => a.session_id === selectedId)}
        profiles={profiles}
        enrolments={enrolments}
        refresh={refresh}
        onEdit={() => {
          setEditing(selected);
          setSelectedId(null);
          setFormOpen(true);
        }}
      />

      <EntryFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        session={editing}
        defaultDate={defaultDate}
        programmes={programmes}
        onSaved={refresh}
      />
    </div>
  );
}
