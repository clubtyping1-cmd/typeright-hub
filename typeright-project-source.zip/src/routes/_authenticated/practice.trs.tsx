import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Mic, Home } from "lucide-react";

import { Button } from "@/components/ui/button";
import { EntitlementLock } from "@/components/subscription/EntitlementLock";
import { myEntitlements } from "@/lib/subscriptions.functions";

export const Route = createFileRoute("/_authenticated/practice/trs")({
  head: () => ({
    meta: [
      { title: "Digital Shorthand practice — TypeRight Hub" },
      { name: "description", content: "Practice shorthand dictation, transcription and speed-building." },
      { property: "og:title", content: "Digital Shorthand practice" },
      { property: "og:description", content: "Practice shorthand dictation, transcription and speed-building." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PracticeTRS,
});

function PracticeTRS() {
  const load = useServerFn(myEntitlements);
  const { data, isLoading } = useQuery({ queryKey: ["my-entitlements"], queryFn: () => load() });
  const hasAccess = data?.entitlements?.trs_full_access;

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="text-xl font-bold tracking-tight">TypeRight<span className="text-accent">.</span></Link>
          <Button variant="ghost" size="sm" asChild><Link to="/profile"><Home className="mr-2 h-4 w-4" />Profile</Link></Button>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent"><Mic className="h-5 w-5" /></div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Digital Shorthand practice</h1>
            <p className="text-sm text-muted-foreground">Dictation · transcription · speed-building</p>
          </div>
        </div>

        <div className="mt-8">
          {isLoading ? (
            <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : hasAccess ? (
            <div className="rounded-2xl border border-border bg-card p-8">
              <p className="text-lg font-medium">Welcome back to Shorthand practice.</p>
              <p className="mt-2 text-sm text-muted-foreground">Choose a dictation set to begin.</p>
              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                {["Fundamental drills", "Advanced dictation", "Transcription set", "Speed-building"].map((l) => (
                  <Button key={l} variant="outline">{l}</Button>
                ))}
              </div>
            </div>
          ) : (
            <EntitlementLock
              entitlement="trs_full_access"
              suggestedPlans={["trs", "complete"]}
              title="Unlock full Shorthand practice"
              description="Subscribe to Shorthand Practice or Complete Practice for full dictation and transcription drills."
            />
          )}
        </div>
      </section>
    </main>
  );
}
