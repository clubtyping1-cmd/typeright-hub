import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Keyboard, Home } from "lucide-react";

import { Button } from "@/components/ui/button";
import { EntitlementLock } from "@/components/subscription/EntitlementLock";
import { myEntitlements } from "@/lib/subscriptions.functions";

export const Route = createFileRoute("/_authenticated/practice/trt")({
  head: () => ({
    meta: [
      { title: "Digital Typing practice — TypeRight Hub" },
      { name: "description", content: "Practice typing speed and accuracy with structured passages." },
      { property: "og:title", content: "Digital Typing practice" },
      { property: "og:description", content: "Practice typing speed and accuracy with structured passages." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PracticeTRT,
});

function PracticeTRT() {
  const load = useServerFn(myEntitlements);
  const { data, isLoading } = useQuery({ queryKey: ["my-entitlements"], queryFn: () => load() });
  const hasAccess = data?.entitlements?.trt_full_access;

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="text-xl font-bold tracking-tight">TypeRight<span className="text-accent">.</span></Link>
          <Button variant="ghost" size="sm" asChild><Link to="/profile"><Home className="mr-2 h-4 w-4" />Profile</Link></Button>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent"><Keyboard className="h-5 w-5" /></div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Digital Typing practice</h1>
            <p className="text-sm text-muted-foreground">Structured passages by difficulty · WPM & accuracy tracking</p>
          </div>
        </div>

        <div className="mt-8">
          {isLoading ? (
            <div className="flex justify-center py-16"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : hasAccess ? (
            <div className="rounded-2xl border border-border bg-card p-8">
              <p className="text-lg font-medium">Welcome back to Typing practice.</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Your practice environment loads here. Pick a difficulty and start a timed drill.
              </p>
              <div className="mt-6 grid gap-3 sm:grid-cols-4">
                {["Basic", "Beginner", "Intermediate", "Advanced"].map((l) => (
                  <Button key={l} variant="outline">{l}</Button>
                ))}
              </div>
            </div>
          ) : (
            <EntitlementLock
              entitlement="trt_full_access"
              suggestedPlans={["trt", "complete"]}
              title="Unlock full Typing practice"
              description="Subscribe to Typing Practice or Complete Practice for continuous access to typing drills, WPM tracking and assessment-readiness."
            />
          )}
        </div>
      </section>
    </main>
  );
}
