import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/courses/CategoryPage";

export const Route = createFileRoute("/courses/programmes")({
  head: () => ({
    meta: [
      { title: "Core programmes — TypeRight Hub" },
      { name: "description", content: "Structured programmes in digital typing, shorthand and AI literacy for learners in Brunei." },
      { property: "og:title", content: "Core programmes — TypeRight Hub" },
      { property: "og:description", content: "Structured programmes in digital typing, shorthand and AI literacy for learners in Brunei." },
    ],
  }),
  component: () => (
    <CategoryPage
      category="programme"
      eyebrow="Core programmes"
      title="Structured learning programmes"
      intro="Instructor-led programmes covering digital typing, shorthand and AI-enabled clerical excellence — designed for measurable outcomes."
    />
  ),
});