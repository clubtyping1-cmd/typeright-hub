const bubbles = [
  // size, x, y, color, opacity
  { size: 420, x: "-6%", y: "-18%", color: "#1E3A8A", opacity: 0.12 },
  { size: 320, x: "72%", y: "-12%", color: "#FDBA74", opacity: 0.22 },
  { size: 260, x: "58%", y: "62%", color: "#1E3A8A", opacity: 0.1 },
  { size: 200, x: "12%", y: "70%", color: "#FDBA74", opacity: 0.18 },
  { size: 150, x: "38%", y: "8%", color: "#1E3A8A", opacity: 0.08 },
  { size: 110, x: "88%", y: "55%", color: "#FDBA74", opacity: 0.16 },
];

export function BubbleBackground() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 overflow-hidden"
    >
      {bubbles.map((b, i) => (
        <div
          key={i}
          className="absolute rounded-full blur-2xl"
          style={{
            width: b.size,
            height: b.size,
            left: b.x,
            top: b.y,
            backgroundColor: b.color,
            opacity: b.opacity,
          }}
        />
      ))}
    </div>
  );
}
