import {
  Keyboard,
  FileText,
  GraduationCap,
  Sparkles,
  Users,
  Award,
} from "lucide-react";

const badges = [
  // left side
  { Icon: Sparkles, size: 88, x: "8%", y: "-4%", bg: "#FDBA74", fg: "#0B1220" },
  { Icon: Users, size: 128, x: "2%", y: "38%", bg: "#BFDBFE", fg: "#0B1220" },
  { Icon: GraduationCap, size: 104, x: "10%", y: "76%", bg: "#C4B5FD", fg: "#0B1220" },
  // right side
  { Icon: FileText, size: 88, x: "88%", y: "0%", bg: "#BFDBFE", fg: "#0B1220" },
  { Icon: Keyboard, size: 132, x: "84%", y: "36%", bg: "#1E3A8A", fg: "#FFF7ED" },
  { Icon: Award, size: 104, x: "90%", y: "74%", bg: "#D9F99D", fg: "#0B1220" },
];

export function HeroBadges() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 hidden lg:block"
    >
      {badges.map((b, i) => (
        <div
          key={i}
          className="absolute flex items-center justify-center rounded-full shadow-lg"
          style={{
            width: b.size,
            height: b.size,
            left: b.x,
            top: b.y,
            backgroundColor: b.bg,
            color: b.fg,
          }}
        >
          <b.Icon style={{ width: b.size * 0.42, height: b.size * 0.42 }} />
        </div>
      ))}
    </div>
  );
}
