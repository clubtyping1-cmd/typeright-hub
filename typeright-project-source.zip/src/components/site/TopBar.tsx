import { useEffect, useState } from "react";
import { Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Menu, LogOut, LayoutDashboard, ShieldCheck, User as UserIcon, ChevronDown } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { amIAdmin } from "@/lib/admin.functions";
import logoAsset from "@/assets/trms-logo.png.asset.json";

export function TopBar() {
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();
  const router = useRouter();
  const queryClient = useQueryClient();
  const checkAdmin = useServerFn(amIAdmin);

  const { data: adminCheck } = useQuery({
    queryKey: ["am-i-admin", user?.id ?? null],
    queryFn: () => checkAdmin(),
    enabled: Boolean(user),
  });
  const isAdmin = adminCheck?.isAdmin === true;

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await router.invalidate();
    navigate({ to: "/auth", replace: true });
  };

  const notify = (label: string) =>
    toast(`${label} — coming soon`, {
      description: "This feature isn't wired up yet.",
    });

  const userLabel = user?.user_metadata?.display_name || user?.email || "Account";
  const initial = (userLabel?.[0] ?? "U").toUpperCase();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:gap-4 sm:px-6">
        <Link to="/" className="flex shrink-0 items-center gap-2">
          <img
            src={logoAsset.url}
            alt="TypeRight Management & Services logo"
            width={40}
            height={40}
            className="h-10 w-10 object-contain"
          />
        </Link>

        <nav className="hidden flex-1 items-center gap-6 lg:flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="inline-flex items-center gap-1 text-sm font-medium text-foreground/80 transition-colors hover:text-foreground"
              >
                Courses
                <ChevronDown className="h-4 w-4" aria-hidden />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuItem asChild><Link to="/courses">All courses</Link></DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild><Link to="/courses/programmes">Core programmes</Link></DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Link to="/about" className="text-sm font-medium text-foreground/80 transition-colors hover:text-foreground">About</Link>
          <Link to="/news" className="text-sm font-medium text-foreground/80 transition-colors hover:text-foreground">News</Link>
          <Link to="/pricing" className="text-sm font-medium text-foreground/80 transition-colors hover:text-foreground">Pricing</Link>
        </nav>

        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          {user ? (
            <div className="hidden sm:block">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="Account menu"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                  >
                    {initial}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="truncate">{userLabel}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile">
                      <LayoutDashboard className="mr-2 h-4 w-4" />
                      My profile
                    </Link>
                  </DropdownMenuItem>
                  {isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link to="/admin">
                        <ShieldCheck className="mr-2 h-4 w-4" />
                        Admin console
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={signOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Button variant="outline" asChild>
                <Link to="/auth" search={{ tab: "signin" }}>Log in</Link>
              </Button>
              <Button asChild>
                <Link to="/auth" search={{ tab: "signup" }}>Sign up</Link>
              </Button>
            </div>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Menu"
                className="inline-flex h-10 w-10 items-center justify-center rounded-full text-foreground/80 transition-colors hover:bg-secondary hover:text-foreground sm:hidden"
              >
                <Menu className="h-5 w-5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild><Link to="/courses">Courses</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/courses/programmes">— Core programmes</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/about">About</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/news">News</Link></DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/pricing">Pricing</Link></DropdownMenuItem>
              <DropdownMenuSeparator />
              {user ? (
                <>
                  <DropdownMenuItem asChild>
                    <Link to="/profile">
                      <LayoutDashboard className="mr-2 h-4 w-4" />
                      My profile
                    </Link>
                  </DropdownMenuItem>
                  {isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link to="/admin">
                        <ShieldCheck className="mr-2 h-4 w-4" />
                        Admin console
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onSelect={signOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign out
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                  <DropdownMenuItem asChild>
                    <Link to="/auth" search={{ tab: "signin" }}>
                      <UserIcon className="mr-2 h-4 w-4" />
                      Log in
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/auth" search={{ tab: "signup" }}>Sign up</Link>
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}