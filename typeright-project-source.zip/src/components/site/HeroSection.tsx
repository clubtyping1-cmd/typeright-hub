import { Link } from "@tanstack/react-router";

import { Button } from "@/components/ui/button";
import { BubbleBackground } from "@/components/site/BubbleBackground";
import { HeroBadges } from "@/components/site/HeroBadges";

const hero = {
  eyebrow: "Practical typing training in Brunei",
  title: "Turn Everyday Typing into a Powerful Workplace Skill",
  subtitle:
    "Build the speed, accuracy, focus, and digital confidence needed to complete emails, reports, database entries, and administrative work more efficiently — with structured assessment and recognised certification.",
  primary: { label: "Explore Our Programmes", to: "/courses" },
  trust:
    "Suitable for government officers, graduates, secretaries and administrative professionals.",
};

export function HeroSection() {
  return (
    <section
      aria-label="Featured highlights"
      className="relative overflow-hidden py-16 sm:py-20 lg:py-28"
    >
      <BubbleBackground />
      <HeroBadges />
      <div className="relative mx-auto max-w-3xl px-6 text-center sm:px-8">
        <p className="text-sm font-semibold text-accent">{hero.eyebrow}</p>
        <h1 className="mt-3 text-4xl font-semibold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl">
          {hero.title}
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          {hero.subtitle}
        </p>
        <div className="mt-8 flex justify-center">
          <Button asChild size="lg" className="rounded-full px-8">
            <Link to={hero.primary.to}>{hero.primary.label}</Link>
          </Button>
        </div>
        <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
          {hero.trust}
        </p>
      </div>
    </section>
  );
}
