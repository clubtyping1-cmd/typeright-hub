import { Link } from "@tanstack/react-router";
import logoAsset from "@/assets/trms-logo.png.asset.json";

const linkClass = "transition-colors hover:text-foreground";

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr]">
          <div className="space-y-4">
            <Link to="/" className="inline-flex items-center gap-2">
              <img
                src={logoAsset.url}
                alt="TypeRight Management &amp; Services logo"
                width={44}
                height={44}
                className="h-11 w-11 object-contain"
              />
            </Link>
            <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
              TypeRight Hub delivers structured keyboard mastery and shorthand
              training, with certified assessments for learners and
              organisations across Brunei Darussalam.
            </p>
          </div>

          <nav aria-label="Explore" className="space-y-3">
            <h2 className="text-sm font-semibold text-foreground">Explore</h2>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link to="/" className={linkClass}>
                  Home
                </Link>
              </li>
              <li>
                <Link to="/courses" className={linkClass}>
                  Courses
                </Link>
              </li>
              <li>
                <Link to="/courses/programmes" className={linkClass}>
                  Core programmes
                </Link>
              </li>
              <li>
                <Link to="/about" className={linkClass}>
                  About
                </Link>
              </li>
              <li>
                <Link to="/news" className={linkClass}>
                  News
                </Link>
              </li>
              <li>
                <Link to="/pricing" className={linkClass}>
                  Pricing
                </Link>
              </li>
            </ul>
          </nav>

          <nav aria-label="Account" className="space-y-3">
            <h2 className="text-sm font-semibold text-foreground">Account</h2>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link
                  to="/auth"
                  search={{ tab: "signin" }}
                  className={linkClass}
                >
                  Log in
                </Link>
              </li>
              <li>
                <Link
                  to="/auth"
                  search={{ tab: "signup" }}
                  className={linkClass}
                >
                  Sign up
                </Link>
              </li>
            </ul>
          </nav>
        </div>

        <div className="mt-12 border-t border-border pt-6">
          <p className="text-sm text-muted-foreground">
            © {year} TypeRight Management &amp; Services. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
