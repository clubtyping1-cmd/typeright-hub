export function AboutCompany() {
  return (
    <section
      aria-labelledby="about-company-heading"
      className="relative overflow-hidden bg-background"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,color-mix(in_oklab,var(--accent)_12%,transparent),transparent_65%)]"
      />
      <div className="relative mx-auto max-w-5xl px-6 py-28 text-center sm:py-32 lg:py-40">
        <h1
          id="about-company-heading"
          className="text-4xl font-semibold tracking-tight text-accent sm:text-6xl"
        >
          Who We Are
        </h1>
        <p className="mx-auto mt-10 max-w-4xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          TypeRight Management &amp; Services is a Brunei-based training,
          digital learning and workforce-development provider committed to
          building practical, workplace-ready capability across the nation.
          Through TypeRight Hub, we deliver Digital Typing, Digital Shorthand,
          AI Literacy and Workplace Productivity training alongside recognised
          skills assessments.
        </p>
        <p className="mx-auto mt-6 max-w-4xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          We support students, professionals, government personnel and
          organisations of every size with structured learning pathways,
          measurable benchmarks and certification. Focused on three strategic
          thrusts&mdash;Practical Digital Skills, Workforce Readiness and
          Institutional Partnership&mdash;TypeRight is dedicated to raising
          clerical and digital standards in Brunei and beyond.
        </p>
      </div>
    </section>
  );
}
