import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const missionPoints = [
  "Provide accessible, practical training in Digital Typing, Digital Shorthand and AI literacy for learners at every stage.",
  "Offer reliable assessments and benchmarks that give individuals and employers a trusted measure of workplace capability.",
  "Partner with schools, agencies and enterprises to build clerical and digital standards that last.",
];

const thrusts = [
  {
    title: "Practical Digital Skills",
    body: "Training built around real administrative work, not theory.",
  },
  {
    title: "Workforce Readiness",
    body: "Benchmarks and certification that translate directly into employability.",
  },
  {
    title: "Institutional Partnership",
    body: "Programmes tailored for schools, government bodies and enterprises.",
  },
];

function Diamond() {
  return (
    <span
      aria-hidden
      className="mx-auto flex w-fit items-center gap-1.5"
    >
      <span className="h-2.5 w-2.5 rotate-45 bg-accent/60" />
      <span className="h-3.5 w-3.5 rotate-45 bg-accent" />
      <span className="h-2.5 w-2.5 rotate-45 bg-accent/60" />
    </span>
  );
}

export function AboutPillars() {
  return (
    <section
      aria-labelledby="about-pillars-heading"
      className="bg-background"
    >
      <h2 id="about-pillars-heading" className="sr-only">
        Our vision, mission and strategic thrusts
      </h2>

      <div className="mx-auto max-w-5xl px-6 pt-16 sm:pt-20">
        <Diamond />
      </div>

      <div className="mx-auto max-w-5xl px-6 py-16 sm:py-20">
        <Accordion
          type="multiple"
          defaultValue={["vision", "mission", "thrusts"]}
          className="w-full"
        >
          <AccordionItem value="vision" className="border-border/60">
            <AccordionTrigger className="justify-center gap-3 py-8 text-center text-2xl font-semibold text-accent hover:no-underline sm:text-3xl">
              Our Vision
            </AccordionTrigger>
            <AccordionContent className="pb-12">
              <p className="mx-auto max-w-3xl text-center text-xl font-medium leading-relaxed text-foreground sm:text-2xl">
                A trusted learning hub for digital typing, shorthand and AI
                literacy in Brunei and beyond.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="mission" className="border-border/60">
            <AccordionTrigger className="justify-center gap-3 py-8 text-center text-2xl font-semibold text-accent hover:no-underline sm:text-3xl">
              Our Mission
            </AccordionTrigger>
            <AccordionContent className="pb-12">
              <ol className="grid gap-8 sm:grid-cols-3">
                {missionPoints.map((point, index) => (
                  <li key={point} className="text-center">
                    <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full border border-accent/50 text-sm font-semibold text-accent">
                      {index + 1}
                    </span>
                    <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                      {point}
                    </p>
                  </li>
                ))}
              </ol>
              <p className="mt-12 text-center text-xl font-medium text-foreground sm:text-2xl">
                To build confidence and capability for the modern workplace.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="thrusts" className="border-border/60">
            <AccordionTrigger className="justify-center gap-3 py-8 text-center text-2xl font-semibold text-accent hover:no-underline sm:text-3xl">
              Three Strategic Thrusts
            </AccordionTrigger>
            <AccordionContent className="pb-12">
              <div className="grid gap-8 sm:grid-cols-3">
                {thrusts.map((thrust) => (
                  <div key={thrust.title} className="text-center">
                    <h3 className="text-lg font-semibold text-foreground">
                      {thrust.title}
                    </h3>
                    <p className="mt-3 text-base leading-relaxed text-muted-foreground">
                      {thrust.body}
                    </p>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </section>
  );
}
