import { Link } from "@tanstack/react-router";
import { Lock, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";

type Props = {
  entitlement: "trt_full_access" | "trs_full_access" | "advanced_progress" | "monthly_summary" | "organisation_reporting";
  suggestedPlans?: Array<"trt" | "trs" | "complete" | "teams">;
  title?: string;
  description?: string;
};

const PLAN_LABEL: Record<string, string> = {
  trt: "Typing Practice",
  trs: "Shorthand Practice",
  complete: "Complete Practice",
  teams: "TypeRight Teams",
};

export function EntitlementLock({ entitlement, suggestedPlans = ["complete"], title, description }: Props) {
  const planNames = suggestedPlans.map((p) => PLAN_LABEL[p] ?? p).join(", ");
  return (
    <div className="rounded-2xl border border-dashed border-border bg-secondary/30 p-8 text-center">
      <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/15 text-accent">
        <Lock className="h-6 w-6" aria-hidden />
      </div>
      <h3 className="text-lg font-semibold text-foreground">{title ?? "Subscription required"}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
        {description ?? `Unlock this with the ${planNames} plan.`}
      </p>
      <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
        <Button asChild>
          <Link to="/pricing">
            <Sparkles className="mr-2 h-4 w-4" />
            View plans
          </Link>
        </Button>
      </div>
      <p className="mt-4 text-[11px] uppercase tracking-wider text-muted-foreground">
        Required entitlement: {entitlement}
      </p>
    </div>
  );
}
