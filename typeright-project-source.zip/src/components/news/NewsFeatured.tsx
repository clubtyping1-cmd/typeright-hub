import { Link } from "@tanstack/react-router";

import type { NewsPost } from "@/lib/news.constants";

export function NewsFeatured({ post }: { post: NewsPost }) {
  const date = new Date(post.published_at)
    .toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
    .toUpperCase();

  return (
    <Link
      to="/news/$slug"
      params={{ slug: post.slug }}
      className="group grid overflow-hidden rounded-sm sm:grid-cols-2"
    >
      <div className="flex flex-col justify-between bg-secondary/70 p-6 transition-colors group-hover:bg-secondary sm:p-8">
        <div>
          <span className="inline-flex items-center bg-primary px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-primary-foreground">
            Highlights
          </span>
          <h2 className="mt-5 text-2xl font-extrabold uppercase leading-[1.1] tracking-tight text-foreground sm:text-3xl">
            {post.title}
          </h2>
        </div>
        <p className="mt-8 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {post.category} <span className="px-1.5 opacity-50">|</span> {date}
        </p>
      </div>

      <div className="order-first min-h-[220px] bg-muted sm:order-none">
        {post.cover_url ? (
          <img
            src={post.cover_url}
            alt={post.title}
            loading="eager"
            className="h-full min-h-[220px] w-full object-cover"
          />
        ) : (
          <div className="flex h-full min-h-[220px] w-full items-center justify-center text-xs uppercase tracking-widest text-muted-foreground">
            TypeRight
          </div>
        )}
      </div>
    </Link>
  );
}
