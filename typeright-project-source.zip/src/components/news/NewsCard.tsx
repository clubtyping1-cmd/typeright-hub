import { Link } from "@tanstack/react-router";

import type { NewsPost } from "@/lib/news.constants";

export function NewsCard({ post }: { post: NewsPost }) {
  const date = new Date(post.published_at)
    .toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })
    .toUpperCase();

  return (
    <Link
      to="/news/$slug"
      params={{ slug: post.slug }}
      className="group flex flex-col gap-4 rounded-sm bg-secondary/60 p-4 transition-all hover:-translate-y-0.5 hover:bg-secondary hover:shadow-sm"
    >
      <div className="h-20 w-28 overflow-hidden rounded-sm bg-muted">
        {post.cover_url ? (
          <img
            src={post.cover_url}
            alt={post.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-[9px] uppercase tracking-widest text-muted-foreground">
            TypeRight
          </div>
        )}
      </div>

      <div className="mt-auto">
        <p className="text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {post.category} <span className="px-1.5 opacity-50">|</span> {date}
        </p>
        <h3 className="mt-2 line-clamp-2 text-sm font-semibold leading-snug text-foreground transition-colors group-hover:text-accent">
          {post.title}
        </h3>
      </div>
    </Link>
  );
}
