type Item = { category: string; count: number };

export function NewsCategorySidebar({
  items,
  selected,
  onSelect,
}: {
  items: Item[];
  selected: string | null;
  onSelect: (category: string | null) => void;
}) {
  if (items.length === 0) return null;

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block">
        <h2 className="text-sm font-bold uppercase tracking-[0.1em] text-foreground">Categories</h2>
        <p className="mt-4 bg-secondary/70 px-3 py-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          Articles
        </p>
        <ul className="mt-1">
          {items.map((item) => {
            const active = selected === item.category;
            return (
              <li key={item.category}>
                <button
                  type="button"
                  onClick={() => onSelect(active ? null : item.category)}
                  className={`flex w-full items-center justify-between gap-3 border-b border-border px-3 py-2 text-left text-xs uppercase tracking-[0.08em] transition-colors ${
                    active
                      ? "font-semibold text-accent"
                      : "text-foreground/80 hover:text-accent"
                  }`}
                >
                  <span className="truncate">{item.category}</span>
                  <span className="shrink-0 text-[10px] text-muted-foreground">{item.count}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </aside>

      {/* Mobile chips */}
      <div className="-mx-6 flex gap-2 overflow-x-auto px-6 pb-2 lg:hidden">
        <Chip active={selected === null} onClick={() => onSelect(null)} label="All" />
        {items.map((item) => (
          <Chip
            key={item.category}
            active={selected === item.category}
            onClick={() => onSelect(selected === item.category ? null : item.category)}
            label={`${item.category} (${item.count})`}
          />
        ))}
      </div>
    </>
  );
}

function Chip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`shrink-0 rounded-full border px-3 py-1 text-[11px] uppercase tracking-[0.1em] transition-colors ${
        active
          ? "border-accent bg-accent/10 font-semibold text-accent"
          : "border-border text-muted-foreground hover:text-foreground"
      }`}
    >
      {label}
    </button>
  );
}
