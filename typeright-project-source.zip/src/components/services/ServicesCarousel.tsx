import {
  ArrowRight,
  BadgeCheck,
  MessagesSquare,
  Users,
} from "lucide-react";
import { Link } from "@tanstack/react-router";

import { BubbleBackground } from "@/components/site/BubbleBackground";
import typingIllustration from "@/assets/typing-illustration.png";

const highlights = [
  { icon: BadgeCheck, label: "Certified trainers" },
  { icon: Users, label: "Small class sizes" },
  { icon: MessagesSquare, label: "Practical feedback" },
];

export function ServicesCarousel({
  eyebrow,
  heading,
  description,
}: {
  eyebrow: string;
  heading: string;
  description: string;
}) {
  return (
    <section
      id="services"
      aria-labelledby="services-heading"
      className="relative scroll-mt-16 overflow-hidden bg-background py-20 sm:py-24 lg:py-28"
    >
      <BubbleBackground />
      <div className="relative mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,320px)_1fr] lg:gap-12">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-accent">
              {eyebrow}
            </p>
            <h2
              id="services-heading"
              className="mt-3 text-4xl font-bold tracking-tight text-foreground sm:text-5xl"
            >
              {heading}
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              {description}
            </p>
            <Link
              to="/courses"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-accent-foreground shadow-sm transition hover:brightness-110"
            >
              See Courses
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
            <ul className="mt-10 flex flex-wrap items-center gap-6">
              {highlights.map(({ icon: Icon, label }) => (
                <li key={label} className="flex flex-col items-center gap-2 text-center">
                  <span className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-accent/40 text-accent">
                    <Icon className="h-6 w-6" aria-hidden />
                  </span>
                  <span className="max-w-24 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {label}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="min-w-0">
            <img
              src={typingIllustration}
              alt="Illustration of hands typing on a keyboard with a WPM speed gauge and accuracy markers."
              width={1216}
              height={896}
              loading="lazy"
              className="w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
