import heroAsset from "@/assets/L3C_4.jpeg.asset.json";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

const heroImg = heroAsset.url;

export function ServicesHero() {
  return (
    <section
      id="about"
      aria-labelledby="services-hero-heading"
      className="relative scroll-mt-16 overflow-hidden bg-secondary/50"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 dot-texture" />
      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 py-20 pb-28 sm:py-24 sm:pb-32 lg:grid-cols-2 lg:py-28 lg:pb-36">
        <div className="min-w-0">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-accent">
            Practical Skills for the Digital Workplace
          </p>
          <h1
            id="services-hero-heading"
            className="mt-3 text-4xl font-semibold tracking-tight text-foreground sm:text-5xl lg:text-6xl"
          >
            Is Everyday Administrative Work Taking Too Much Time?
          </h1>
          <div className="mt-4 space-y-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
            <p>
              TypeRight provides practical training, digital learning systems and structured
              competency assessments for students, professionals, government personnel and
              organisations in Brunei Darussalam.
            </p>
            <p>
              Our programmes combine guided instruction, hands-on practice and measurable
              assessment to build confident, workplace-ready skills.
            </p>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/courses">Explore Our Services</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <a href="#organisation-training">Request Organisational Training</a>
            </Button>
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-6 -z-10 rounded-3xl bg-accent/10 blur-2xl" aria-hidden />
          <img
            src={heroImg}
            alt="A full TypeRight classroom in Brunei with learners working on laptops during a training session."
            width={1280}
            height={960}
            loading="lazy"
            className="aspect-[4/3] w-full rounded-3xl border border-border object-cover shadow-xl"
          />
        </div>
      </div>
      <svg
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-12 w-full text-background sm:h-16"
        viewBox="0 0 1440 64"
        preserveAspectRatio="none"
        fill="currentColor"
      >
        <path d="M0 64h1440V32c-180 24-360 32-540 24S540 16 360 24 90 48 0 32v32z" />
      </svg>
    </section>
  );
}