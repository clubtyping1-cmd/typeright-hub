import { Award, FileCheck, TrendingUp, ArrowRight } from "lucide-react";

const certifications = [
  {
    icon: FileCheck,
    title: "Digital Typing",
    subtitle: "Speed, accuracy & business documents",
    color: "bg-accent/20 text-accent",
  },
  {
    icon: Award,
    title: "Digital Shorthand",
    subtitle: "English & Malay shorthand",
    color: "bg-primary/20 text-primary",
  },
  {
    icon: TrendingUp,
    title: "Train-the-Trainer",
    subtitle: "Certify your in-house trainers",
    color: "bg-secondary text-secondary-foreground",
  },
];

export function CertificationsBanner() {
  return (
    <section aria-labelledby="certifications-heading" className="py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="overflow-hidden rounded-3xl bg-primary px-6 py-10 text-primary-foreground sm:px-10 sm:py-12 lg:px-14 lg:py-14">
          <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:items-center xl:grid-cols-[1fr_1.1fr]">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-accent">
                Certifications
              </p>
              <h2
                id="certifications-heading"
                className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl"
              >
                Get certified and get ahead in your career
              </h2>
              <p className="mt-4 max-w-2xl text-base leading-relaxed text-primary-foreground/80 sm:text-lg">
                Prepare for government assessments, professional certifications
                and workplace competency tests with structured courses,
                practice tools and expert guidance.
              </p>
              <a
                href="#services"
                className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-accent hover:underline sm:text-base"
              >
                Explore certifications and vouchers
                <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>

            <div className="grid gap-5 sm:grid-cols-3">
              {certifications.map((c) => {
                const Icon = c.icon;
                return (
                  <a
                    key={c.title}
                    href="#services"
                    className="group flex flex-col rounded-2xl border border-primary-foreground/10 bg-primary-foreground/5 p-5 transition-colors hover:bg-primary-foreground/10"
                  >
                    <div
                      className={`inline-flex h-12 w-12 items-center justify-center rounded-xl ${c.color}`}
                    >
                      <Icon className="h-6 w-6" aria-hidden />
                    </div>
                    <h3 className="mt-4 text-base font-semibold">
                      {c.title}
                    </h3>
                    <p className="mt-1 text-sm leading-relaxed text-primary-foreground/70 sm:text-base">
                      {c.subtitle}
                    </p>
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
