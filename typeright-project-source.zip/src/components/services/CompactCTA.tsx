import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function CompactCTA() {
  return (
    <section
      id="contact"
      aria-labelledby="compact-cta-heading"
      className="relative scroll-mt-16 overflow-hidden bg-foreground py-16 sm:py-20"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 dot-texture-light" />
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-background">
          Get started
        </p>
        <h2
          id="compact-cta-heading"
          className="mt-3 text-3xl font-semibold tracking-tight text-background sm:text-4xl"
        >
          Start building practical skills today
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-background/80 sm:text-lg">
          Whether you are preparing for an examination, strengthening workplace
          skills, adopting AI or developing your organisation&apos;s workforce,
          TypeRight provides structured training and measurable outcomes.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg" variant="secondary">
            <Link to="/courses">Explore Courses</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
