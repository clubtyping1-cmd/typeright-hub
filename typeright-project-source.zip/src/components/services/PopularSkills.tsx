import { Button } from "@/components/ui/button";

const skillGroups = [
  {
    category: "Typing & Office",
    featured: "Touch Typing Mastery",
    featuredHref: "#services",
    skills: [
      { name: "Business Document Formatting", learners: "1,200+ learners" },
      { name: "Microsoft Office Essentials", learners: "980+ learners" },
      { name: "Office Correspondence", learners: "850+ learners" },
    ],
  },
  {
    category: "Shorthand",
    featured: "English & Malay Shorthand",
    featuredHref: "#services",
    skills: [
      { name: "Gregg Shorthand Foundations", learners: "620+ learners" },
      { name: "Dictation & Transcription", learners: "540+ learners" },
      { name: "Meeting Note-Taking Speed", learners: "710+ learners" },
    ],
  },
  {
    category: "AI & Productivity",
    featured: "Workplace AI Literacy",
    featuredHref: "#services",
    skills: [
      { name: "Prompt Writing for ChatGPT", learners: "1,500+ learners" },
      { name: "AI-Assisted Reports & Emails", learners: "930+ learners" },
      { name: "Responsible AI Use", learners: "760+ learners" },
    ],
  },
  {
    category: "Career & Exams",
    featured: "Government Exam Preparation",
    featuredHref: "#services",
    skills: [
      { name: "Brunei Trade Certificate", learners: "890+ learners" },
      { name: "Secretarial Services Exam", learners: "640+ learners" },
      { name: "Clerical Competency", learners: "720+ learners" },
    ],
  },
];

export function PopularSkills() {
  return (
    <section
      aria-labelledby="popular-skills-heading"
      className="border-t border-border py-16 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-6">
        <h2
          id="popular-skills-heading"
          className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl"
        >
          Popular Skills
        </h2>

        <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {skillGroups.map((g) => (
            <div key={g.category}>
              <h3 className="text-base font-semibold text-foreground">
                {g.category}
              </h3>
              <div className="mt-3">
                <a
                  href={g.featuredHref}
                  className="text-sm font-semibold text-accent hover:underline"
                >
                  {g.featured} →
                </a>
                <p className="mt-1 text-xs text-muted-foreground">
                  {g.skills[0].learners}
                </p>
              </div>
              <ul className="mt-4 space-y-3">
                {g.skills.map((s) => (
                  <li key={s.name}>
                    <a
                      href="#services"
                      className="text-sm font-medium text-foreground hover:text-accent"
                    >
                      {s.name} →
                    </a>
                    <p className="text-xs text-muted-foreground">
                      {s.learners}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10">
          <Button variant="outline" asChild>
            <a href="#services">Show all trending skills →</a>
          </Button>
        </div>
      </div>
    </section>
  );
}
