import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { cn } from "@/lib/utils";
import ibteLogo from "@/assets/ibte-logo.png.asset.json";
import l3cLogo from "@/assets/l3c-logo.png.asset.json";
import ppbLogo from "@/assets/ppb-logo.png.asset.json";
import asyuraAliahLogo from "@/assets/asyura-aliah-logo.png.asset.json";

const testimonials = [
  {
    quote:
      "The digital typing course helped me improve my speed and accuracy in just a few weeks. I now feel confident handling office correspondence and reports.",
    name: "Nurul H.",
    role: "Administrative Assistant",
    course: "Digital Typing Training",
  },
  {
    quote:
      "Learning shorthand digitally was a game-changer for my note-taking during meetings. The structured lessons made it easy to practise every day.",
    name: "Ahmad S.",
    role: "Secretary, Government Department",
    course: "Digital Shorthand Training",
  },
  {
    quote:
      "The AI literacy programme gave me practical skills I use at work immediately—writing emails, summarising reports and creating presentations responsibly.",
    name: "Siti M.",
    role: "Executive Officer",
    course: "AI Literacy & Productivity",
  },
  {
    quote:
      "TypeRight's exam preparation gave me the structure and practice I needed to pass my Brunei Trade Certificate examination with confidence.",
    name: "Hafiz R.",
    role: "Recent Graduate",
    course: "Government Exam Preparation",
  },
];

const partners = [
  {
    src: ibteLogo.url,
    alt: "Institute of Brunei Technical Education (IBTE)",
  },
  {
    src: l3cLogo.url,
    alt: "Lifelong Learning Centre (L3C)",
  },
  {
    src: ppbLogo.url,
    alt: "Pusat Pembangunan Belia (PPB)",
  },
  {
    src: asyuraAliahLogo.url,
    alt: "Asyura & Aliah Management & Training Services",
  },
];

export function TestimonialsSection() {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    loop: false,
    containScroll: "trimSnaps",
  });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [snaps, setSnaps] = useState<number[]>([]);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
    setCanPrev(emblaApi.canScrollPrev());
    setCanNext(emblaApi.canScrollNext());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    setSnaps(emblaApi.scrollSnapList());
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);
  }, [emblaApi, onSelect]);

  return (
    <section
      aria-labelledby="testimonials-heading"
      className="relative overflow-hidden bg-background py-20 text-foreground sm:py-24 lg:py-28"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 dot-texture" />
      <div className="relative mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-flex items-center rounded-full bg-foreground/10 px-3 py-1 text-xs font-semibold text-foreground">
            Trusted by
          </span>
          <h2
            id="testimonials-heading"
            className="mt-5 text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-5xl"
          >
            Future-Proof Your Career with Industry-Backed Credentials
          </h2>
          <p className="mt-5 text-base leading-relaxed text-foreground/80">
            <span>Gain the skills top employers look for with our IBTE CET accredited programs.</span>
          </p>

        </div>

        <div className="mt-12 overflow-hidden" ref={emblaRef}>
          <div className="flex gap-5">
            {testimonials.map((t) => (
              <div
                key={t.name}
                className="flex min-w-0 shrink-0 basis-[85%] flex-col justify-between rounded-2xl border border-foreground/10 bg-foreground/5 p-6 sm:basis-[48%] lg:basis-[32%]"
              >
                <div>
                  <p className="text-base leading-relaxed text-foreground">
                    &ldquo;{t.quote}&rdquo;
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="rounded-md bg-foreground/10 px-2.5 py-1 text-xs font-medium text-foreground">
                      {t.course}
                    </span>
                  </div>
                </div>

                <div className="mt-8 flex items-center gap-3">
                  <div className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-foreground/10 text-sm font-semibold text-foreground">
                    {t.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground">
                      {t.name}
                    </p>
                    <p className="truncate text-xs text-foreground/70">
                      {t.role}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 flex items-center justify-center gap-4">
          <button
            type="button"
            onClick={() => emblaApi?.scrollPrev()}
            disabled={!canPrev}
            aria-label="Previous success stories"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-foreground/10 bg-foreground/5 text-foreground shadow-sm transition hover:bg-foreground/10 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            {snaps.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => emblaApi?.scrollTo(i)}
                aria-label={`Go to success story ${i + 1}`}
                aria-current={i === selectedIndex}
                className={cn(
                  "h-2 rounded-full transition-all",
                  i === selectedIndex
                    ? "w-6 bg-accent"
                    : "w-2 bg-foreground/30 hover:bg-foreground/50",
                )}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={() => emblaApi?.scrollNext()}
            disabled={!canNext}
            aria-label="Next success stories"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-foreground/10 bg-foreground/5 text-foreground shadow-sm transition hover:bg-foreground/10 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

      </div>

      <div className="mt-14 w-full py-10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-14 gap-y-8 px-6">
          {partners.map((p) => (
            <img
              key={p.alt}
              src={p.src}
              alt={p.alt}
              loading="lazy"
              className="h-12 w-auto object-contain drop-shadow-sm sm:h-14"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
