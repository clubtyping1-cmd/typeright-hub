import { useState, type ComponentType } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export interface ServiceCardProps {
  icon: ComponentType<{ className?: string; "aria-hidden"?: boolean }>;
  title: string;
  description: string;
  highlights: string[];
  moreHighlights?: string[];
  highlightStatement?: string;
}

export function ServiceCard({
  icon: Icon,
  title,
  description,
  highlights,
  moreHighlights,
  highlightStatement,
}: ServiceCardProps) {
  const [open, setOpen] = useState(false);
  const hasMore = (moreHighlights && moreHighlights.length > 0) || !!highlightStatement;

  return (
    <article className="group flex h-full flex-col rounded-2xl border border-border bg-card p-6 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-lg">
      <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
        <Icon className="h-6 w-6" aria-hidden />
      </div>
      <h3 className="text-lg font-semibold tracking-tight text-foreground">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>

      <ul className="mt-5 space-y-2 text-sm text-foreground/90">
        {highlights.map((h) => (
          <li key={h} className="flex gap-2">
            <span
              aria-hidden
              className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent"
            />
            <span>{h}</span>
          </li>
        ))}
      </ul>

      {hasMore && (
        <div
          className={cn(
            "grid overflow-hidden transition-[grid-template-rows] duration-300 ease-out",
            open ? "mt-4 grid-rows-[1fr]" : "grid-rows-[0fr]",
          )}
        >
          <div className="min-h-0">
            {moreHighlights && moreHighlights.length > 0 && (
              <ul className="space-y-2 text-sm text-foreground/90">
                {moreHighlights.map((h) => (
                  <li key={h} className="flex gap-2">
                    <span
                      aria-hidden
                      className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent/60"
                    />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            )}
            {highlightStatement && (
              <p className="mt-4 rounded-lg border-l-2 border-accent bg-muted/50 p-3 text-sm italic leading-relaxed text-muted-foreground">
                {highlightStatement}
              </p>
            )}
          </div>
        </div>
      )}

      {hasMore && (
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className="mt-5 inline-flex items-center gap-1 self-start text-sm font-medium text-accent transition-colors hover:text-accent/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded"
        >
          {open ? "Show less" : "Learn more"}
          <ChevronDown
            className={cn("h-4 w-4 transition-transform", open && "rotate-180")}
            aria-hidden
          />
        </button>
      )}
    </article>
  );
}