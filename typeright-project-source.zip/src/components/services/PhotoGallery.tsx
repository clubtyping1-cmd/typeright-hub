import expo1 from "@/assets/ICENTRE_EXPO_1.jpeg.asset.json";
import ic4 from "@/assets/IC_4.jpeg.asset.json";
import l3c2 from "@/assets/L3C_2.jpeg.asset.json";
import sh1 from "@/assets/L3C_Shorthand_1.jpeg.asset.json";
import lab from "@/assets/IMG_2995.jpeg.asset.json";
import groupPhoto from "@/assets/IMG_3003.jpeg.asset.json";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const photos = [
  {
    src: expo1.url,
    caption: "iCentre Expo demo",
    alt: "TypeRight trainers demonstrating the typing programme to visitors at the iCentre Expo in Brunei.",
  },
  {
    src: ic4.url,
    caption: "Meeting the community",
    alt: "TypeRight team members speaking with expo visitors about digital typing training.",
  },
  {
    src: l3c2.url,
    caption: "PPB Shorthand Course",
    alt: "Adult learners working on laptops in a TypeRight evening classroom session.",
  },
  {
    src: sh1.url,
    caption: "Digital Shorthand cohort",
    alt: "A Digital Shorthand class in progress with learners taking notes and asking questions.",
  },
  {
    src: lab.url,
    caption: "Keyboard Mastery in LCB ",
    alt: "Learners practising touch typing at computer workstations in a TypeRight training lab.",
  },
  {
    src: groupPhoto.url,
    caption: "LCB Attendees",
    alt: "Trainers and graduating learners gathered in the classroom after the certificate ceremony.",
  },
];

export function PhotoGallery() {
  return (
    <section
      aria-labelledby="gallery-heading"
      className="relative overflow-hidden bg-secondary/50 py-20 sm:py-24 lg:py-28"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 dot-texture-up" />
      <div className="relative mx-auto max-w-7xl px-6">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-accent">
          Gallery
        </p>
        <h2
          id="gallery-heading"
          className="mt-3 text-3xl font-semibold tracking-tight text-foreground sm:text-4xl"
        >
          Inside our classrooms
        </h2>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
          Real TypeRight sessions across Brunei — from community expos to evening
          typing and Digital Shorthand classes.
        </p>

        <Carousel
          opts={{ align: "start", loop: true }}
          className="mt-10"
          aria-label="TypeRight classroom photo carousel"
        >
          <CarouselContent className="-ml-5">
            {photos.map((p) => (
              <CarouselItem
                key={p.src}
                className="pl-5 sm:basis-1/2 lg:basis-1/3"
              >
                <figure className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
                  <img
                    src={p.src}
                    alt={p.alt}
                    width={1280}
                    height={860}
                    loading="lazy"
                    className="aspect-[3/2] w-full object-cover transition duration-300 hover:scale-[1.03]"
                  />
                  <figcaption className="px-4 py-3 text-sm font-medium text-foreground sm:text-base">
                    {p.caption}
                  </figcaption>
                </figure>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="-left-4 hidden sm:flex" />
          <CarouselNext className="-right-4 hidden sm:flex" />
        </Carousel>
      </div>
    </section>
  );
}
