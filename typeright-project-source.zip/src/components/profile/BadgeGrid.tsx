import { Award, Lock } from "lucide-react";

type Badge = { code: string; label: string; description: string };
type Earned = { badge_code: string; awarded_at: string };

export function BadgeGrid({ badges, earned }: { badges: Badge[]; earned: Earned[] }) {
  const earnedMap = new Map(earned.map((e) => [e.badge_code, e.awarded_at]));

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-lg font-semibold">Badges</h2>
        <p className="text-sm text-muted-foreground">
          {earned.length} of {badges.length} earned
        </p>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {badges.map((b) => {
          const at = earnedMap.get(b.code);
          const isEarned = Boolean(at);
          return (
            <div
              key={b.code}
              className={`flex gap-3 rounded-xl border p-3 transition-colors ${
                isEarned
                  ? "border-accent/40 bg-accent/5"
                  : "border-dashed border-border bg-muted/30 opacity-70"
              }`}
            >
              <span
                className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                  isEarned ? "bg-accent/15 text-accent" : "bg-secondary text-muted-foreground"
                }`}
              >
                {isEarned ? <Award className="h-4 w-4" /> : <Lock className="h-3.5 w-3.5" />}
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{b.label}</p>
                <p className="text-xs text-muted-foreground">{b.description}</p>
                {at && (
                  <p className="mt-1 text-[11px] font-medium text-accent">
                    Awarded {new Date(at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
