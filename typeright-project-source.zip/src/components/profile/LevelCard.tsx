import { Trophy } from "lucide-react";

const MAX_LEVEL = 5;

export function LevelCard({
  level,
}: {
  level: { level: number; level_name: string } | null;
}) {
  const current = level?.level ?? 1;
  const name = level?.level_name ?? "Beginner";
  const pct = Math.min(100, Math.round((current / MAX_LEVEL) * 100));

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-center gap-3">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/10 text-accent">
          <Trophy className="h-5 w-5" />
        </span>
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            Your level
          </p>
          <p className="text-lg font-bold tracking-tight">
            Level {current} — {name}
          </p>
        </div>
      </div>
      <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full bg-accent transition-all" style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {current >= MAX_LEVEL
          ? "You've reached the highest level. Outstanding work."
          : `Level ${current} of ${MAX_LEVEL}. Your instructor updates this as you progress.`}
      </p>
    </div>
  );
}
