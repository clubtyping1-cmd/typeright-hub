import type { ModuleArea } from "@/data/courses";

export function CourseModuleAreas({ areas }: { areas: ModuleArea[] }) {
  if (!areas.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Module areas
      </h2>
      <div className="mt-4 divide-y divide-border border-y border-border">
        {areas.map((m) => (
          <div key={m.area} className="py-4">
            <h3 className="text-[15px] font-semibold text-foreground">{m.area}</h3>
            <p className="mt-1 text-[15px] leading-relaxed text-foreground/85">
              {m.examples}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}