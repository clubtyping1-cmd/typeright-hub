export function CourseRequirements({ items }: { items: string[] }) {
  if (!items.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Requirements
      </h2>
      <ul className="mt-4 space-y-2">
        {items.map((r) => (
          <li key={r} className="flex items-start gap-2 text-[15px] text-foreground/85">
            <span
              className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent"
              aria-hidden
            />
            <span>{r}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}