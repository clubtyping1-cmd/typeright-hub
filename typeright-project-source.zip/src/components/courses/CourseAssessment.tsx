import { Award, CheckCircle2 } from "lucide-react";

import { CourseSection } from "@/components/courses/templates/EventbriteLayout";
import type { CourseAssessmentInfo } from "@/data/courses";

export function CourseAssessment({ assessment }: { assessment: CourseAssessmentInfo }) {
  return (
    <div id="assessment" className="scroll-mt-24">
      <CourseSection title="Assessment & certification">
        <p className="text-[15px] leading-relaxed text-foreground/85">{assessment.summary}</p>


        {assessment.fees && assessment.fees.length > 0 && (
          <div className="mt-6 divide-y divide-border border-y border-border">
            {assessment.fees.map((f) => (
              <div key={f.label} className="flex items-center justify-between gap-4 py-3">
                <span className="text-[15px] text-foreground/85">{f.label}</span>
                <span className="shrink-0 font-semibold text-foreground">BND {f.price}</span>
              </div>
            ))}
          </div>
        )}

        {assessment.feeNote && (
          <p className="mt-3 text-sm text-muted-foreground">{assessment.feeNote}</p>
        )}

        {assessment.outcomes.length > 0 && (
          <ul className="mt-6 grid gap-2 sm:grid-cols-2">
            {assessment.outcomes.map((o) => (
              <li key={o} className="flex items-start gap-2 text-[15px] text-foreground/85">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                {o}
              </li>
            ))}
          </ul>
        )}

        {assessment.certificateTitle && (
          <div className="mt-6 rounded-lg border border-border bg-secondary/30 p-4">
            <h4 className="text-[15px] font-semibold text-foreground">Certificate title</h4>
            <p className="mt-1 text-[15px] leading-relaxed text-foreground/85">
              {assessment.certificateTitle}
            </p>
          </div>
        )}


        {assessment.upgradePathway && assessment.upgradePathway.length > 0 && (
          <div className="mt-4 rounded-lg border border-border p-4">
            <h4 className="text-[15px] font-semibold text-foreground">
              Upgrading your typing level
            </h4>
            <ul className="mt-2 space-y-1.5">
              {assessment.upgradePathway.map((u) => (
                <li key={u} className="flex items-start gap-2 text-[15px] text-foreground/85">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
                  {u}
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="mt-5 flex items-start gap-2 text-sm text-muted-foreground">
          <Award className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
          Assessment dates are scheduled with your instructor and appear in your profile calendar.
        </p>
      </CourseSection>
    </div>
  );
}