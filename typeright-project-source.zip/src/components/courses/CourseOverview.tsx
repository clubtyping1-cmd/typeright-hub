export function CourseOverview({
  tagline,
  paragraphs,
}: {
  tagline?: string;
  paragraphs?: string[];
}) {
  if (!tagline && !paragraphs?.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Overview
      </h2>
      {tagline && (
        <p className="mt-4 text-base leading-relaxed text-foreground">{tagline}</p>
      )}
      {paragraphs && paragraphs.length > 0 && (
        <div className="mt-4 space-y-4 text-[15px] leading-relaxed text-foreground/85">
          {paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      )}
    </section>
  );
}