import { Link } from "@tanstack/react-router";
import { Star, GraduationCap } from "lucide-react";

import type { Course } from "@/data/courses";

const CATEGORY_LABEL: Record<Course["category"], string> = {
  programme: "Programme",
  trainer: "Trainer pathway",
};

function formatReviews(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}K reviews`;
  return `${n.toLocaleString()} reviews`;
}

export function CourseCard({ course }: { course: Course }) {
  const Icon = course.icon;
  const categoryLabel = CATEGORY_LABEL[course.category];
  const metaLabel = course.code
    ? `${course.code} · ${course.format ?? categoryLabel}`
    : course.format ?? categoryLabel;

  return (
    <Link
      to="/courses/$courseSlug"
      params={{ courseSlug: course.slug }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition hover:-translate-y-1 hover:border-accent/40 hover:shadow-md"
    >
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-muted">
        {course.image ? (
          <img
            src={course.image}
            alt=""
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10 text-accent">
            <Icon className="h-12 w-12" aria-hidden />
          </div>
        )}
        <span className="absolute right-3 top-3 rounded-full bg-background/95 px-2.5 py-1 text-[11px] font-semibold text-foreground shadow-sm backdrop-blur">
          {categoryLabel}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-accent/10 text-accent">
            <Icon className="h-4 w-4" aria-hidden />
          </span>
          <span className="text-sm font-medium text-muted-foreground">TypeRight Hub</span>
        </div>

        <h3 className="text-base font-semibold leading-snug text-foreground line-clamp-2">
          {course.title}
        </h3>

        <div className="flex items-center gap-1.5 text-sm font-medium text-accent">
          <GraduationCap className="h-4 w-4" aria-hidden />
          <span className="line-clamp-1">{metaLabel}</span>
        </div>

        {course.ratingCount > 0 ? (
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <Star className="h-4 w-4 fill-foreground text-foreground" aria-hidden />
            <span className="font-semibold text-foreground">{course.rating.toFixed(1)}</span>
            <span>· {formatReviews(course.ratingCount)}</span>
          </div>
        ) : (
          <div className="text-sm text-muted-foreground">New</div>
        )}

        <div className="mt-auto pt-1 text-xs text-muted-foreground">
          {course.level} · {course.format ?? categoryLabel} · {course.duration}
        </div>
      </div>
    </Link>
  );
}