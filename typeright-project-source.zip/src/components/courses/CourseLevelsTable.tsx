import type { LevelRow } from "@/data/courses";

export function CourseLevelsTable({
  levels,
  selectedLevelId,
}: {
  levels: LevelRow[];
  selectedLevelId?: string;
}) {
  if (!levels.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Programme levels
      </h2>
      <div className="mt-4 overflow-hidden rounded-xl border border-border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-secondary/60 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Level</th>
              <th className="px-4 py-3">Min. passing</th>
              <th className="px-4 py-3">Competency</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {levels.map((l) => {
              const active = l.level === selectedLevelId;
              return (
                <tr
                  key={l.level}
                  id={`level-${l.level}`}
                  className={active ? "bg-accent/10" : undefined}
                >
                  <td className="px-4 py-3 font-medium text-foreground">
                    <span className="inline-flex items-center gap-2">
                      {active && (
                        <span
                          className="h-2 w-2 rounded-full bg-accent"
                          aria-hidden
                        />
                      )}
                      {l.level}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-foreground/85">{l.minWpm}</td>
                  <td className="px-4 py-3 text-muted-foreground">{l.description}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}