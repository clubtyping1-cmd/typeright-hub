import { Check } from "lucide-react";

export function CourseWhatYoullLearn({ items }: { items: string[] }) {
  if (!items.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Objectives
      </h2>
      <ul className="mt-4 grid gap-3 sm:grid-cols-2">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-2 text-[15px] text-foreground/85">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}