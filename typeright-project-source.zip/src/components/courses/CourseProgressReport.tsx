import { CheckCircle2, FileBarChart } from "lucide-react";

import { CourseSection } from "@/components/courses/templates/EventbriteLayout";
import type { CourseProgressReportInfo } from "@/data/courses";

export function CourseProgressReport({ report }: { report: CourseProgressReportInfo }) {
  return (
    <div id="progress-report" className="scroll-mt-24">
      <CourseSection title="Optional progress report">
        <p className="text-[15px] leading-relaxed text-foreground/85">{report.summary}</p>

        <dl className="mt-4 grid gap-3">
          <div className="rounded-lg border border-border p-4">
            <dt className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Fee
            </dt>
            <dd className="mt-1 text-[15px] text-foreground">BND {report.price} per report</dd>
          </div>
        </dl>

        <ul className="mt-6 grid gap-2 sm:grid-cols-2">
          {report.includes.map((i) => (
            <li key={i} className="flex items-start gap-2 text-[15px] text-foreground/85">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
              {i}
            </li>
          ))}
        </ul>

        <p className="mt-5 flex items-start gap-2 text-sm text-muted-foreground">
          <FileBarChart className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
          Add the progress report when you enrol, or request it later from your instructor.
        </p>
      </CourseSection>
    </div>
  );
}