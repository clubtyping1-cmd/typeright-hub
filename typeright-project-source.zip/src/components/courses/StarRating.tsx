import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function StarRating({
  value,
  size = 16,
  className,
}: {
  value: number;
  size?: number;
  className?: string;
}) {
  const full = Math.floor(value);
  const hasHalf = value - full >= 0.25 && value - full < 0.75;
  const fullCount = hasHalf ? full : Math.round(value);
  return (
    <div className={cn("inline-flex items-center gap-0.5 text-amber-500", className)} aria-label={`Rating ${value} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => {
        const filled = i < fullCount;
        const half = hasHalf && i === fullCount;
        return (
          <span key={i} className="relative inline-block" style={{ width: size, height: size }}>
            <Star className="absolute inset-0" size={size} strokeWidth={1.5} aria-hidden />
            {(filled || half) && (
              <span
                className="absolute inset-0 overflow-hidden"
                style={{ width: half ? size / 2 : size }}
              >
                <Star size={size} strokeWidth={1.5} className="fill-amber-500 text-amber-500" aria-hidden />
              </span>
            )}
          </span>
        );
      })}
    </div>
  );
}
