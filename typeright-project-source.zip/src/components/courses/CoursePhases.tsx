import type { PhaseRow } from "@/data/courses";

export function CoursePhases({ phases }: { phases: PhaseRow[] }) {
  if (!phases.length) return null;
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Programme structure
      </h2>
      <div className="mt-4 space-y-4 border-l-2 border-border pl-5">
        {phases.map((p) => (
          <div key={p.phase}>
            <h3 className="text-[15px] font-semibold text-foreground">{p.phase}</h3>
            <p className="mt-0.5 text-sm text-accent">
              {p.mode} · {p.duration}
            </p>
            <p className="mt-1.5 text-[15px] leading-relaxed text-foreground/85">
              {p.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}