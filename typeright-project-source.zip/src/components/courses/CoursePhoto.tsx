import typingPhoto from "@/assets/IC_2.jpeg.asset.json";
import shorthandPhoto from "@/assets/L3C_Shorthand_2.jpeg.asset.json";
import shorthandTabletPhoto from "@/assets/L3C_Shorthand_3.jpeg.asset.json";
import classroomPhoto from "@/assets/L3C_4.jpeg.asset.json";
import expoPhoto from "@/assets/ICENTRE_EXPO_1.jpeg.asset.json";

const bySlug: Record<string, { src: string; alt: string; caption: string }> = {
  "keyboard-mastery-trt": {
    src: typingPhoto.url,
    alt: "A learner practising keyboard drills on the TypeRight typing trainer.",
    caption: "Guided keyboard practice during a TypeRight session.",
  },
  "shorthand-training-trs": {
    src: shorthandPhoto.url,
    alt: "Shorthand learners following a projected lesson on brief forms.",
    caption: "Digital Shorthand class working through brief forms.",
  },
  "trs-practice-access": {
    src: shorthandTabletPhoto.url,
    alt: "A learner writing shorthand strokes on a tablet.",
    caption: "Online shorthand practice on tablet.",
  },
  "institutional-training": {
    src: classroomPhoto.url,
    alt: "A full classroom of professionals attending TypeRight training.",
    caption: "Onsite group training for an organisation in Brunei.",
  },
  "train-the-trainer": {
    src: expoPhoto.url,
    alt: "TypeRight trainers demonstrating the programme to visitors.",
    caption: "Certified TypeRight trainers in the field.",
  },
};

export function CoursePhoto() {
  return null;
}