import { CourseOverview } from "@/components/courses/CourseOverview";
import { CourseWhatYoullLearn } from "@/components/courses/CourseWhatYoullLearn";
import { CourseLevelsTable } from "@/components/courses/CourseLevelsTable";
import { CoursePhases } from "@/components/courses/CoursePhases";
import { CourseModuleAreas } from "@/components/courses/CourseModuleAreas";
import { CourseCurriculum } from "@/components/courses/CourseCurriculum";
import { CourseRequirements } from "@/components/courses/CourseRequirements";
import { CourseReviews } from "@/components/courses/CourseReviews";

import { CourseAssessment } from "@/components/courses/CourseAssessment";
import { CourseProgressReport } from "@/components/courses/CourseProgressReport";

import { EventbriteLayout } from "./EventbriteLayout";
import type { TemplateProps } from "./types";

export function ProgrammeTemplate(props: TemplateProps) {
  const { course, levelId } = props;
  return (
    <EventbriteLayout {...props}>
      {course.requirements && <CourseRequirements items={course.requirements} />}
      <CourseOverview tagline={course.tagline} paragraphs={course.description} />
      {course.phases && <CoursePhases phases={course.phases} />}
      {course.whatYoullLearn && <CourseWhatYoullLearn items={course.whatYoullLearn} />}
      {course.moduleAreas && <CourseModuleAreas areas={course.moduleAreas} />}
      {course.curriculum && (
        <div id="curriculum" className="scroll-mt-24">
          <CourseCurriculum curriculum={course.curriculum} />
        </div>
      )}
      {course.levels && <CourseLevelsTable levels={course.levels} selectedLevelId={levelId} />}
      {course.assessment && <CourseAssessment assessment={course.assessment} />}
      {course.progressReport && <CourseProgressReport report={course.progressReport} />}
      {course.reviews && (
        <div id="reviews" className="scroll-mt-24">
          <CourseReviews
            rating={course.rating}
            ratingCount={course.ratingCount}
            reviews={course.reviews}
          />
        </div>
      )}
    </EventbriteLayout>
  );
}
