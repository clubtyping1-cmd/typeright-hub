import { CheckCircle2, GraduationCap, HeartHandshake, Users } from "lucide-react";

import { CourseOverview } from "@/components/courses/CourseOverview";

import { EventbriteLayout, CourseSection } from "./EventbriteLayout";
import type { TemplateProps } from "./types";

export function TrainerTemplate(props: TemplateProps) {
  const { course } = props;
  const steps = [
    { icon: GraduationCap, title: "Apply", body: "Submit your interest with your teaching or industry background." },
    { icon: Users, title: "Facilitator training", body: "Learn TypeRight's programme delivery methodology." },
    { icon: CheckCircle2, title: "Certification", body: "Complete a delivery review to earn typing and shorthand instructor status." },
    { icon: HeartHandshake, title: "Ongoing support", body: "Join the trainer network with materials, refreshers and mentorship." },
  ];
  return (
    <EventbriteLayout {...props}>
      <CourseOverview tagline={course.tagline} paragraphs={course.description} />

      <CourseSection title="Certification pathway">
        <ol className="space-y-5 border-l-2 border-border pl-5">
          {steps.map(({ icon: Icon, title, body }, i) => (
            <li key={title}>
              <div className="flex items-center gap-2">
                <Icon className="h-4 w-4 text-accent" aria-hidden />
                <h3 className="text-[15px] font-semibold text-foreground">
                  Step {i + 1}: {title}
                </h3>
              </div>
              <p className="mt-1 text-[15px] leading-relaxed text-foreground/85">{body}</p>
            </li>
          ))}
        </ol>
      </CourseSection>

      <CourseSection title="Prerequisites">
        <ul className="space-y-2 text-[15px] text-foreground/85">
          {[
            "Experience delivering training or teaching in a professional setting",
            "Proficiency in typing or shorthand (or willingness to certify)",
            "Commitment to a full facilitator training cohort",
          ].map((r) => (
            <li key={r} className="flex items-start gap-2">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
              {r}
            </li>
          ))}
        </ul>
      </CourseSection>

      <CourseSection title="Cohort schedule">
        <p className="text-[15px] leading-relaxed text-foreground/85">
          Coming soon — dates and locations will be announced ahead of the next intake.
          Register your interest to be notified first.
        </p>
      </CourseSection>
    </EventbriteLayout>
  );
}
