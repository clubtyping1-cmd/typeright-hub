import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Clock, Globe, GraduationCap, MapPin, Users } from "lucide-react";

import { StarRating } from "@/components/courses/StarRating";
import { Button } from "@/components/ui/button";

import type { TemplateProps } from "./types";

export function EventbriteLayout({
  children,
  ...props
}: TemplateProps & { children: ReactNode }) {
  const { course } = props;
  const Icon = course.icon;

  return (
    <div className="bg-background">
      {/* Cover band — blurred backdrop with the centred cover image */}
      <div className="relative overflow-hidden border-b border-border bg-secondary/50">
        {course.image && (
          <div
            aria-hidden
            className="absolute inset-0 scale-110 bg-cover bg-center opacity-40 blur-2xl"
            style={{ backgroundImage: `url(${course.image})` }}
          />
        )}
        <div className="relative mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
          <div className="aspect-[16/7] w-full overflow-hidden rounded-xl bg-card shadow-lg">
            {course.image ? (
              <img
                src={course.image}
                alt={`${course.title} cover`}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/15 to-accent/15 text-accent">
                <Icon className="h-16 w-16" aria-hidden />
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="pt-8">
          {/* Main column */}
          <div className="min-w-0">
            <Link
              to="/courses"
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden />
              Back to courses
            </Link>

            <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <h1 className="text-3xl font-bold leading-tight tracking-tight text-foreground sm:text-4xl lg:text-[2.75rem]">
                {course.title}
              </h1>
              <div className="flex flex-wrap gap-2 sm:pt-1">
                <Button asChild>
                  <a
                    href="https://app.typerightms.com/TypingStudent/login.php"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Start typing
                  </a>
                </Button>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                TR
              </div>
              <div>
                <p className="text-sm text-foreground">
                  by <span className="font-semibold">TypeRight Hub</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {course.studentsEnrolled.toLocaleString()} learners ·{" "}
                  {course.ratingCount.toLocaleString()} ratings · Brunei Darussalam
                </p>
              </div>
            </div>

            <dl className="mt-6 space-y-2 text-sm text-foreground/85">
              <MetaRow icon={MapPin}>
                {course.format ?? "Bandar Seri Begawan, Brunei-Muara District"}
              </MetaRow>
              <MetaRow icon={CalendarDays}>
                {course.code ? `${course.code} · ` : ""}
                Rolling intakes · Enrol anytime
              </MetaRow>
              <MetaRow icon={Clock}>{course.duration}</MetaRow>
              <MetaRow icon={GraduationCap}>{course.level}</MetaRow>
              <MetaRow icon={Globe}>{course.language}</MetaRow>
            </dl>

            {course.ratingCount > 0 && (
              <div className="mt-5 flex items-center gap-2 text-sm">
                <span className="font-semibold text-foreground">
                  {course.rating.toFixed(1)}
                </span>
                <StarRating value={course.rating} size={16} />
                <span className="text-muted-foreground">
                  ({course.ratingCount.toLocaleString()} ratings)
                </span>
              </div>
            )}

            <div className="mt-10 space-y-10">{children}</div>

            {/* Organiser card */}
            <section className="mt-14 rounded-xl border border-border bg-card p-6">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Organised by
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-base font-bold text-primary-foreground">
                  TR
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-lg font-semibold text-foreground">TypeRight Hub</p>
                  <p className="text-sm text-muted-foreground">
                    Brunei's digital typing, shorthand and AI learning hub
                  </p>
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5" aria-hidden /> Trusted by schools,
                  agencies and employers
                </span>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetaRow({
  icon: Icon,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <div className="flex items-start gap-2.5">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
      <span>{children}</span>
    </div>
  );
}

export function CourseSection({
  title,
  id,
  children,
}: {
  title?: string;
  id?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className={id ? "scroll-mt-24" : undefined}>
      {title && (
        <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
          {title}
        </h2>
      )}
      <div className={title ? "mt-4" : undefined}>{children}</div>
    </section>
  );
}
