import type { Course, LevelRow } from "@/data/courses";

export type TemplateProps = {
  course: Course;
  levels: LevelRow[];
  levelId: string;
  setLevelId: (id: string) => void;
};

export function formatPrice(n: number) {
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}
