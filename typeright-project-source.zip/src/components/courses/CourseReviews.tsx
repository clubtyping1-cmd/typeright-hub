import { useState } from "react";

import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/courses/StarRating";
import type { Review } from "@/data/courses";

export function CourseReviews({
  rating,
  ratingCount,
  reviews,
}: {
  rating: number;
  ratingCount: number;
  reviews: Review[];
}) {
  const [open, setOpen] = useState(false);
  if (!reviews.length) return null;
  const visible = open ? reviews : reviews.slice(0, 3);
  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Student ratings & reviews
      </h2>
      <div className="mt-4 flex flex-wrap items-center gap-6 rounded-xl border border-border bg-card p-6">
        <div className="text-center">
          <div className="text-4xl font-semibold text-foreground">
            {rating.toFixed(1)}
          </div>
          <StarRating value={rating} size={18} className="mt-1 justify-center" />
          <p className="mt-1 text-xs text-muted-foreground">Course rating</p>
        </div>
        <div className="flex-1 text-sm text-muted-foreground">
          Based on {ratingCount.toLocaleString()} learner reviews from students,
          professionals and government officers across Brunei.
        </div>
      </div>

      <ul className="mt-6 space-y-4">
        {visible.map((r, i) => (
          <li key={i} className="border-b border-border pb-5 last:border-0">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
                {r.name[0]}
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{r.name}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <StarRating value={r.rating} size={12} />
                  <span>·</span>
                  <span>{r.date}</span>
                </div>
              </div>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-foreground/85">
              {r.comment}
            </p>
          </li>
        ))}
      </ul>
      {reviews.length > 3 && (
        <div className="mt-4">
          <Button variant="outline" size="sm" onClick={() => setOpen((v) => !v)}>
            {open ? "Show fewer reviews" : "Show all reviews"}
          </Button>
        </div>
      )}
    </section>
  );
}