import { useState } from "react";
import type { Instructor } from "@/data/courses";
import { StarRating } from "./StarRating";
import { cn } from "@/lib/utils";
import { Users, BookOpen } from "lucide-react";

export function InstructorTabs({ instructors }: { instructors: Instructor[] }) {
  const [activeId, setActiveId] = useState(instructors[0]?.id);
  const active = instructors.find((i) => i.id === activeId) ?? instructors[0];
  if (!active) return null;
  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2">
        {instructors.map((i) => {
          const selected = i.id === active.id;
          return (
            <button
              key={i.id}
              type="button"
              onClick={() => setActiveId(i.id)}
              className={cn(
                "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
                selected
                  ? "border-accent bg-accent text-accent-foreground"
                  : "border-border bg-background text-foreground/80 hover:bg-secondary",
              )}
            >
              {i.name}
            </button>
          );
        })}
      </div>
      <div className="rounded-2xl border border-border bg-card p-6">
        <div className="flex flex-wrap items-start gap-4">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-primary text-2xl font-semibold text-primary-foreground">
            {active.initial}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-foreground">{active.name}</h3>
            <p className="text-sm text-muted-foreground">{active.title}</p>
            <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <StarRating value={active.rating} size={14} />
                <span className="ml-1 font-medium text-foreground">{active.rating.toFixed(1)}</span>
                <span>instructor rating</span>
              </span>
              <span className="inline-flex items-center gap-1">
                <Users className="h-3.5 w-3.5" aria-hidden />
                {active.students.toLocaleString()} students
              </span>
              <span className="inline-flex items-center gap-1">
                <BookOpen className="h-3.5 w-3.5" aria-hidden />
                {active.courses} courses
              </span>
            </div>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-foreground/85">{active.bio}</p>
      </div>
    </div>
  );
}
