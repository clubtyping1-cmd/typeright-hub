import type { CurriculumModule } from "@/data/courses";

export function CourseCurriculum({
  curriculum,
}: {
  curriculum: CurriculumModule[];
}) {
  if (!curriculum.length) return null;

  return (
    <section>
      <h2 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">
        Course content
      </h2>
      <div className="mt-4 divide-y divide-border rounded-xl border border-border bg-card">
        {curriculum.map((mod) => (
          <div key={mod.title} className="px-4 py-3 text-sm font-medium text-foreground">
            {mod.title}
          </div>
        ))}
      </div>
    </section>
  );
}