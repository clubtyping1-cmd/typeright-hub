import { Link } from "@tanstack/react-router";

import { TopBar } from "@/components/site/TopBar";
import { CourseCard } from "@/components/courses/CourseCard";
import { courses, type Course } from "@/data/courses";

export function CategoryPage({
  category,
  eyebrow,
  title,
  intro,
}: {
  category: Course["category"];
  eyebrow: string;
  title: string;
  intro: string;
}) {
  const items = courses.filter((c) => c.category === category);

  return (
    <main className="min-h-screen bg-background text-foreground">
      <TopBar />

      <section className="border-b border-border bg-gradient-to-b from-secondary/60 to-background">
        <div className="mx-auto max-w-7xl px-6 py-16 sm:py-20">
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-accent">
            {eyebrow}
          </p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
            {title}
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {intro}
          </p>
          <div className="mt-6">
            <Link
              to="/courses"
              className="text-sm font-medium text-accent hover:underline"
            >
              ← All courses
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 sm:py-20">
        {items.length === 0 ? (
          <p className="text-muted-foreground">No courses in this category yet.</p>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {items.map((c) => (
              <CourseCard key={c.slug} course={c} />
            ))}
          </div>
        )}
      </section>

      <section className="bg-secondary/40 py-16 sm:py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            Need help choosing?
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Tell us your goals and we'll recommend the right pathway for you or
            your organisation.
          </p>
        </div>
      </section>
    </main>
  );
}