import { useMemo, useState } from "react";
import {
  addMonths,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { ChevronLeft, ChevronRight, MapPin, Video } from "lucide-react";

import { Button } from "@/components/ui/button";

export type SessionRow = {
  id: string;
  course_slug: string;
  title: string;
  starts_at: string;
  ends_at?: string | null;
  mode: string;
  location?: string | null;
  join_url?: string | null;
  instructor_name?: string | null;
  status?: string | null;
  cancellation_reason?: string | null;
  original_starts_at?: string | null;
  session_type?: string | null;
};

function StatusTag({ status }: { status?: string | null }) {
  if (!status || status === "scheduled") return null;
  const cancelled = status === "cancelled";
  return (
    <span
      className={`ml-2 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
        cancelled ? "bg-destructive/10 text-destructive" : "bg-accent/10 text-accent"
      }`}
    >
      {cancelled ? "Cancelled" : "Rescheduled"}
    </span>
  );
}

function TypeTag({ type }: { type?: string | null }) {
  const isExam = type === "exam";
  return (
    <span
      className={`ml-2 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
        isExam ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
      }`}
    >
      {isExam ? "Exam" : "Class"}
    </span>
  );
}

export function SessionCalendar({ sessions }: { sessions: SessionRow[] }) {
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState<Date | null>(null);

  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 });
    const out: Date[] = [];
    for (let d = start; d <= end; d = new Date(d.getTime() + 86400000)) out.push(new Date(d));
    return out;
  }, [cursor]);

  const sessionsFor = (day: Date) =>
    sessions.filter((s) => isSameDay(new Date(s.starts_at), day));

  const listDay = selected ?? new Date();
  const listed = sessionsFor(listDay);
  const upcoming = sessions
    .filter((s) => new Date(s.starts_at) >= new Date())
    .slice(0, 4);

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Upcoming classes &amp; exams</h2>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={() => setCursor(addMonths(cursor, -1))} aria-label="Previous month">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="w-28 text-center text-sm font-medium">{format(cursor, "MMMM yyyy")}</span>
          <Button variant="ghost" size="icon" onClick={() => setCursor(addMonths(cursor, 1))} aria-label="Next month">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[11px] font-semibold uppercase text-muted-foreground">
        {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => (
          <div key={d}>{d}</div>
        ))}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {days.map((day) => {
          const has = sessionsFor(day).length > 0;
          const isToday = isSameDay(day, new Date());
          const isSelected = selected && isSameDay(day, selected);
          return (
            <button
              key={day.toISOString()}
              type="button"
              onClick={() => setSelected(day)}
              className={[
                "flex aspect-square flex-col items-center justify-center rounded-lg text-sm transition-colors",
                isSameMonth(day, cursor) ? "text-foreground" : "text-muted-foreground/50",
                isSelected ? "bg-accent text-accent-foreground" : isToday ? "bg-secondary" : "hover:bg-secondary",
              ].join(" ")}
            >
              {day.getDate()}
              <span
                className={`mt-0.5 h-1 w-1 rounded-full ${has ? (isSelected ? "bg-accent-foreground" : "bg-accent") : "bg-transparent"}`}
                aria-hidden
              />
            </button>
          );
        })}
      </div>

      <div className="mt-5 border-t border-border pt-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          {selected ? format(listDay, "d MMM yyyy") : "Upcoming"}
        </p>
        <ul className="mt-2 space-y-3">
          {(selected ? listed : upcoming).map((s) => {
            const cancelled = s.status === "cancelled";
            return (
            <li key={s.id} className="text-sm">
              <p className={`font-medium text-foreground ${cancelled ? "line-through opacity-70" : ""}`}>
                {s.title}
                <TypeTag type={s.session_type} />
                <StatusTag status={s.status} />
              </p>
              <p className="text-xs text-muted-foreground">
                {format(new Date(s.starts_at), "d MMM · HH:mm")}
                {s.instructor_name ? ` · ${s.instructor_name}` : ""}
              </p>
              {s.status === "rescheduled" && s.original_starts_at ? (
                <p className="text-xs text-muted-foreground line-through">
                  was {format(new Date(s.original_starts_at), "d MMM · HH:mm")}
                </p>
              ) : null}
              {cancelled && s.cancellation_reason ? (
                <p className="text-xs text-destructive">{s.cancellation_reason}</p>
              ) : null}
              {cancelled ? null : s.mode === "online" && s.join_url ? (
                <a
                  href={s.join_url}
                  className="mt-0.5 inline-flex items-center gap-1 text-xs font-semibold text-accent hover:underline"
                >
                  <Video className="h-3 w-3" /> Join online
                </a>
              ) : s.location ? (
                <p className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" /> {s.location}
                </p>
              ) : null}
            </li>
            );
          })}
          {(selected ? listed : upcoming).length === 0 && (
            <li className="text-sm text-muted-foreground">Nothing scheduled for you yet.</li>
          )}
        </ul>
      </div>
    </div>
  );
}