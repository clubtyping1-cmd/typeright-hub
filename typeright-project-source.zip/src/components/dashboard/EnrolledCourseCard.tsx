import { Link } from "@tanstack/react-router";
import { CalendarClock, ExternalLink, PlayCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getCourseBySlug } from "@/data/courses";
import { PRACTICE_PORTAL_URL } from "@/lib/enrolment";

export type Enrolment = {
  id: string;
  course_slug: string;
  title: string;
  level_name?: string | null;
  instructor_name?: string | null;
  status: string;
  progress_percent: number;
  next_lesson_title?: string | null;
  last_accessed_at?: string | null;
};

export function EnrolledCourseCard({
  enrolment,
  nextSession,
  featured,
}: {
  enrolment: Enrolment;
  nextSession?: { title: string; starts_at: string; mode: string; location?: string | null } | null;
  featured?: boolean;
}) {
  const course = getCourseBySlug(enrolment.course_slug as any);
  const cover = course?.image;

  return (
    <div
      className={`overflow-hidden rounded-2xl border border-border bg-card ${
        featured ? "sm:flex" : ""
      }`}
    >
      {cover && (
        <div className={featured ? "sm:w-64 sm:shrink-0" : ""}>
          <img
            src={cover}
            alt=""
            loading="lazy"
            className={`w-full object-cover ${featured ? "h-40 sm:h-full" : "h-32"}`}
          />
        </div>
      )}
      <div className="flex-1 p-5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-secondary px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            {enrolment.status}
          </span>
          {enrolment.level_name && (
            <span className="text-xs text-muted-foreground">Level {enrolment.level_name}</span>
          )}
        </div>
        <h3 className="mt-2 text-base font-semibold text-foreground">{enrolment.title}</h3>
        {enrolment.instructor_name && (
          <p className="text-xs text-muted-foreground">with {enrolment.instructor_name}</p>
        )}

        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Progress</span>
            <span className="font-semibold text-foreground">{enrolment.progress_percent}%</span>
          </div>
          <Progress value={enrolment.progress_percent} className="mt-1.5 h-2" />
        </div>

        {enrolment.next_lesson_title && (
          <p className="mt-3 flex items-start gap-2 text-sm text-foreground/85">
            <PlayCircle className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
            Next lesson: {enrolment.next_lesson_title}
          </p>
        )}
        {nextSession && (
          <p className="mt-1.5 flex items-start gap-2 text-sm text-muted-foreground">
            <CalendarClock className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden />
            {nextSession.title} ·{" "}
            {new Date(nextSession.starts_at).toLocaleString("en-GB", {
              day: "numeric",
              month: "short",
              hour: "2-digit",
              minute: "2-digit",
            })}
            {nextSession.location ? ` · ${nextSession.location}` : ""}
          </p>
        )}

        <div className="mt-4 flex flex-wrap gap-2">
          {enrolment.status?.toLowerCase() === "active" && (
            <Button asChild size="sm">
              <a href={PRACTICE_PORTAL_URL} target="_blank" rel="noopener noreferrer">
                Start your typing
                <ExternalLink className="ml-1.5 h-4 w-4" aria-hidden />
              </a>
            </Button>
          )}
          <Button asChild size="sm" variant="outline">
            <Link to="/courses/$courseSlug" params={{ courseSlug: enrolment.course_slug }}>
              {enrolment.progress_percent > 0 ? "Continue" : "Start learning"}
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}