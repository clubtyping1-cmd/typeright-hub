import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Pencil, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { updateMyProfile } from "@/lib/learning.functions";

export function ProfileCard({
  profile,
  isAdmin,
}: {
  profile: { email?: string | null; display_name?: string | null; avatar_url?: string | null; created_at?: string } | null;
  isAdmin?: boolean;
}) {
  const queryClient = useQueryClient();
  const save = useServerFn(updateMyProfile);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.display_name ?? "");

  const mutation = useMutation({
    mutationFn: (displayName: string) => save({ data: { displayName } }),
    onSuccess: () => {
      toast.success("Profile updated");
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: () => toast.error("Could not update your profile"),
  });

  const displayName = profile?.display_name || profile?.email?.split("@")[0] || "Learner";
  const initial = displayName.charAt(0).toUpperCase();

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-start gap-4">
        <Avatar className="h-14 w-14">
          {profile?.avatar_url ? <AvatarImage src={profile.avatar_url} alt="" /> : null}
          <AvatarFallback className="text-lg font-semibold">{initial}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          {editing ? (
            <div className="flex flex-wrap items-center gap-2">
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-9 max-w-56"
                placeholder="Your name"
              />
              <Button
                size="sm"
                disabled={!name.trim() || mutation.isPending}
                onClick={() => mutation.mutate(name.trim())}
              >
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
                Cancel
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <h2 className="truncate text-xl font-bold tracking-tight">{displayName}</h2>
              <button
                type="button"
                onClick={() => {
                  setName(profile?.display_name ?? "");
                  setEditing(true);
                }}
                className="text-muted-foreground transition-colors hover:text-foreground"
                aria-label="Edit your name"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
              {isAdmin && (
                <span className="inline-flex items-center gap-1 rounded-full border border-accent/40 bg-accent/10 px-2 py-0.5 text-[11px] font-semibold text-accent">
                  <ShieldCheck className="h-3 w-3" /> Admin
                </span>
              )}
            </div>
          )}
          <p className="mt-1 truncate text-sm text-muted-foreground">{profile?.email}</p>
          {profile?.created_at && (
            <p className="mt-1 text-xs text-muted-foreground">
              Member since{" "}
              {new Date(profile.created_at).toLocaleDateString("en-GB", {
                month: "long",
                year: "numeric",
              })}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}