import { Award, Download } from "lucide-react";

export function CertificateList({
  certificates,
}: {
  certificates: Array<{
    id: string;
    title: string;
    certificate_number: string;
    issued_at: string;
    file_url?: string | null;
  }>;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h2 className="text-lg font-semibold">Certificates</h2>
      {certificates.length === 0 ? (
        <div className="mt-4 rounded-xl border border-dashed border-border p-6 text-center">
          <Award className="mx-auto h-5 w-5 text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">
            Certificates appear here once a programme is completed.
          </p>
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {certificates.map((c) => (
            <li key={c.id} className="flex items-start justify-between gap-3 rounded-xl border border-border p-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-foreground">{c.title}</p>
                <p className="text-xs text-muted-foreground">
                  {c.certificate_number} ·{" "}
                  {new Date(c.issued_at).toLocaleDateString("en-GB", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                </p>
              </div>
              {c.file_url && (
                <a
                  href={c.file_url}
                  className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-accent hover:underline"
                >
                  <Download className="h-3.5 w-3.5" /> Download
                </a>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}