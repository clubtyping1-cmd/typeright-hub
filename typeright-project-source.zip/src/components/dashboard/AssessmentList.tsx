import { ClipboardCheck } from "lucide-react";

const STATUS_STYLES: Record<string, string> = {
  scheduled: "bg-secondary text-muted-foreground",
  pending_result: "bg-amber-500/15 text-amber-600",
  passed: "bg-emerald-500/15 text-emerald-600",
  failed: "bg-destructive/15 text-destructive",
};

export function AssessmentList({
  attempts,
}: {
  attempts: Array<{
    id: string;
    assessment_name: string;
    scheduled_at?: string | null;
    status: string;
    score?: number | null;
    wpm?: number | null;
    remarks?: string | null;
  }>;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h2 className="text-lg font-semibold">Assessments</h2>
      {attempts.length === 0 ? (
        <div className="mt-4 rounded-xl border border-dashed border-border p-6 text-center">
          <ClipboardCheck className="mx-auto h-5 w-5 text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">No assessments recorded yet.</p>
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {attempts.map((a) => (
            <li key={a.id} className="rounded-xl border border-border p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-medium text-foreground">{a.assessment_name}</p>
                <span
                  className={`rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase ${
                    STATUS_STYLES[a.status] ?? "bg-secondary text-muted-foreground"
                  }`}
                >
                  {a.status.replace("_", " ")}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {a.scheduled_at
                  ? new Date(a.scheduled_at).toLocaleDateString("en-GB", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })
                  : "Date to be confirmed"}
                {a.wpm != null ? ` · ${a.wpm} wpm` : ""}
                {a.score != null ? ` · score ${a.score}` : ""}
              </p>
              {a.remarks && <p className="mt-1 text-xs text-muted-foreground">{a.remarks}</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}