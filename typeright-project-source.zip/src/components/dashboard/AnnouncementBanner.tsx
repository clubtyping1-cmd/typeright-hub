import { useState } from "react";
import { Megaphone, X } from "lucide-react";

export function AnnouncementBanner({
  announcement,
}: {
  announcement: { id: string; title: string; body?: string | null; link_url?: string | null; published_at: string } | null;
}) {
  const [dismissed, setDismissed] = useState(false);
  if (!announcement || dismissed) return null;

  return (
    <div className="relative rounded-2xl border border-accent/30 bg-accent/5 p-6">
      <button
        type="button"
        onClick={() => setDismissed(true)}
        className="absolute right-4 top-4 text-muted-foreground transition-colors hover:text-foreground"
        aria-label="Dismiss announcement"
      >
        <X className="h-4 w-4" />
      </button>
      <div className="flex items-start gap-3">
        <Megaphone className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden />
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-wide text-accent">
            Latest announcement
          </p>
          <h3 className="mt-1 text-lg font-semibold text-foreground">{announcement.title}</h3>
          {announcement.body && (
            <p className="mt-1.5 text-sm leading-relaxed text-foreground/80">{announcement.body}</p>
          )}
          <p className="mt-2 text-xs text-muted-foreground">
            {new Date(announcement.published_at).toLocaleDateString("en-GB", {
              day: "numeric",
              month: "short",
              year: "numeric",
            })}
          </p>
          {announcement.link_url && (
            <a
              href={announcement.link_url}
              className="mt-2 inline-block text-sm font-semibold text-accent underline-offset-4 hover:underline"
            >
              Read more
            </a>
          )}
        </div>
      </div>
    </div>
  );
}