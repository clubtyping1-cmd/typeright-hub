import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { deleteProgramme, upsertProgramme } from "@/lib/classes.admin.functions";

export type Programme = {
  id: string;
  slug: string;
  title: string;
  default_instructor: string | null;
  is_active: boolean;
  sort_order: number;
};

const empty = {
  id: undefined as string | undefined,
  slug: "",
  title: "",
  defaultInstructor: "",
  isActive: true,
  sortOrder: "0",
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function ProgrammeManager({
  programmes,
  onChanged,
}: {
  programmes: Programme[];
  onChanged: () => void;
}) {
  const [form, setForm] = useState(empty);
  const [open, setOpen] = useState(false);

  const save = useMutation({
    mutationFn: useServerFn(upsertProgramme),
    onSuccess: () => {
      toast.success("Programme saved");
      setForm(empty);
      onChanged();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not save this programme."),
  });

  const remove = useMutation({
    mutationFn: useServerFn(deleteProgramme),
    onSuccess: () => {
      toast.success("Programme deleted");
      onChanged();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not delete this programme."),
  });

  const submit = () => {
    const slug = form.slug.trim() || slugify(form.title);
    if (!form.title.trim() || !slug) {
      toast.error("A programme name is required.");
      return;
    }
    save.mutate({
      data: {
        ...(form.id ? { id: form.id } : {}),
        slug,
        title: form.title.trim(),
        defaultInstructor: form.defaultInstructor.trim() || null,
        isActive: form.isActive,
        sortOrder: Number(form.sortOrder) || 0,
      },
    });
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Programmes</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            The courses the calendar can schedule classes and exams against.
          </p>
        </div>
        <Button
          size="sm"
          variant={open ? "ghost" : "outline"}
          onClick={() => {
            setOpen((v) => !v);
            setForm(empty);
          }}
        >
          {open ? "Close" : (<><Plus className="mr-1 h-4 w-4" /> Add</>)}
        </Button>
      </div>

      {open && (
        <div className="mt-4 space-y-3 rounded-xl border border-border bg-background p-4">
          <div>
            <Label className="text-xs">Programme name</Label>
            <Input
              className="mt-1"
              value={form.title}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  title: e.target.value,
                  slug: f.id ? f.slug : slugify(e.target.value),
                }))
              }
            />
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Code</Label>
              <Input
                className="mt-1"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: slugify(e.target.value) })}
              />
            </div>
            <div>
              <Label className="text-xs">Default trainer</Label>
              <Input
                className="mt-1"
                value={form.defaultInstructor}
                onChange={(e) => setForm({ ...form, defaultInstructor: e.target.value })}
              />
            </div>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Order</Label>
              <Input
                type="number"
                min={0}
                className="mt-1"
                value={form.sortOrder}
                onChange={(e) => setForm({ ...form, sortOrder: e.target.value })}
              />
            </div>
            <div className="flex items-end gap-2 pb-2">
              <Switch
                id="programme-active"
                checked={form.isActive}
                onCheckedChange={(v) => setForm({ ...form, isActive: v })}
              />
              <Label htmlFor="programme-active" className="text-xs">
                Available for scheduling
              </Label>
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={submit} disabled={save.isPending}>
              {save.isPending ? "Saving…" : form.id ? "Save changes" : "Add programme"}
            </Button>
            {form.id && (
              <Button size="sm" variant="ghost" onClick={() => setForm(empty)}>
                Cancel edit
              </Button>
            )}
          </div>
        </div>
      )}

      <ul className="mt-4 divide-y divide-border">
        {programmes.length === 0 && (
          <li className="py-3 text-sm text-muted-foreground">No programmes yet — add one to start scheduling.</li>
        )}
        {programmes.map((p) => (
          <li key={p.id} className="flex items-center justify-between gap-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">
                {p.title}
                {!p.is_active && (
                  <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                    Hidden
                  </span>
                )}
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {p.slug}
                {p.default_instructor ? ` · ${p.default_instructor}` : ""}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              <Button
                size="icon"
                variant="ghost"
                aria-label={`Edit ${p.title}`}
                onClick={() => {
                  setOpen(true);
                  setForm({
                    id: p.id,
                    slug: p.slug,
                    title: p.title,
                    defaultInstructor: p.default_instructor ?? "",
                    isActive: p.is_active,
                    sortOrder: String(p.sort_order),
                  });
                }}
              >
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                aria-label={`Delete ${p.title}`}
                disabled={remove.isPending}
                onClick={() => {
                  if (!window.confirm(`Delete "${p.title}"?`)) return;
                  remove.mutate({ data: { id: p.id, slug: p.slug } });
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
