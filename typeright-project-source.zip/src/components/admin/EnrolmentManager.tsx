import { useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { format } from "date-fns";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { deleteEnrolment, upsertEnrolment } from "@/lib/classes.admin.functions";
import type { Programme } from "@/components/admin/ProgrammeManager";

type EnrolmentRow = {
  id: string;
  user_id: string;
  course_slug: string;
  title: string;
  level_name: string | null;
  instructor_name: string | null;
  status: string;
  payment_reference: string | null;
  payment_amount_bnd: number | null;
  paid_at: string | null;
  payment_note: string | null;
  created_at?: string | null;
};

const empty = {
  id: undefined as string | undefined,
  userId: "",
  courseSlug: "",
  levelName: "",
  instructorName: "",
  status: "active",
  paymentReference: "",
  paymentAmountBnd: "",
  paidAt: "",
  paymentNote: "",
  sessionIds: [] as string[],
};

export function EnrolmentManager({
  enrolments,
  profiles,
  programmes,
  sessions,
  attendees,
  onChanged,
}: {
  enrolments: EnrolmentRow[];
  profiles: any[];
  programmes: Programme[];
  sessions: any[];
  attendees: any[];
  onChanged: () => void;
}) {
  const [form, setForm] = useState(empty);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const save = useMutation({
    mutationFn: useServerFn(upsertEnrolment),
    onSuccess: () => {
      toast.success("Enrolment activated");
      setForm(empty);
      setOpen(false);
      onChanged();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not save this enrolment."),
  });

  const remove = useMutation({
    mutationFn: useServerFn(deleteEnrolment),
    onSuccess: () => {
      toast.success("Enrolment removed");
      onChanged();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not remove this enrolment."),
  });

  const learnerLabel = (userId: string) => {
    const p = profiles.find((x) => x.id === userId);
    return p?.display_name || p?.email || "Unknown learner";
  };

  const filteredProfiles = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = q
      ? profiles.filter(
          (p) =>
            (p.display_name ?? "").toLowerCase().includes(q) ||
            (p.email ?? "").toLowerCase().includes(q),
        )
      : profiles;
    return list.slice(0, 50);
  }, [profiles, search]);

  const upcomingForCourse = useMemo(
    () =>
      sessions.filter(
        (s) =>
          s.course_slug === form.courseSlug &&
          s.status !== "cancelled" &&
          new Date(s.starts_at) >= new Date(Date.now() - 12 * 60 * 60 * 1000),
      ),
    [sessions, form.courseSlug],
  );

  const startEdit = (e: EnrolmentRow) => {
    setOpen(true);
    setForm({
      id: e.id,
      userId: e.user_id,
      courseSlug: e.course_slug,
      levelName: e.level_name ?? "",
      instructorName: e.instructor_name ?? "",
      status: e.status,
      paymentReference: e.payment_reference ?? "",
      paymentAmountBnd: e.payment_amount_bnd != null ? String(e.payment_amount_bnd) : "",
      paidAt: e.paid_at ? e.paid_at.slice(0, 10) : "",
      paymentNote: e.payment_note ?? "",
      sessionIds: attendees
        .filter((a) => a.enrolment_id === e.id)
        .map((a) => a.session_id as string),
    });
  };

  const submit = () => {
    const programme = programmes.find((p) => p.slug === form.courseSlug);
    if (!form.userId) return toast.error("Choose a learner.");
    if (!programme) return toast.error("Choose a programme.");
    save.mutate({
      data: {
        ...(form.id ? { id: form.id } : {}),
        userId: form.userId,
        courseSlug: programme.slug,
        title: programme.title,
        levelName: form.levelName.trim() || null,
        instructorName: form.instructorName.trim() || programme.default_instructor || null,
        status: form.status as "active" | "completed" | "suspended",
        paymentReference: form.paymentReference.trim() || null,
        paymentAmountBnd: form.paymentAmountBnd ? Number(form.paymentAmountBnd) : null,
        paidAt: form.paidAt || null,
        paymentNote: form.paymentNote.trim() || null,
        sessionIds: form.sessionIds,
      },
    });
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Enrolments
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Activate a learner's course once their bank transfer has been verified.
          </p>
        </div>
        <Button
          size="sm"
          variant={open ? "ghost" : "outline"}
          onClick={() => {
            setOpen((v) => !v);
            setForm(empty);
          }}
        >
          {open ? "Close" : (<><Plus className="mr-1 h-4 w-4" /> Add enrolment</>)}
        </Button>
      </div>

      {open && (
        <div className="mt-4 space-y-3 rounded-xl border border-border bg-background p-4">
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Learner</Label>
              <Input
                className="mt-1"
                placeholder="Search name or email"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <Select value={form.userId} onValueChange={(v) => setForm({ ...form, userId: v })}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select a learner account" />
                </SelectTrigger>
                <SelectContent>
                  {filteredProfiles.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.display_name ? `${p.display_name} — ${p.email}` : p.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {profiles.length === 0 && (
                <p className="mt-1 text-xs text-muted-foreground">
                  No accounts yet — the learner must sign up first.
                </p>
              )}
            </div>
            <div>
              <Label className="text-xs">Programme</Label>
              <Select
                value={form.courseSlug}
                onValueChange={(v) =>
                  setForm({ ...form, courseSlug: v, sessionIds: form.id ? form.sessionIds : [] })
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select a programme" />
                </SelectTrigger>
                <SelectContent>
                  {programmes.map((p) => (
                    <SelectItem key={p.id} value={p.slug}>
                      {p.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                <Input
                  placeholder="Level (optional)"
                  value={form.levelName}
                  onChange={(e) => setForm({ ...form, levelName: e.target.value })}
                />
                <Input
                  placeholder="Trainer (optional)"
                  value={form.instructorName}
                  onChange={(e) => setForm({ ...form, instructorName: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="grid gap-2 sm:grid-cols-4">
            <div>
              <Label className="text-xs">Payment reference</Label>
              <Input
                className="mt-1"
                value={form.paymentReference}
                onChange={(e) => setForm({ ...form, paymentReference: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Amount (BND)</Label>
              <Input
                className="mt-1"
                type="number"
                min={0}
                step="0.01"
                value={form.paymentAmountBnd}
                onChange={(e) => setForm({ ...form, paymentAmountBnd: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Date paid</Label>
              <Input
                className="mt-1"
                type="date"
                value={form.paidAt}
                onChange={(e) => setForm({ ...form, paidAt: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs">Payment note</Label>
            <Textarea
              className="mt-1"
              rows={2}
              value={form.paymentNote}
              onChange={(e) => setForm({ ...form, paymentNote: e.target.value })}
            />
          </div>

          <div>
            <Label className="text-xs">Book into classes &amp; exams</Label>
            {!form.courseSlug ? (
              <p className="mt-1 text-xs text-muted-foreground">Choose a programme first.</p>
            ) : upcomingForCourse.length === 0 ? (
              <p className="mt-1 text-xs text-muted-foreground">
                No upcoming slots for this programme yet.
              </p>
            ) : (
              <ul className="mt-2 max-h-48 space-y-1 overflow-y-auto rounded-lg border border-border p-2">
                {upcomingForCourse.map((s) => {
                  const checked = form.sessionIds.includes(s.id);
                  return (
                    <li key={s.id}>
                      <label className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1 text-sm hover:bg-secondary">
                        <input
                          type="checkbox"
                          className="h-4 w-4 accent-[hsl(var(--accent))]"
                          checked={checked}
                          onChange={(e) =>
                            setForm((f) => ({
                              ...f,
                              sessionIds: e.target.checked
                                ? [...f.sessionIds, s.id]
                                : f.sessionIds.filter((x) => x !== s.id),
                            }))
                          }
                        />
                        <span className="min-w-0 truncate">
                          {s.title}
                          <span className="ml-2 text-xs text-muted-foreground">
                            {format(new Date(s.starts_at), "d MMM · HH:mm")} ·{" "}
                            {s.session_type === "exam" ? "Exam" : "Class"}
                          </span>
                        </span>
                      </label>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={submit} disabled={save.isPending}>
              {save.isPending ? "Saving…" : form.id ? "Save changes" : "Activate enrolment"}
            </Button>
            {form.id && (
              <Button size="sm" variant="ghost" onClick={() => setForm(empty)}>
                Cancel edit
              </Button>
            )}
          </div>
        </div>
      )}

      <ul className="mt-4 divide-y divide-border">
        {enrolments.length === 0 && (
          <li className="py-3 text-sm text-muted-foreground">
            No enrolments yet — add one once a learner's payment is verified.
          </li>
        )}
        {enrolments.map((e) => (
          <li key={e.id} className="flex items-center justify-between gap-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">
                {learnerLabel(e.user_id)}
                {e.status !== "active" && (
                  <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                    {e.status}
                  </span>
                )}
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {e.title}
                {e.level_name ? ` · ${e.level_name}` : ""}
                {e.payment_reference ? ` · Ref ${e.payment_reference}` : ""}
                {e.payment_amount_bnd != null ? ` · BND ${e.payment_amount_bnd}` : ""}
                {e.paid_at ? ` · paid ${format(new Date(e.paid_at), "d MMM yyyy")}` : ""}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              <Button size="icon" variant="ghost" aria-label="Edit enrolment" onClick={() => startEdit(e)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                aria-label="Remove enrolment"
                disabled={remove.isPending}
                onClick={() => {
                  if (
                    window.confirm(
                      `Remove ${learnerLabel(e.user_id)} from ${e.title}? Their booked slots will also be cleared.`,
                    )
                  ) {
                    remove.mutate({ data: { id: e.id } });
                  }
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
