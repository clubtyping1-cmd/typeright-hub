import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { StatusPill, TypePill } from "@/components/admin/calendar/pills";

export function EntryList({
  sessions,
  countFor,
  onPick,
}: {
  sessions: any[];
  countFor: (id: string) => number;
  onPick: (s: any) => void;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card">
      {sessions.length === 0 && <p className="p-5 text-sm text-muted-foreground">Nothing matches these filters.</p>}
      <ul className="divide-y divide-border">
        {sessions.map((s) => (
          <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <p className="flex items-center gap-2 text-sm font-medium">
                {s.title} <TypePill type={s.session_type} /> <StatusPill status={s.status} />
              </p>
              <p className="text-xs text-muted-foreground">
                {format(new Date(s.starts_at), "EEE d MMM yyyy · HH:mm")}
                {s.instructor_name ? ` · ${s.instructor_name}` : ""} · {countFor(s.id)}
                {s.capacity ? ` of ${s.capacity}` : ""} learners
              </p>
            </div>
            <Button size="sm" variant="outline" onClick={() => onPick(s)}>
              Manage
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
