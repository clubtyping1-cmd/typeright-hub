import { useMemo } from "react";
import {
  addDays,
  addMonths,
  addWeeks,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";

import { Button } from "@/components/ui/button";

export function CalendarGrid({
  mode,
  cursor,
  setCursor,
  sessions,
  countFor,
  onPick,
  onAddOn,
}: {
  mode: "month" | "week";
  cursor: Date;
  setCursor: (d: Date) => void;
  sessions: any[];
  countFor: (id: string) => number;
  onPick: (s: any) => void;
  onAddOn: (day: Date) => void;
}) {
  const days = useMemo(() => {
    const start =
      mode === "month"
        ? startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 })
        : startOfWeek(cursor, { weekStartsOn: 1 });
    const end =
      mode === "month" ? endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 }) : endOfWeek(cursor, { weekStartsOn: 1 });
    const out: Date[] = [];
    for (let d = start; d <= end; d = addDays(d, 1)) out.push(new Date(d));
    return out;
  }, [cursor, mode]);

  const step = (dir: number) => setCursor(mode === "month" ? addMonths(cursor, dir) : addWeeks(cursor, dir));

  return (
    <div className="rounded-2xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold">
          {mode === "month"
            ? format(cursor, "MMMM yyyy")
            : `${format(startOfWeek(cursor, { weekStartsOn: 1 }), "d MMM")} – ${format(
                endOfWeek(cursor, { weekStartsOn: 1 }),
                "d MMM yyyy",
              )}`}
        </span>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" aria-label="Previous" onClick={() => step(-1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setCursor(new Date())}>
            Today
          </Button>
          <Button variant="ghost" size="icon" aria-label="Next" onClick={() => step(1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-7 gap-1 text-center text-[11px] font-semibold uppercase text-muted-foreground">
        {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => (
          <div key={d}>{d}</div>
        ))}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {days.map((day) => {
          const dayClasses = sessions.filter((s) => isSameDay(new Date(s.starts_at), day));
          return (
            <div
              key={day.toISOString()}
              className={`group relative min-h-24 rounded-lg border border-border/60 p-1 text-left ${
                mode === "month" && !isSameMonth(day, cursor) ? "opacity-50" : ""
              } ${isSameDay(day, new Date()) ? "bg-secondary" : ""}`}
            >
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-medium">{day.getDate()}</span>
                <button
                  type="button"
                  aria-label={`Add entry on ${format(day, "d MMM")}`}
                  onClick={() => onAddOn(day)}
                  className="rounded p-0.5 text-muted-foreground opacity-0 transition hover:bg-secondary hover:text-foreground focus:opacity-100 group-hover:opacity-100"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="mt-1 space-y-1">
                {dayClasses.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => onPick(s)}
                    className={`w-full truncate rounded px-1 py-0.5 text-left text-[11px] ${
                      s.status === "cancelled"
                        ? "bg-destructive/10 text-destructive line-through"
                        : (s.session_type ?? "class") === "exam"
                          ? "bg-primary/10 text-primary"
                          : "bg-accent/10 text-accent-foreground"
                    }`}
                    title={s.title}
                  >
                    {format(new Date(s.starts_at), "HH:mm")} {s.title} ({countFor(s.id)}
                    {s.capacity ? `/${s.capacity}` : ""})
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
