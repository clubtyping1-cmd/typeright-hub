import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Programme } from "@/components/admin/ProgrammeManager";
import { SESSION_MODES } from "@/lib/learning.constants";
import { SESSION_TYPES } from "@/lib/classes.constants";
import { upsertClass } from "@/lib/classes.admin.functions";

const emptyForm = {
  id: undefined as string | undefined,
  sessionType: "class" as (typeof SESSION_TYPES)[number],
  courseSlug: "",
  title: "",
  date: "",
  startTime: "09:00",
  endTime: "11:00",
  mode: "onsite" as (typeof SESSION_MODES)[number],
  location: "",
  joinUrl: "",
  instructorName: "",
  capacity: "",
  notes: "",
};

function toLocalInput(iso: string) {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
    time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
  };
}

export function EntryFormDialog({
  open,
  onOpenChange,
  session,
  defaultDate,
  programmes,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  session?: any | null;
  defaultDate?: string;
  programmes: Programme[];
  onSaved: () => void;
}) {
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    if (!open) return;
    if (session) {
      const start = toLocalInput(session.starts_at);
      const end = session.ends_at ? toLocalInput(session.ends_at) : null;
      setForm({
        id: session.id,
        sessionType: session.session_type ?? "class",
        courseSlug: session.course_slug,
        title: session.title,
        date: start.date,
        startTime: start.time,
        endTime: end?.time ?? "",
        mode: session.mode,
        location: session.location ?? "",
        joinUrl: session.join_url ?? "",
        instructorName: session.instructor_name ?? "",
        capacity: session.capacity != null ? String(session.capacity) : "",
        notes: session.notes ?? "",
      });
    } else {
      setForm({ ...emptyForm, date: defaultDate ?? "" });
    }
  }, [open, session, defaultDate]);

  const save = useMutation({
    mutationFn: useServerFn(upsertClass),
    onSuccess: () => {
      toast.success(form.id ? "Entry updated — learner calendars refreshed" : "Added to everyone's calendar");
      onOpenChange(false);
      onSaved();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not save this entry."),
  });

  const schedulable = programmes.filter((p) => p.is_active || p.slug === form.courseSlug);

  const submit = () => {
    if (!form.courseSlug || !form.title || !form.date || !form.startTime) {
      toast.error("Programme, title, date and start time are required.");
      return;
    }
    save.mutate({
      data: {
        ...(form.id ? { id: form.id } : {}),
        sessionType: form.sessionType,
        courseSlug: form.courseSlug,
        title: form.title,
        startsAt: `${form.date}T${form.startTime}`,
        endsAt: form.endTime ? `${form.date}T${form.endTime}` : null,
        mode: form.mode,
        location: form.location || null,
        joinUrl: form.joinUrl || null,
        instructorName: form.instructorName || null,
        capacity: form.capacity ? Number(form.capacity) : null,
        notes: form.notes || null,
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{form.id ? "Edit entry" : "New entry"}</DialogTitle>
          <DialogDescription>
            {form.id
              ? "Changing the date or time marks this entry as rescheduled and notifies assigned learners."
              : "Scheduled entries appear on every learner's dashboard calendar."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-xs">Type</Label>
              <Select value={form.sessionType} onValueChange={(v) => setForm({ ...form, sessionType: v as any })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SESSION_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t === "exam" ? "Exam" : "Class"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Programme</Label>
              <Select
                value={form.courseSlug}
                onValueChange={(v) =>
                  setForm({
                    ...form,
                    courseSlug: v,
                    instructorName:
                      form.instructorName || (programmes.find((p) => p.slug === v)?.default_instructor ?? ""),
                  })
                }
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {schedulable.map((c) => (
                    <SelectItem key={c.id} value={c.slug}>
                      {c.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs">Title</Label>
            <Input className="mt-1" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-xs">Date</Label>
              <Input
                type="date"
                className="mt-1"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Start</Label>
              <Input
                type="time"
                className="mt-1"
                value={form.startTime}
                onChange={(e) => setForm({ ...form, startTime: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">End</Label>
              <Input
                type="time"
                className="mt-1"
                value={form.endTime}
                onChange={(e) => setForm({ ...form, endTime: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <Label className="text-xs">Mode</Label>
              <Select value={form.mode} onValueChange={(v) => setForm({ ...form, mode: v as any })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SESSION_MODES.map((m) => (
                    <SelectItem key={m} value={m}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Trainer</Label>
              <Input
                className="mt-1"
                value={form.instructorName}
                onChange={(e) => setForm({ ...form, instructorName: e.target.value })}
              />
            </div>
            <div>
              <Label className="text-xs">Capacity</Label>
              <Input
                type="number"
                min={1}
                className="mt-1"
                value={form.capacity}
                onChange={(e) => setForm({ ...form, capacity: e.target.value })}
              />
            </div>
          </div>

          {form.mode === "online" ? (
            <div>
              <Label className="text-xs">Online meeting link</Label>
              <Input
                className="mt-1"
                value={form.joinUrl}
                onChange={(e) => setForm({ ...form, joinUrl: e.target.value })}
              />
            </div>
          ) : (
            <div>
              <Label className="text-xs">Venue</Label>
              <Input
                className="mt-1"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
              />
            </div>
          )}

          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea
              className="mt-1"
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={save.isPending}>
            {save.isPending ? "Saving…" : form.id ? "Save changes" : "Add to calendar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
