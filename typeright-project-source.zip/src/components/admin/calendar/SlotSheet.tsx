import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { format } from "date-fns";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusPill, TypePill } from "@/components/admin/calendar/pills";
import { ATTENDANCE_STATUSES } from "@/lib/classes.constants";
import {
  assignLearner,
  cancelClass,
  deleteClass,
  markAttendance,
  restoreClass,
  unassignLearner,
} from "@/lib/classes.admin.functions";

export function SlotSheet({
  session,
  onOpenChange,
  attendees,
  profiles,
  enrolments,
  refresh,
  onEdit,
}: {
  session: any | null;
  onOpenChange: (v: boolean) => void;
  attendees: any[];
  profiles: any[];
  enrolments: any[];
  refresh: () => void;
  onEdit: () => void;
}) {
  const [pick, setPick] = useState("");
  const [reason, setReason] = useState("");
  const [confirm, setConfirm] = useState<null | "cancel" | "delete">(null);

  const assign = useMutation({
    mutationFn: useServerFn(assignLearner),
    onSuccess: () => {
      toast.success("Learner assigned");
      setPick("");
      refresh();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not assign learner."),
  });
  const unassign = useMutation({ mutationFn: useServerFn(unassignLearner), onSuccess: () => refresh() });
  const mark = useMutation({
    mutationFn: useServerFn(markAttendance),
    onSuccess: () => refresh(),
    onError: (e: any) => toast.error(e?.message ?? "Could not save attendance."),
  });
  const cancel = useMutation({
    mutationFn: useServerFn(cancelClass),
    onSuccess: () => {
      toast.success("Slot cancelled — learners notified");
      setReason("");
      setConfirm(null);
      refresh();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not cancel this slot."),
  });
  const restore = useMutation({
    mutationFn: useServerFn(restoreClass),
    onSuccess: () => {
      toast.success("Slot reinstated");
      refresh();
    },
  });
  const remove = useMutation({
    mutationFn: useServerFn(deleteClass),
    onSuccess: () => {
      toast.success("Slot deleted");
      setConfirm(null);
      onOpenChange(false);
      refresh();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not delete this slot."),
  });

  if (!session) return null;

  const nameOf = (userId: string) => {
    const p = profiles.find((x) => x.id === userId);
    return p?.display_name || p?.email || userId.slice(0, 8);
  };
  const eligible = enrolments.filter(
    (e) => e.course_slug === session.course_slug && !attendees.some((a) => a.user_id === e.user_id),
  );
  const full = session.capacity != null && attendees.length >= session.capacity;

  return (
    <>
      <Sheet open={Boolean(session)} onOpenChange={onOpenChange}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-md">
          <SheetHeader>
            <SheetTitle className="flex flex-wrap items-center gap-2 text-left">
              {session.title} <TypePill type={session.session_type} /> <StatusPill status={session.status} />
            </SheetTitle>
            <SheetDescription className="text-left">
              {format(new Date(session.starts_at), "EEE d MMM yyyy · HH:mm")} · {attendees.length}
              {session.capacity ? ` of ${session.capacity}` : ""} seats filled
            </SheetDescription>
          </SheetHeader>

          <div className="mt-4 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={onEdit}>
              Edit
            </Button>
            {session.status === "cancelled" ? (
              <Button size="sm" variant="ghost" onClick={() => restore.mutate({ data: { id: session.id } })}>
                Reinstate
              </Button>
            ) : (
              <Button size="sm" variant="ghost" onClick={() => setConfirm("cancel")}>
                Cancel slot
              </Button>
            )}
            <Button size="sm" variant="ghost" className="text-destructive" onClick={() => setConfirm("delete")}>
              <Trash2 className="mr-1.5 h-4 w-4" /> Delete
            </Button>
          </div>

          <div className="mt-6 flex flex-wrap items-end gap-2">
            <div className="min-w-48 flex-1">
              <Label className="text-xs">Assign an enrolled learner</Label>
              <Select value={pick} onValueChange={setPick}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder={eligible.length ? "Select a learner" : "No eligible learners"} />
                </SelectTrigger>
                <SelectContent>
                  {eligible.map((e) => (
                    <SelectItem key={e.id} value={e.id}>
                      {nameOf(e.user_id)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              disabled={!pick || full || assign.isPending}
              onClick={() => {
                const e = eligible.find((x) => x.id === pick);
                if (!e) return;
                assign.mutate({ data: { sessionId: session.id, userId: e.user_id, enrolmentId: e.id } });
              }}
            >
              {full ? "Full" : "Add"}
            </Button>
          </div>

          <ul className="mt-4 divide-y divide-border">
            {attendees.map((a) => (
              <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <span className="text-sm">{nameOf(a.user_id)}</span>
                <div className="flex items-center gap-2">
                  <Select
                    value={a.attendance_status}
                    onValueChange={(v) => mark.mutate({ data: { id: a.id, attendanceStatus: v as any } })}
                  >
                    <SelectTrigger className="h-9 w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ATTENDANCE_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Remove learner"
                    onClick={() => unassign.mutate({ data: { id: a.id } })}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </li>
            ))}
            {attendees.length === 0 && (
              <li className="py-3 text-sm text-muted-foreground">No learners assigned yet.</li>
            )}
          </ul>
        </SheetContent>
      </Sheet>

      <AlertDialog open={confirm !== null} onOpenChange={(v) => !v && setConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm === "delete" ? "Delete this slot?" : "Cancel this slot?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm === "delete"
                ? "The slot is permanently removed from everyone's calendar."
                : "Assigned learners are notified and the slot shows as cancelled."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {confirm === "cancel" && (
            <Input placeholder="Reason (optional)" value={reason} onChange={(e) => setReason(e.target.value)} />
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Keep it</AlertDialogCancel>
            <AlertDialogAction
              onClick={() =>
                confirm === "delete"
                  ? remove.mutate({ data: { id: session.id } })
                  : cancel.mutate({ data: { id: session.id, reason: reason || undefined } })
              }
            >
              {confirm === "delete" ? "Delete" : "Cancel slot"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
