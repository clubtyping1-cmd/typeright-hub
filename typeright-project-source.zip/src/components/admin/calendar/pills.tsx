export function StatusPill({ status }: { status?: string | null }) {
  if (!status || status === "scheduled") return null;
  const cancelled = status === "cancelled";
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
        cancelled ? "bg-destructive/10 text-destructive" : "bg-accent/10 text-accent"
      }`}
    >
      {cancelled ? "Cancelled" : "Rescheduled"}
    </span>
  );
}

export function TypePill({ type }: { type?: string | null }) {
  const isExam = type === "exam";
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
        isExam ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
      }`}
    >
      {isExam ? "Exam" : "Class"}
    </span>
  );
}
