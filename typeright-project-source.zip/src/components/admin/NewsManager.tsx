import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { Pencil, Plus, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";


import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  deleteNewsPost,
  listAllNews,
  upsertNewsPost,
} from "@/lib/news.functions";
import { NEWS_CATEGORIES, slugifyTitle, type NewsPost } from "@/lib/news.constants";

const empty = {
  id: undefined as string | undefined,
  slug: "",
  title: "",
  excerpt: "",
  body: "",
  category: NEWS_CATEGORIES[0] as string,
  coverUrl: "",
  author: "TypeRight Hub",
  publishedAt: new Date().toISOString().slice(0, 10),
  isPublished: true,
};

export function NewsManager() {
  const queryClient = useQueryClient();
  const fetchAll = useServerFn(listAllNews);
  const { data, isLoading } = useQuery({ queryKey: ["admin-news"], queryFn: () => fetchAll() });
  const posts = (data?.posts ?? []) as NewsPost[];

  const [form, setForm] = useState(empty);
  const [open, setOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const uploadCover = async (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be 5MB or smaller.");
      return;
    }
    setUploading(true);
    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage
        .from("news-covers")
        .upload(path, file, { upsert: false, contentType: file.type });
      if (error) throw error;
      setForm((f) => ({ ...f, coverUrl: `/api/public/news-cover/${path}` }));
      toast.success("Cover image uploaded");
    } catch (e: any) {
      toast.error(e?.message ?? "Could not upload this image.");
    } finally {
      setUploading(false);
    }
  };



  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-news"] });
    queryClient.invalidateQueries({ queryKey: ["news"] });
  };

  const save = useMutation({
    mutationFn: useServerFn(upsertNewsPost),
    onSuccess: () => {
      toast.success("News post saved");
      setForm(empty);
      setOpen(false);
      refresh();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not save this post."),
  });

  const remove = useMutation({
    mutationFn: useServerFn(deleteNewsPost),
    onSuccess: () => {
      toast.success("News post deleted");
      refresh();
    },
    onError: (e: any) => toast.error(e?.message ?? "Could not delete this post."),
  });

  const submit = () => {
    const slug = form.slug.trim() || slugifyTitle(form.title);
    if (!form.title.trim() || !slug) {
      toast.error("A headline is required.");
      return;
    }
    save.mutate({
      data: {
        ...(form.id ? { id: form.id } : {}),
        slug,
        title: form.title.trim(),
        excerpt: form.excerpt.trim() || null,
        body: form.body.trim() || null,
        category: form.category,
        coverUrl: form.coverUrl.trim() || null,
        author: form.author.trim() || "TypeRight Hub",
        publishedAt: form.publishedAt,
        isPublished: form.isPublished,
      },
    });
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">News</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Published posts appear on the public News page, newest first.
          </p>
        </div>
        <Button
          size="sm"
          variant={open ? "ghost" : "outline"}
          onClick={() => {
            setOpen((v) => !v);
            setForm(empty);
          }}
        >
          {open ? "Close" : (<><Plus className="mr-1 h-4 w-4" /> Add post</>)}
        </Button>
      </div>

      {open && (
        <div className="mt-4 space-y-3 rounded-xl border border-border bg-background p-4">
          <div>
            <Label className="text-xs">Headline</Label>
            <Input
              className="mt-1"
              value={form.title}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  title: e.target.value,
                  slug: f.id ? f.slug : slugifyTitle(e.target.value),
                }))
              }
            />
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">URL slug</Label>
              <Input
                className="mt-1"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: slugifyTitle(e.target.value) })}
              />
            </div>
            <div>
              <Label className="text-xs">Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {NEWS_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-xs">Summary</Label>
            <Textarea
              className="mt-1"
              rows={2}
              value={form.excerpt}
              onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
            />
          </div>

          <div>
            <Label className="text-xs">Article body</Label>
            <Textarea
              className="mt-1"
              rows={8}
              placeholder="Separate paragraphs with a blank line."
              value={form.body}
              onChange={(e) => setForm({ ...form, body: e.target.value })}
            />
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Cover image</Label>
              <div className="mt-1 space-y-2">
                {form.coverUrl ? (
                  <div className="flex items-center gap-3">
                    <img
                      src={form.coverUrl}
                      alt="Cover preview"
                      className="h-16 w-24 rounded-md border border-border object-cover"
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setForm((f) => ({ ...f, coverUrl: "" }))}
                    >
                      Remove
                    </Button>
                  </div>
                ) : null}
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    e.target.value = "";
                    if (file) void uploadCover(file);
                  }}
                />
                <Button
                  size="sm"
                  variant="outline"
                  disabled={uploading}
                  onClick={() => fileRef.current?.click()}
                >
                  <Upload className="mr-1 h-4 w-4" />
                  {uploading ? "Uploading…" : form.coverUrl ? "Replace image" : "Choose image"}
                </Button>
                <Input
                  className="mt-1"
                  placeholder="or paste a link (https://…)"
                  value={form.coverUrl}
                  onChange={(e) => setForm({ ...form, coverUrl: e.target.value })}
                />
                <p className="text-[11px] text-muted-foreground">JPG, PNG or WebP, up to 5MB.</p>
              </div>
            </div>
            <div>
              <Label className="text-xs">Author</Label>
              <Input
                className="mt-1"
                value={form.author}
                onChange={(e) => setForm({ ...form, author: e.target.value })}
              />
            </div>
          </div>


          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <Label className="text-xs">Publish date</Label>
              <Input
                type="date"
                className="mt-1"
                value={form.publishedAt}
                onChange={(e) => setForm({ ...form, publishedAt: e.target.value })}
              />
            </div>
            <div className="flex items-end gap-2 pb-2">
              <Switch
                id="news-published"
                checked={form.isPublished}
                onCheckedChange={(v) => setForm({ ...form, isPublished: v })}
              />
              <Label htmlFor="news-published" className="text-xs">
                Visible on the public News page
              </Label>
            </div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={submit} disabled={save.isPending}>
              {save.isPending ? "Saving…" : form.id ? "Save changes" : "Publish post"}
            </Button>
            {form.id && (
              <Button size="sm" variant="ghost" onClick={() => setForm(empty)}>
                Cancel edit
              </Button>
            )}
          </div>
        </div>
      )}

      <ul className="mt-4 divide-y divide-border">
        {isLoading && <li className="py-3 text-sm text-muted-foreground">Loading…</li>}
        {!isLoading && posts.length === 0 && (
          <li className="py-3 text-sm text-muted-foreground">No posts yet — add one to publish it.</li>
        )}
        {posts.map((p) => (
          <li key={p.id} className="flex items-center justify-between gap-3 py-2">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">
                {p.title}
                {!p.is_published && (
                  <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                    Draft
                  </span>
                )}
              </p>
              <p className="truncate text-xs text-muted-foreground">
                {p.category} ·{" "}
                {new Date(p.published_at).toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}{" "}
                · /news/{p.slug}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              <Button
                size="icon"
                variant="ghost"
                aria-label={`Edit ${p.title}`}
                onClick={() => {
                  setOpen(true);
                  setForm({
                    id: p.id,
                    slug: p.slug,
                    title: p.title,
                    excerpt: p.excerpt ?? "",
                    body: p.body ?? "",
                    category: p.category,
                    coverUrl: p.cover_url ?? "",
                    author: p.author,
                    publishedAt: p.published_at.slice(0, 10),
                    isPublished: p.is_published,
                  });
                }}
              >
                <Pencil className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                aria-label={`Delete ${p.title}`}
                disabled={remove.isPending}
                onClick={() => {
                  if (!window.confirm(`Delete "${p.title}"?`)) return;
                  remove.mutate({ data: { id: p.id } });
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}