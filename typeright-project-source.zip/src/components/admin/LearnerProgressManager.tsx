import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Award, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getLearnerProgress, setLearnerBadge, setLearnerLevel } from "@/lib/admin.functions";

const LEVELS = [
  { level: 1, name: "Beginner" },
  { level: 2, name: "Foundation" },
  { level: 3, name: "Intermediate" },
  { level: 4, name: "Advanced" },
  { level: 5, name: "Master" },
];

export function LearnerProgressManager() {
  const queryClient = useQueryClient();
  const fetchProgress = useServerFn(getLearnerProgress);
  const saveLevel = useServerFn(setLearnerLevel);
  const saveBadge = useServerFn(setLearnerBadge);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-learner-progress"],
    queryFn: () => fetchProgress(),
  });

  const [userId, setUserId] = useState<string>("");
  const [levelValue, setLevelValue] = useState<string>("1");
  const [levelName, setLevelName] = useState<string>("Beginner");

  const profiles: any[] = data?.profiles ?? [];
  const badges: any[] = data?.badges ?? [];
  const awarded: any[] = data?.awarded ?? [];
  const levels: any[] = data?.levels ?? [];

  const selectLearner = (id: string) => {
    setUserId(id);
    const existing = levels.find((l) => l.user_id === id);
    setLevelValue(String(existing?.level ?? 1));
    setLevelName(existing?.level_name ?? LEVELS[0].name);
  };

  const earned = useMemo(
    () => new Set(awarded.filter((a) => a.user_id === userId).map((a) => a.badge_code)),
    [awarded, userId],
  );

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin-learner-progress"] });

  const levelMutation = useMutation({
    mutationFn: () =>
      saveLevel({ data: { userId, level: Number(levelValue), levelName: levelName.trim() } }),
    onSuccess: () => {
      toast.success("Level updated");
      refresh();
    },
    onError: () => toast.error("Could not save the level"),
  });

  const badgeMutation = useMutation({
    mutationFn: (v: { badgeCode: string; awarded: boolean }) =>
      saveBadge({ data: { userId, badgeCode: v.badgeCode, awarded: v.awarded } }),
    onSuccess: () => refresh(),
    onError: () => toast.error("Could not update the badge"),
  });

  if (isLoading) {
    return (
      <div className="flex min-h-40 items-center justify-center">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="max-w-md space-y-2">
        <Label>Learner</Label>
        <Select value={userId} onValueChange={selectLearner}>
          <SelectTrigger>
            <SelectValue placeholder="Choose a learner" />
          </SelectTrigger>
          <SelectContent>
            {profiles.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.display_name ? `${p.display_name} — ${p.email}` : p.email}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {!userId ? (
        <p className="text-sm text-muted-foreground">
          Select a learner to set their level and award badges.
        </p>
      ) : (
        <div className="space-y-6">
          <div className="rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold">Achievement level</h3>
            <div className="mt-3 flex flex-wrap items-end gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Level</Label>
                <Select
                  value={levelValue}
                  onValueChange={(v) => {
                    setLevelValue(v);
                    const preset = LEVELS.find((l) => String(l.level) === v);
                    if (preset) setLevelName(preset.name);
                  }}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LEVELS.map((l) => (
                      <SelectItem key={l.level} value={String(l.level)}>
                        Level {l.level}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Level name</Label>
                <Input
                  value={levelName}
                  onChange={(e) => setLevelName(e.target.value)}
                  className="w-56"
                />
              </div>
              <Button
                onClick={() => levelMutation.mutate()}
                disabled={!levelName.trim() || levelMutation.isPending}
              >
                Save level
              </Button>
            </div>
          </div>

          <div className="rounded-xl border border-border p-4">
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <Award className="h-4 w-4" /> Badges
            </h3>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {badges.map((b) => (
                <label
                  key={b.code}
                  className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2"
                >
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-medium">{b.label}</span>
                    <span className="block text-xs text-muted-foreground">{b.description}</span>
                  </span>
                  <Switch
                    checked={earned.has(b.code)}
                    onCheckedChange={(checked) =>
                      badgeMutation.mutate({ badgeCode: b.code, awarded: checked })
                    }
                  />
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
