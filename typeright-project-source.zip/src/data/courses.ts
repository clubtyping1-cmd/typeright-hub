import {
  Keyboard,
  PenLine,
  GraduationCap,
  Users,
  type LucideIcon,
} from "lucide-react";

import photoTyping from "@/assets/cover-trt.jpeg.asset.json";
import photoShorthand from "@/assets/cover-trs.png.asset.json";
import photoTrainer from "@/assets/cover-train-the-trainer.png.asset.json";

const serviceTyping = photoTyping.url;
const serviceShorthand = photoShorthand.url;
const serviceDigital = photoTrainer.url;

export type Instructor = {
  id: string;
  name: string;
  title: string;
  bio: string;
  initial: string;
  rating: number;
  students: number;
  courses: number;
};

export type PriceTier = {
  id: string;
  label: string;
  price: number;
  unit?: string;
  note?: string;
};

export type LevelRow = { level: string; minWpm: string; description: string };
export type PhaseRow = { phase: string; mode: string; duration: string; description: string };
export type ModuleArea = { area: string; examples: string };

export type CurriculumModule = {
  title: string;
  duration: string;
  lessons: string[];
};

export type Review = {
  name: string;
  rating: number;
  date: string;
  comment: string;
};

export type CourseAssessmentInfo = {
  summary: string;
  format: string;
  duration: string;
  steps: { title: string; body: string }[];
  outcomes: string[];
  fees?: { label: string; price: number }[];
  feeNote?: string;
  certificateTitle?: string;
  transcript?: string[];
  upgradePathway?: string[];
};

export type CourseProgressReportInfo = {
  summary: string;
  price: number;
  turnaround: string;
  includes: string[];
};

export type Course = {
  slug:
    | "keyboard-mastery-trt"
    | "shorthand-training-trs"
    | "train-the-trainer";
  category: "programme" | "trainer";
  code?: string;
  title: string;
  tagline: string;
  icon: LucideIcon;
  price: number;
  originalPrice: number;
  priceTiers?: PriceTier[];
  levels?: LevelRow[];
  phases?: PhaseRow[];
  moduleAreas?: ModuleArea[];
  ctaMode?: "form" | "contact";
  duration: string;
  level: string;
  language: string;
  rating: number;
  ratingCount: number;
  studentsEnrolled: number;
  description: string[];
  whatYoullLearn?: string[];
  curriculum?: CurriculumModule[];
  requirements?: string[];
  instructors?: Instructor[];
  reviews?: Review[];
  includes?: string[];
  image?: string;
  format?: string;
  assessment?: CourseAssessmentInfo;
  progressReport?: CourseProgressReportInfo;
};

const noraini: Instructor = { id: "hjh-noraini", name: "Hjh Noraini Abdullah", title: "Senior Typing & Secretarial Instructor", initial: "N", bio: "Hjh Noraini has trained government officers, private-sector staff and school leavers across Brunei for over 20 years, specialising in typing and secretarial competency examinations.", rating: 4.9, students: 5820, courses: 4 };
const kelvin: Instructor = { id: "mr-kelvin", name: "Kelvin Tan", title: "Digital Skills Coach", initial: "K", bio: "Kelvin coaches learners on modern keyboarding, ergonomics and workplace productivity. He focuses on measurable results and consistent daily practice.", rating: 4.7, students: 2140, courses: 3 };
const hasnah: Instructor = { id: "puan-hasnah", name: "Puan Hasnah Ismail", title: "Lead Shorthand Instructor", initial: "H", bio: "Puan Hasnah has taught shorthand in both English and Malay for over 15 years and has prepared hundreds of learners for national secretarial examinations.", rating: 4.9, students: 2260, courses: 2 };
const daud: Instructor = { id: "cikgu-daud", name: "Cikgu Daud", title: "Malay Shorthand Specialist", initial: "D", bio: "Cikgu Daud specialises in Malay-language dictation and transcription, working with public sector officers who need bilingual note-taking skills.", rating: 4.8, students: 940, courses: 1 };

const allCourses: Course[] = [
  {
    slug: "keyboard-mastery-trt",
    category: "programme",
    title: "Keyboard Mastery Programme\u00A0",
    tagline: "Structured typing development using the TypeRight typing platform",
    icon: Keyboard,
    image: serviceTyping,
    format: "Certificate pathway",
    price: 40,
    originalPrice: 40,
    priceTiers: [
      { id: "full-day-course", label: "Full Day Keyboard Mastery Course", price: 40, unit: "per participant" },
      { id: "exam", label: "Examination / Assessment", price: 40, unit: "one-off" },
      { id: "upgrade", label: "Upgrade Typing Level Assessment", price: 40, unit: "one-off" },
      { id: "retake", label: "Retake Examination", price: 25, unit: "one-off" },
      { id: "report", label: "Optional Detailed Progress Report", price: 10, unit: "one-off" },
    ],
    levels: [
      { level: "Beginner", minWpm: "35 WPM", description: "Improved rhythm, accuracy, and basic workplace readiness." },
      { level: "Intermediate", minWpm: "45 WPM", description: "Stronger typing speed suitable for clerical and administrative tasks." },
      { level: "Advanced", minWpm: "55 WPM", description: "Higher professional standard for office documentation and fast-paced workplace tasks." },
    ],
    duration: "Full day guided session + ongoing practice",
    level: "Beginner to Advanced",
    language: "English & Malay\n",
    rating: 4.8,
    ratingCount: 1284,
    studentsEnrolled: 3540,
    description: [
      "The Keyboard Mastery Programme is a structured typing development programme designed to help participants improve typing speed, accuracy, posture, rhythm, keyboard discipline, and workplace readiness.",
      "The full day guided session covers correct finger placement, posture, rhythm, speed, accuracy and familiarisation with the TypeRight typing platform. Learners then progress through weekly or monthly online practice, culminating in a formal typing assessment.",
      "Successful candidates receive a Certificate of Achievement and a Typing Level Transcript, and may progress from Beginner, Intermediate and Advanced levels.",
    ],
    whatYoullLearn: [
      "Correct ten-finger technique and finger placement",
      "Posture, ergonomics and rhythm at the keyboard",
      "Speed and accuracy development up to 55+ WPM",
      "Typing platform familiarisation and self-practice",
      "Business document typing readiness",
      "Preparation for Examination and level upgrade",
    ],
    curriculum: [
      { title: "Full Day Keyboard Mastery Course", duration: "Full day", lessons: ["Correct finger placement", "Posture and ergonomics", "Rhythm and consistency", "Typing platform familiarisation"] },
      { title: "Online Practice", duration: "Weekly / Monthly", lessons: ["Guided speed drills", "Accuracy exercises", "Self-diagnosis of weak keys", "Progress tracking"] },
      { title: "Examination / Assessment", duration: "~1 hour", lessons: ["Formal typing assessment", "Level determination (Beginner → Advanced)", "Certificate of Achievement", "Typing Level Transcript"] },
    ],
    requirements: [
      "A laptop or desktop with a standard keyboard",
      "Stable internet access for online practice",
      "No prior typing experience required",
    ],
    instructors: [noraini, kelvin],
    reviews: [
      { name: "Aina R.", rating: 5, date: "3 weeks ago", comment: "Went from 22 WPM to 55 WPM in two months. The drills and progress tracking make a huge difference." },
      { name: "Farid H.", rating: 5, date: "1 month ago", comment: "Perfect preparation for my secretarial examination. Clear structure and very patient instructors." },
      { name: "Siti M.", rating: 4, date: "2 months ago", comment: "Really well paced. Would love even more advanced business document exercises." },
    ],
    includes: ["Full day guided session", "Typing platform practice access", "Assessment pathway", "Certificate and Typing Level Transcript"],
    assessment: {
      summary:
        "The Examination is the final stage of this programme. It is a formal, supervised typing assessment that determines your certified typing level.",
      format: "Supervised typing examination on the TypeRight typing platform",
      duration: "About 1 hour",
      steps: [
        { title: "Check-in", body: "Arrive 15 minutes early with your ID and booking confirmation." },
        { title: "Warm-up", body: "Short familiarisation run on the examination interface." },
        { title: "Assessed run", body: "Timed typing test under examination conditions, scored on speed and accuracy." },
        { title: "Marking and result", body: "Instructor review and level determination; results confirmed within about one week. Your final speed is recorded as Net Words Per Minute, supported by your accuracy percentage and number of errors." },
      ],
      outcomes: [
        "Certified level from Beginner (35 WPM) to Advanced (55 WPM)",
        "Certificate of Achievement",
        "Typing Level Transcript",
        "Level upgrade pathway for repeat candidates",
      ],
      fees: [
        { label: "Examination / Assessment", price: 40 },
        { label: "Upgrade Typing Level Assessment", price: 40 },
        { label: "Retake Examination", price: 25 },
      ],
      feeNote:
        "The retake fee applies only to candidates who attempted an assessment but did not meet the passing mark for the level they applied for. Upgrade candidates are charged the normal examination fee of BND 40, not the retake fee.",
      certificateTitle:
        "Certificate of Achievement in Keyboard Mastery — Beginner, Intermediate or Advanced Level, according to the level achieved accredited by IBTE, CET.",
      transcript: [
        "Candidate name",
        "Assessment date",
        "Typing level achieved",
        "Words per minute (Net WPM)",
        "Accuracy percentage",
        "Errors recorded",
        "Final result: Passed / Not Yet Achieved",
      ],
      upgradePathway: [
        "Retaking the guided course is optional — available if you want extra technique correction or instructor support.",
        "A minimum weekly online practice subscription is mandatory before an upgrade examination.",
        "The upgrade is charged as a normal examination (BND 40), not as a retake.",
        "If you do not meet the higher-level passing mark, no upgraded certificate is issued and you may apply again when ready.",
      ],
    },
    progressReport: {
      summary:
        "An optional detailed progress report reviewing your typing practice and examination performance, with an instructor recommendation for your next level.",
      price: 10,
      turnaround: "5–7 working days after your assessment or practice window closes",
      includes: [
        "Speed and accuracy breakdown across practice and examination",
        "Current typing level and readiness indicator",
        "Instructor recommendation for the next step",
        "Suitable for school and employer submission",
      ],
    },
  },
  {
    slug: "shorthand-training-trs",
    category: "programme",
    title: "Shorthand Training Programme\u00A0",
    tagline: "Gregg Shorthand with dictation, transcription and platform-supported practice",
    icon: PenLine,
    image: serviceShorthand,
    format: "Certificate pathway",
    price: 150,
    originalPrice: 150,
    priceTiers: [
      { id: "phase-1", label: "Fundamental Skill Development — 5 Days", price: 150, unit: "per participant" },
      { id: "phase-2", label: "Advanced Skill Development — 5 Days", price: 180, unit: "per participant" },
      { id: "exam", label: "Shorthand Examination / Assessment", price: 40, unit: "one-off" },
      { id: "retake", label: "Retake Examination", price: 25, unit: "one-off" },
      { id: "report", label: "Optional Shorthand Progress Report", price: 10, unit: "one-off" },
    ],
    phases: [
      { phase: "Phase 1: Fundamental Skill Development", mode: "Instructor-led and guided", duration: "5 days", description: "Gregg Shorthand fundamentals, sound-based writing, strokes, basic outlines, accuracy development, and platform-supported practice." },
      { phase: "Phase 2: Advanced Skill Development", mode: "Instructor-led and guided", duration: "5 days", description: "Long-form dictation, speed-building, fluency, stamina, workplace vocabulary, transcription, and examination preparation." },
      { phase: "Phase 3: Examination and Result Confirmation", mode: "Shorthand Examination + instructor marking", duration: "2-hour exam + ~1 week result", description: "Learners sit for examination. Results are reviewed and confirmed by the shorthand instructor before release." },
    ],
    duration: "10 days instructor-led + examination",
    level: "Beginner to Intermediate",
    language: "English & Malay",
    rating: 4.7,
    ratingCount: 612,
    studentsEnrolled: 1480,
    description: [
      "The Shorthand Training Programme equips learners with the ability to record spoken information quickly, accurately and efficiently using Gregg Shorthand, supported by the TypeRight platform and structured examination workflow.",
      "Assessment covers timed dictation, transcription, accuracy review, speed and fluency evaluation, and instructor marking. Final results are confirmed within approximately one week after examination.",
    ],
    whatYoullLearn: [
      "Gregg Shorthand alphabet, strokes and outlines",
      "Sound-based writing and brief forms",
      "Timed dictation up to workplace speeds",
      "Accurate transcription from shorthand to longhand",
      "Bilingual English and Malay shorthand practice",
      "Preparation for Examination and result confirmation",
    ],
    curriculum: [
      { title: "Phase 1 — Fundamental Skill Development", duration: "5 days", lessons: ["Gregg Shorthand fundamentals", "Sound-based writing", "Strokes and basic outlines", "Platform-supported practice"] },
      { title: "Phase 2 — Advanced Skill Development", duration: "5 days", lessons: ["Long-form dictation", "Speed-building and fluency", "Workplace vocabulary", "Transcription and exam prep"] },
      { title: "Phase 3 — Examination and Result", duration: "2h exam + ~1 week", lessons: ["Timed dictation", "Transcription assessment", "Accuracy review and instructor marking", "Result confirmation"] },
    ],
    requirements: [
      "Notebook and pen for shorthand practice",
      "Computer with internet access for shorthand practice",
      "Basic typing ability recommended for transcription",
    ],
    instructors: [hasnah, daud],
    reviews: [
      { name: "Nurul S.", rating: 5, date: "2 weeks ago", comment: "The bilingual approach is exactly what I needed for my role in the ministry. Highly recommended." },
      { name: "Amirul K.", rating: 5, date: "1 month ago", comment: "Clear explanations and lots of dictation practice at different speeds. I passed my examination on the first try." },
      { name: "Liyana J.", rating: 4, date: "6 weeks ago", comment: "Great course. The Malay module was especially useful." },
    ],
    includes: ["10 days of instructor-led training", "Shorthand platform practice access", "Shorthand Examination pathway", "Certificate on successful completion"],
    assessment: {
      summary:
        "Phase 3 of this programme is the Shorthand Examination — a timed dictation and transcription assessment marked by your shorthand instructor.",
      format: "Timed dictation and written transcription under examination conditions",
      duration: "2-hour examination, result in about one week",
      steps: [
        { title: "Check-in", body: "Arrive 15 minutes early with your ID, notebook and pen." },
        { title: "Dictation", body: "Timed dictation passages at your examination speed, in English or Malay." },
        { title: "Transcription", body: "Transcribe your shorthand notes accurately into longhand." },
        { title: "Marking and result", body: "Instructor marks accuracy, speed and fluency; result confirmed within about one week." },
      ],
      outcomes: [
        "Verified dictation speed and transcription accuracy",
        "Certificate of Achievement",
        "Instructor feedback on accuracy and fluency",
        "Retake pathway for repeat candidates",
      ],
      fees: [
        { label: "Shorthand Examination / Assessment", price: 40 },
        { label: "Retake Examination", price: 25 },
      ],
    },
    progressReport: {
      summary:
        "An optional detailed shorthand progress report covering dictation speed, transcription accuracy and fluency, with an instructor recommendation.",
      price: 10,
      turnaround: "5–7 working days after your examination or practice window closes",
      includes: [
        "Dictation speed and transcription accuracy breakdown",
        "Fluency and readiness indicator",
        "Instructor recommendation for the next step",
        "Suitable for school and employer submission",
      ],
    },
  },
  {
    slug: "train-the-trainer",
    category: "trainer",
    title: "Future Train-the-Trainer Pathway",
    tagline: "Training future facilitators to expand programme delivery",
    icon: Users,
    image: serviceDigital,
    format: "Facilitator pathway",
    price: 0,
    originalPrice: 0,
    ctaMode: "contact",
    duration: "Coming soon",
    level: "Facilitators",
    language: "English",
    rating: 5,
    ratingCount: 0,
    studentsEnrolled: 0,
    description: [
      "A forthcoming pathway to train future facilitators and trainers in delivering TypeRight programmes across institutions in Brunei.",
      "Register your interest to be notified as intake opens.",
    ],
    includes: ["Facilitator certification pathway", "Programme delivery methodology", "Typing and shorthand instructor training", "Ongoing trainer support"],
  },
];

// Hidden for now: the Train-the-Trainer pathway is not offered publicly yet.
const HIDDEN_CATEGORIES: Course["category"][] = ["trainer"];

export const courses: Course[] = allCourses.filter(
  (c) => !HIDDEN_CATEGORIES.includes(c.category),
);

// Backwards-compat helpers no longer needed; instructors imported directly by components if required.
void GraduationCap;

export function getCourseBySlug(slug: string): Course | undefined {
  return courses.find((c) => c.slug === slug);
}
